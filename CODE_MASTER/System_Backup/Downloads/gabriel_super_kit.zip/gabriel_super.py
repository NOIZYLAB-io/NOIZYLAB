#!/usr/bin/env python3
"""
GABRIEL Super Reorg Engine — v1.0
Scan any directory, classify files, generate a reorg plan, apply it safely with
transaction logs and rollback. Designed for macOS (but mostly POSIX-agnostic).

Usage examples:
  # Analyze only (no changes), write manifest + report
  python gabriel_super.py scan --path "/Volumes/GABRIEL" --out "/Volumes/GABRIEL/_GabrielEngine"

  # Create a reorg plan (no changes), targeting a destination root
  python gabriel_super.py plan --path "/Volumes/GABRIEL/Downloads" --dest-root "/Volumes/GABRIEL/Reorg" --out "/Volumes/GABRIEL/_GabrielEngine"

  # Apply a plan immediately (moves files), keep rollback log
  python gabriel_super.py apply --path "/Volumes/GABRIEL/Downloads" --dest-root "/Volumes/GABRIEL/Reorg" --out "/Volumes/GABRIEL/_GabrielEngine"

  # Restore from a transaction log
  python gabriel_super.py restore --txn "/Volumes/GABRIEL/_GabrielEngine/txns/txn_2025-11-12_10-00-00.json"

Notes:
- Hashing uses SHA1 by default (stdlib). For speed on huge media, we hash first N bytes + size.
- Classification is extension-based with light content sniffing fallback.
"""

import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

# ---------- Config (tweak as needed) ----------
HASH_CHUNK_BYTES = 4 * 1024 * 1024  # 4MB chunk size
PARTIAL_HASH_LIMIT = 64 * 1024 * 1024  # 64MB; files larger get partial-hash strategy
MAX_WORKERS = min(32, (os.cpu_count() or 8) * 2)

EXT_MAP = {
    "audio": {".wav", ".aiff", ".mp3", ".flac", ".ogg", ".m4a", ".aac"},
    "code": {".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml", ".yml", ".sh", ".bash", ".zsh", ".rb", ".go", ".rs", ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".php"},
    "image": {".png", ".jpg", ".jpeg", ".gif", ".tiff", ".bmp", ".svg", ".webp", ".heic"},
    "video": {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".mts"},
    "docs":  {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".md", ".rtf", ".txt"},
    "archive": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"},
}

CATEGORY_DEST = {
    "audio": "Audio",
    "code": "Code",
    "image": "Images",
    "video": "Video",
    "docs": "Documents",
    "archive": "Archives",
    "other": "Other"
}

# ---------- Helpers ----------

def sha1_fast(path: Path) -> str:
    """Hash file; for very large files, hash first N bytes + size for speed."""
    try:
        size = path.stat().st_size
        h = hashlib.sha1()
        with path.open("rb") as f:
            if size > PARTIAL_HASH_LIMIT:
                remaining = PARTIAL_HASH_LIMIT
                while remaining > 0:
                    chunk = f.read(min(HASH_CHUNK_BYTES, remaining))
                    if not chunk:
                        break
                    h.update(chunk)
                    remaining -= len(chunk)
                h.update(str(size).encode())
            else:
                while True:
                    chunk = f.read(HASH_CHUNK_BYTES)
                    if not chunk:
                        break
                    h.update(chunk)
        return h.hexdigest()
    except Exception as e:
        return f"ERR:{e.__class__.__name__}"

def classify(path: Path) -> str:
    ext = path.suffix.lower()
    for cat, exts in EXT_MAP.items():
        if ext in exts:
            return cat
    return "other"

def rel_sanitized(path: Path) -> str:
    return str(path).replace("\n", " ").replace("\r", " ")

def now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

# ---------- Scanning ----------

def scan_directory(root: Path, out_dir: Path) -> Path:
    """Walk and build manifest JSON with basic metadata + hashes (parallelized)."""
    ensure_dir(out_dir)
    manifest_path = out_dir / f"manifest_{now_stamp()}.jsonl"
    files: List[Path] = []
    for base, _, names in os.walk(root):
        for n in names:
            p = Path(base) / n
            if p.is_file():
                files.append(p)

    def describe(p: Path) -> Dict:
        try:
            st = p.stat()
            cat = classify(p)
            h = sha1_fast(p)
            return {
                "path": rel_sanitized(p),
                "size": st.st_size,
                "mtime": int(st.st_mtime),
                "category": cat,
                "hash": h,
            }
        except Exception as e:
            return {"path": rel_sanitized(p), "error": str(e)}

    start = time.time()
    written = 0
    with open(manifest_path, "w", encoding="utf-8") as out, cf.ThreadPoolExecutor(MAX_WORKERS) as pool:
        for info in pool.map(describe, files, chunksize=128):
            out.write(json.dumps(info) + "\n")
            written += 1

    dur = time.time() - start
    print(f"[SCAN] {written} files indexed in {dur:.1f}s -> {manifest_path}")
    return manifest_path

# ---------- Planning ----------

def load_manifest_lines(path: Path) -> List[Dict]:
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))
    return items

def build_plan(manifest_path: Path, dest_root: Path, out_dir: Path) -> Path:
    ensure_dir(out_dir)
    ensure_dir(dest_root)
    plan_path = out_dir / f"plan_{now_stamp()}.jsonl"
    items = load_manifest_lines(manifest_path)

    # duplicate detection: by (size, hash)
    seen: Dict[Tuple[int, str], str] = {}

    def plan_for(item: Dict) -> Dict:
        if "error" in item:
            return {"path": item.get("path"), "action": "skip", "reason": item["error"]}
        src = Path(item["path"])
        cat = item.get("category", "other")
        dest_cat = CATEGORY_DEST.get(cat, "Other")
        key = (item.get("size", -1), item.get("hash", ""))
        subdir = dest_cat
        action = "move"
        reason = ""

        if item.get("hash", "").startswith("ERR:"):
            subdir = "Other"
            reason = "hash_error"
        elif key in seen:
            subdir = "Duplicates"
            reason = f"duplicate_of:{seen[key]}"
        else:
            seen[key] = item["path"]

        rel_name = src.name
        dst = dest_root / subdir / rel_name
        # avoid collisions: append short hash if needed
        if dst.exists():
            short = str(item.get("hash",""))[:8]
            dst = dest_root / subdir / f"{src.stem}__{short}{src.suffix}"

        return {
            "path": item["path"],
            "dest": str(dst),
            "category": cat,
            "action": action,
            "reason": reason,
            "size": item.get("size", 0),
            "hash": item.get("hash", ""),
        }

    start = time.time()
    written = 0
    with open(plan_path, "w", encoding="utf-8") as out:
        for it in items:
            out.write(json.dumps(plan_for(it)) + "\n")
            written += 1
    dur = time.time() - start
    print(f"[PLAN] {written} items planned in {dur:.1f}s -> {plan_path}")
    return plan_path

# ---------- Apply & Rollback ----------

def apply_plan(plan_path: Path, out_dir: Path, dry_run: bool=False) -> Path:
    ensure_dir(out_dir)
    txndir = out_dir / "txns"
    ensure_dir(txndir)
    txn_path = txndir / f"txn_{now_stamp()}.json"
    moves = []
    errors = []

    with open(plan_path, "r", encoding="utf-8") as f:
        lines = [json.loads(x) for x in f if x.strip()]

    def do_move(entry: Dict) -> Dict:
        src = Path(entry["path"])
        dst = Path(entry["dest"])
        if entry.get("action") != "move":
            return {"src": str(src), "dst": str(dst), "status": "skipped", "reason": entry.get("reason","")}
        try:
            if not dst.parent.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
            if dry_run:
                return {"src": str(src), "dst": str(dst), "status": "dry-run"}
            shutil.move(str(src), str(dst))
            return {"src": str(src), "dst": str(dst), "status": "moved"}
        except Exception as e:
            return {"src": str(src), "dst": str(dst), "status": "error", "error": str(e)}

    start = time.time()
    with cf.ThreadPoolExecutor(MAX_WORKERS) as pool:
        for result in pool.map(do_move, lines, chunksize=64):
            if result["status"] == "error":
                errors.append(result)
            elif result["status"] == "moved":
                moves.append(result)

    txn = {
        "created": now_stamp(),
        "plan": str(plan_path),
        "moves": moves,
        "errors": errors,
        "dry_run": dry_run,
    }
    with open(txn_path, "w", encoding="utf-8") as f:
        json.dump(txn, f, indent=2)
    dur = time.time() - start
    print(f"[APPLY] moved {len(moves)} items, {len(errors)} errors in {dur:.1f}s -> {txn_path}")
    return txn_path

def restore_txn(txn_path: Path):
    with open(txn_path, "r", encoding="utf-8") as f:
        txn = json.load(f)
    moves = txn.get("moves", [])
    errors = 0

    def undo(entry: Dict) -> Dict:
        src = Path(entry["dst"])  # current location
        dst = Path(entry["src"])  # original source
        try:
            if not dst.parent.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dst))
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e), "from": str(src), "to": str(dst)}

    with cf.ThreadPoolExecutor(MAX_WORKERS) as pool:
        for res in pool.map(undo, moves, chunksize=64):
            if not res.get("ok"):
                errors += 1
                print(f"[RESTORE] error: {res}")

    print(f"[RESTORE] completed with {errors} errors.")

# ---------- Reporting ----------

def summary_from_manifest(manifest_path: Path, out_dir: Path) -> Path:
    ensure_dir(out_dir)
    items = load_manifest_lines(manifest_path)
    summary = {
        "total_files": 0,
        "total_bytes": 0,
        "by_category": {},
        "by_extension": {},
    }
    for it in items:
        if "error" in it:
            continue
        summary["total_files"] += 1
        summary["total_bytes"] += it.get("size", 0)
        cat = it.get("category", "other")
        summary["by_category"][cat] = summary["by_category"].get(cat, 0) + 1
        ext = Path(it["path"]).suffix.lower() or "<none>"
        summary["by_extension"][ext] = summary["by_extension"].get(ext, 0) + 1

    report_path = out_dir / f"report_{now_stamp()}.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"[REPORT] -> {report_path}")
    return report_path

# ---------- CLI ----------

def main():
    ap = argparse.ArgumentParser(description="GABRIEL Super Reorg Engine")
    sub = ap.add_subparsers(dest="cmd", required=True)

    for name in ("scan", "plan", "apply"):
        sp = sub.add_parser(name)
        sp.add_argument("--path", required=True, help="Directory to process")
        sp.add_argument("--out", required=True, help="Engine working dir (manifests/plans/txns)")
        if name in ("plan", "apply"):
            sp.add_argument("--dest-root", required=True, help="Destination root for reorg (e.g., /Volumes/GABRIEL/Reorg)")
        if name == "apply":
            sp.add_argument("--dry-run", action="store_true", help="Simulate apply; no changes")

    sr = sub.add_parser("restore")
    sr.add_argument("--txn", required=True, help="Transaction JSON path to roll back")

    rr = sub.add_parser("report")
    rr.add_argument("--manifest", required=True, help="Manifest path (JSONL)")
    rr.add_argument("--out", required=True, help="Output dir for report JSON")

    args = ap.parse_args()
    cmd = args.cmd

    path = Path(getattr(args, "path", "."))
    out = Path(getattr(args, "out", "./_GabrielEngine"))

    if cmd == "scan":
        ensure_dir(out)
        manifest = scan_directory(path, out)
        summary_from_manifest(manifest, out)

    elif cmd == "plan":
        ensure_dir(out)
        manifest = scan_directory(path, out)
        plan = build_plan(manifest, Path(args.dest_root), out)
        summary_from_manifest(manifest, out)
        print(f"[NEXT] Review plan: {plan}")

    elif cmd == "apply":
        ensure_dir(out)
        manifest = scan_directory(path, out)
        plan = build_plan(manifest, Path(args.dest_root), out)
        txn = apply_plan(plan, out, dry_run=args.dry_run)
        print(f"[NEXT] To restore: python gabriel_super.py restore --txn \"{txn}\"")

    elif cmd == "restore":
        restore_txn(Path(args.txn))

    elif cmd == "report":
        summary_from_manifest(Path(args.manifest), out)

if __name__ == "__main__":
    main()
