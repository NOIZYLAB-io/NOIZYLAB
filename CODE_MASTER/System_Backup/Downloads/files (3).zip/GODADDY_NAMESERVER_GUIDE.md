# GODADDY NAMESERVER UPDATE - COMPLETE GUIDE
## GORUNFREEX1000 - Zero Ambiguity Instructions

---

## 🎯 OBJECTIVE
Update fishmusicinc.com nameservers from GoDaddy to Cloudflare

**Cloudflare Nameservers:**
```
naomi.ns.cloudflare.com
renan.ns.cloudflare.com
```

---

## ⚡ QUICK START (5 MINUTES)

### STEP 1: LOGIN TO GODADDY
1. Open browser: https://sso.godaddy.com
2. Enter your email and password
3. Click **Sign In**

### STEP 2: NAVIGATE TO DOMAIN
4. Click **"My Products"** at the top
5. Scroll to **"All Products and Services"** section
6. Find **fishmusicinc.com** in the list
7. Click **"DNS"** button next to it
   - *Alternative*: Click three dots (⋮) → **"Manage DNS"**

### STEP 3: DISABLE DNSSEC (CRITICAL!)
8. On DNS Management page, scroll down to **"Additional Settings"**
9. Look for **"DNSSEC"** section
10. **IF DNSSEC shows "Active" or "Enabled":**
    - Click **"Manage"** or **"Edit"**
    - Click **"Remove"** or **"Disable"**
    - Confirm the removal
    - **WAIT 5 MINUTES** before proceeding

### STEP 4: CHANGE NAMESERVERS
11. Scroll back to top of DNS Management page
12. Find **"Nameservers"** section (usually near the top)
13. Click **"Change"** button
14. Select **"Enter my own nameservers (advanced)"**
    - Or: **"I'll use my own nameservers"**
    - Or: **"Custom"**
15. **DELETE ALL existing nameservers:**
    - Click the X or trash icon next to each one
    - Remove ALL of them (usually 2-4 nameservers)
16. **ADD Cloudflare nameservers:**
    
    **Nameserver 1:**
    ```
    naomi.ns.cloudflare.com
    ```
    
    **Nameserver 2:**
    ```
    renan.ns.cloudflare.com
    ```
    
17. Click **"Save"**

### STEP 5: CONFIRM CHANGES
18. GoDaddy will show a warning: **"Changing nameservers will affect email"**
    - **IGNORE THIS WARNING** - we're setting up email in Cloudflare
    - Click **"Continue"** or **"Yes, I understand"**
19. You should see confirmation: **"Nameservers updated successfully"**

---

## ✅ VERIFICATION

### Immediate Check (In GoDaddy)
- Nameservers section should now show:
  ```
  naomi.ns.cloudflare.com
  renan.ns.cloudflare.com
  ```

### Wait Period
- **1-24 hours** for global propagation
- Most changes complete within **2-4 hours**

### Online Verification Tools
After 1 hour, check:
- https://www.whatsmydns.net/#NS/fishmusicinc.com
- https://dnschecker.org/#NS/fishmusicinc.com

### Command Line Verification
```bash
dig NS fishmusicinc.com +short
```
Should return:
```
naomi.ns.cloudflare.com.
renan.ns.cloudflare.com.
```

---

## 🔧 TROUBLESHOOTING

### "Cannot change nameservers"
**Cause:** Domain may be locked or within 60-day transfer lock
**Solution:**
1. Check domain lock status in GoDaddy
2. Unlock domain if locked
3. Wait if within 60-day transfer period

### "DNSSEC cannot be disabled"
**Cause:** DS records still propagating
**Solution:**
1. Wait 5 minutes and try again
2. Clear browser cache
3. Contact GoDaddy support if persists

### "Nameservers invalid"
**Cause:** Typo in nameserver entry
**Solution:**
1. Double-check spelling
2. Ensure no extra spaces
3. Copy-paste from this document

### Changes not propagating
**Cause:** DNS caching
**Solution:**
1. Wait 4-6 hours
2. Try from different device/network
3. Use different DNS checker tool

---

## 📋 WHAT GODADDY INTERFACE LOOKS LIKE

### Top of DNS Management Page
```
┌─────────────────────────────────────────────────┐
│ DNS MANAGEMENT - fishmusicinc.com              │
├─────────────────────────────────────────────────┤
│                                                  │
│ Nameservers                    [Change] button  │
│ ├─ nameserver1.example.com                      │
│ └─ nameserver2.example.com                      │
│                                                  │
└─────────────────────────────────────────────────┘
```

### Nameserver Edit Screen
```
┌─────────────────────────────────────────────────┐
│ Change Nameservers                              │
├─────────────────────────────────────────────────┤
│                                                  │
│ ○ GoDaddy Nameservers (default)                │
│ ● Enter my own nameservers (advanced)          │
│                                                  │
│ Nameserver 1: [_________________________] [X]   │
│ Nameserver 2: [_________________________] [X]   │
│                                                  │
│ [Add Nameserver]                                │
│                                                  │
│          [Cancel]              [Save]           │
└─────────────────────────────────────────────────┘
```

### DNSSEC Section (Additional Settings)
```
┌─────────────────────────────────────────────────┐
│ Additional Settings                             │
├─────────────────────────────────────────────────┤
│                                                  │
│ DNSSEC                Status: Active [Manage]   │
│ │                                                │
│ └─ Helps protect against DNS spoofing          │
│                                                  │
└─────────────────────────────────────────────────┘
```

---

## ⏱️ TIMELINE

| Time | Action | Status |
|------|--------|--------|
| T+0 min | Change nameservers at GoDaddy | Complete |
| T+5 min | GoDaddy updates internal systems | Processing |
| T+1 hour | Initial propagation begins | Partial |
| T+4 hours | Most DNS servers updated | ~80% done |
| T+24 hours | Full global propagation | 100% done |

---

## 🚨 CRITICAL WARNINGS

### DO NOT:
- ❌ Change nameservers back and forth
- ❌ Add additional nameservers beyond the 2 Cloudflare ones
- ❌ Mix GoDaddy and Cloudflare nameservers
- ❌ Enable DNSSEC until zone is active in Cloudflare

### DO:
- ✅ Disable DNSSEC BEFORE changing nameservers
- ✅ Use ONLY the 2 Cloudflare nameservers
- ✅ Wait full 24 hours before assuming failure
- ✅ Keep a backup of current DNS records (just in case)

---

## 📞 SUPPORT CONTACTS

### GoDaddy Support
- Phone: 1-480-505-8877
- Chat: https://www.godaddy.com/contact-us
- Hours: 24/7

### Cloudflare Support
- Community: https://community.cloudflare.com
- Documentation: https://developers.cloudflare.com

---

## 🎉 SUCCESS INDICATORS

### In GoDaddy Dashboard
```
Nameservers: Custom
├─ naomi.ns.cloudflare.com
└─ renan.ns.cloudflare.com
```

### In Cloudflare Dashboard
```
Status: Active ✅
```

### You Will Receive
- Email from Cloudflare: "Your site is now active"
- Domain status changes from "Pending" to "Active"

---

## 📝 NOTES FOR ROB

- **Time to complete:** 5 minutes at GoDaddy
- **Time to activate:** 1-24 hours (usually 2-4 hours)
- **Email downtime:** None (if Cloudflare DNS is configured first)
- **Website downtime:** None (if Cloudflare DNS is configured first)

This is why we configured everything in Cloudflare FIRST with the main setup script. When nameservers switch, everything is already in place.

---

**GORUNFREEX1000 PRINCIPLE:**
One execution at GoDaddy → Everything propagates automatically → Zero downtime

---

Generated by GORUNFREEX1000
Fish Music Inc. | MC(^!!! Ecosystem
