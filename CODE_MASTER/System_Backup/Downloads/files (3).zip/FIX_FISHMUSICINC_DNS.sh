#!/bin/bash
###############################################################################
# AUTOMATED DNS FIX FOR FISHMUSICINC.COM
# ONE COMMAND = ALL FIXES DONE
# Designed for voice-first workflow
###############################################################################

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   FISHMUSICINC.COM - AUTOMATED DNS FIX                    ║"
echo "║   One Command = Everything Fixed                          ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Domain and Account
DOMAIN="fishmusicinc.com"
ACCOUNT_ID="5ba03939f87a498d0bbed185ee123946"
API_BASE="https://api.cloudflare.com/client/v4"

# Check for API token
if [ -z "$CLOUDFLARE_API_TOKEN" ]; then
    echo "❌ ERROR: CLOUDFLARE_API_TOKEN not set"
    echo ""
    echo "You need a Cloudflare API token. Here's how to get it:"
    echo ""
    echo "1. Go to: https://dash.cloudflare.com/profile/api-tokens"
    echo "2. Click 'Create Token'"
    echo "3. Use 'Edit zone DNS' template"
    echo "4. Select zone: fishmusicinc.com"
    echo "5. Click 'Continue to summary'"
    echo "6. Click 'Create Token'"
    echo "7. Copy the token"
    echo ""
    echo "Then run:"
    echo "export CLOUDFLARE_API_TOKEN='your_token_here'"
    echo "./FIX_FISHMUSICINC_DNS.sh"
    echo ""
    exit 1
fi

echo "✅ API Token found"
echo ""

# Get Zone ID
echo "🔍 Finding zone ID for ${DOMAIN}..."
ZONE_RESPONSE=$(curl -s -X GET "${API_BASE}/zones?account.id=${ACCOUNT_ID}&name=${DOMAIN}" \
  -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
  -H "Content-Type: application/json")

ZONE_ID=$(echo "$ZONE_RESPONSE" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    if data.get('success') and data.get('result') and len(data['result']) > 0:
        print(data['result'][0]['id'])
    else:
        print('ERROR')
except:
    print('ERROR')
" 2>/dev/null)

if [ "$ZONE_ID" == "ERROR" ] || [ -z "$ZONE_ID" ]; then
    echo "❌ Could not find zone"
    exit 1
fi

echo "✅ Zone ID: ${ZONE_ID}"
echo ""

# Get all DNS records
echo "📋 Fetching DNS records..."
RECORDS=$(curl -s -X GET "${API_BASE}/zones/${ZONE_ID}/dns_records" \
  -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
  -H "Content-Type: application/json")

echo "✅ Records fetched"
echo ""

###############################################################################
# FIX #1: UPDATE SPF RECORD
###############################################################################

echo "🔧 FIX #1: Updating SPF record..."

SPF_RECORD_ID=$(echo "$RECORDS" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for record in data.get('result', []):
    if record['type'] == 'TXT' and 'spf1' in record.get('content', ''):
        print(record['id'])
        break
" 2>/dev/null)

if [ -n "$SPF_RECORD_ID" ]; then
    NEW_SPF="v=spf1 include:_spf.google.com ~all"
    
    UPDATE_RESPONSE=$(curl -s -X PATCH "${API_BASE}/zones/${ZONE_ID}/dns_records/${SPF_RECORD_ID}" \
      -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
      -H "Content-Type: application/json" \
      --data "{\"content\":\"${NEW_SPF}\"}")
    
    SUCCESS=$(echo "$UPDATE_RESPONSE" | python3 -c "import sys, json; print(json.load(sys.stdin).get('success', False))")
    
    if [ "$SUCCESS" == "True" ]; then
        echo "   ✅ SPF record updated"
        echo "   Old: v=spf1 include:_spf.webador.com..."
        echo "   New: ${NEW_SPF}"
    else
        echo "   ⚠️  SPF update failed"
    fi
else
    echo "   ⚠️  SPF record not found"
fi

echo ""

###############################################################################
# FIX #2: UPDATE DMARC RECORD
###############################################################################

echo "🔧 FIX #2: Updating DMARC record..."

DMARC_RECORD_ID=$(echo "$RECORDS" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for record in data.get('result', []):
    if record['type'] == 'TXT' and record['name'].startswith('_dmarc'):
        print(record['id'])
        break
" 2>/dev/null)

if [ -n "$DMARC_RECORD_ID" ]; then
    NEW_DMARC="v=DMARC1; p=quarantine; rua=mailto:rp@fishmusicinc.com"
    
    UPDATE_RESPONSE=$(curl -s -X PATCH "${API_BASE}/zones/${ZONE_ID}/dns_records/${DMARC_RECORD_ID}" \
      -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
      -H "Content-Type: application/json" \
      --data "{\"content\":\"${NEW_DMARC}\"}")
    
    SUCCESS=$(echo "$UPDATE_RESPONSE" | python3 -c "import sys, json; print(json.load(sys.stdin).get('success', False))")
    
    if [ "$SUCCESS" == "True" ]; then
        echo "   ✅ DMARC record updated"
        echo "   Old: v=DMARC1; p=none"
        echo "   New: ${NEW_DMARC}"
    else
        echo "   ⚠️  DMARC update failed"
    fi
else
    echo "   ⚠️  DMARC record not found"
fi

echo ""

###############################################################################
# CLEANUP: DELETE OLD RECORDS
###############################################################################

echo "🧹 CLEANUP: Removing old records..."

# Delete mandrill DKIM
MANDRILL_ID=$(echo "$RECORDS" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for record in data.get('result', []):
    if 'mandrill._domainkey' in record['name']:
        print(record['id'])
        break
" 2>/dev/null)

if [ -n "$MANDRILL_ID" ]; then
    curl -s -X DELETE "${API_BASE}/zones/${ZONE_ID}/dns_records/${MANDRILL_ID}" \
      -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" > /dev/null
    echo "   ✅ Deleted old mandrill DKIM record"
fi

# Delete autodiscover
AUTODISCOVER_ID=$(echo "$RECORDS" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for record in data.get('result', []):
    if '_autodiscover' in record['name']:
        print(record['id'])
        break
" 2>/dev/null)

if [ -n "$AUTODISCOVER_ID" ]; then
    curl -s -X DELETE "${API_BASE}/zones/${ZONE_ID}/dns_records/${AUTODISCOVER_ID}" \
      -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" > /dev/null
    echo "   ✅ Deleted old autodiscover record"
fi

echo ""

###############################################################################
# SUMMARY
###############################################################################

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   FIXES COMPLETE                                           ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "✅ SPF record updated (Google only)"
echo "✅ DMARC record upgraded (quarantine policy)"
echo "✅ Old records cleaned up"
echo ""
echo "⚠️  STILL NEED TO ADD:"
echo "   Google Workspace DKIM record"
echo ""
echo "Next step:"
echo "1. Go to: https://admin.google.com"
echo "2. Apps → Gmail → Authenticate email"
echo "3. Generate DKIM key"
echo "4. Run: ./ADD_GOOGLE_DKIM.sh"
echo ""
echo "Or tell Claude: 'Add Google DKIM now'"
echo ""
