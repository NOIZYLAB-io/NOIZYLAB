# DIGITAL PLATFORM QUICK CHECKLIST
## Rob Plowman | Fish Music Inc | NOIZYLAB | NOIZYFISH

**Last Updated:** November 12, 2025

---

## ✅ CONFIRMED ACTIVE

| Platform | Status | Username/URL | Priority |
|----------|--------|--------------|----------|
| Google Workspace | ✅ ACTIVE | rp@fishmusicinc.com | CRITICAL |
| Cloudflare | ✅ ACTIVE | noizylab.ca account | CRITICAL |
| GoDaddy | ✅ ACTIVE | fishmusicinc.com | HIGH |
| Website | ✅ ACTIVE | fishmusicinc.com | CRITICAL |

---

## ❓ TO BE DISCOVERED

### SOCIAL MEDIA
- [ ] **YouTube** - Search: "Fish Music Inc" / "NOIZYLAB"
- [ ] **Facebook** - Search pages and personal
- [ ] **Instagram** - Check @fishmusicinc / @noizylab / @noizyfish
- [ ] **Twitter/X** - Check @fishmusicinc / @noizylab
- [ ] **Threads** - Check if Instagram-linked
- [ ] **LinkedIn** - Search: "Rob Plowman composer" / company pages
- [ ] **Discord** - Check app on devices
- [ ] **TikTok** - Search brand names

### MICROSOFT ECOSYSTEM
- [ ] **Microsoft 365** - Check for account
- [ ] **OneDrive** - Check for storage
- [ ] **Outlook.com** - Check for email
- [ ] **Teams** - Check for usage

### MUSIC PLATFORMS
- [ ] **Spotify** - Search for compositions
- [ ] **Apple Music** - Search for work
- [ ] **SoundCloud** - Check for portfolio
- [ ] **Bandcamp** - Check for presence
- [ ] **IMDB** - Search "Rob Plowman composer"

### PROFESSIONAL
- [ ] **SOCAN** - Canadian music rights
- [ ] **PRO Memberships** - ASCAP/BMI
- [ ] **AFM** - Musicians union
- [ ] **Industry Forums** - Gearspace, VI-Control

### DEVELOPMENT
- [ ] **GitHub** - Check for repositories
- [ ] **GitLab** - Alternative platform

---

## 🔍 SEARCH COMMANDS TO RUN

**Google Searches:**
```
"Fish Music Inc"
"Fish Music Inc Toronto"
"NOIZYLAB"
"NOIZYFISH"
"Rob Plowman composer"
"Rob Plowman sound design"
site:linkedin.com "Rob Plowman"
site:facebook.com "Fish Music Inc"
site:instagram.com "fishmusicinc"
site:youtube.com "Fish Music Inc"
```

**Email Searches (in Gmail):**
```
from:facebook.com
from:instagram.com
from:youtube.com
from:linkedin.com
from:twitter.com
from:discord.com
from:microsoft.com
subject:"verify your account"
subject:"welcome to"
```

---

## 📋 DISCOVERY PROCESS

### STEP 1: EMAIL AUDIT (10 min)
1. Search Gmail for platform notifications
2. Look for "verify", "welcome", "account"
3. Check for password reset emails
4. Note all platforms found

### STEP 2: BROWSER CHECK (5 min)
1. Check saved passwords in browser
2. Review bookmarks for platforms
3. Check browser history for logins
4. Note all accounts found

### STEP 3: PHONE CHECK (5 min)
1. Look for apps installed
2. Check notification history
3. Review app store downloads
4. Note all apps found

### STEP 4: ONLINE SEARCH (15 min)
1. Google search brand names
2. Search social platforms directly
3. Use domain search tools
4. Document all findings

---

## 📊 DOCUMENTATION TEMPLATE

For each platform found, record:

**Platform Name:** ___________
**Brand:** Fish Music Inc / NOIZYLAB / NOIZYFISH / Personal
**Username:** ___________
**Email Used:** ___________
**Status:** Active / Dormant / Unknown
**Last Activity:** ___________
**Follower Count:** ___________
**Content Type:** ___________
**Priority:** Critical / High / Medium / Low
**Notes:** ___________

---

## 🎯 IMMEDIATE PRIORITIES

**IF YOU FIND ACCOUNTS:**

**Critical (Fix Today):**
1. LinkedIn - Update profile, add portfolio
2. YouTube - Verify ownership, update info
3. Facebook - Update business page
4. Instagram - Update profile, post content

**High (This Week):**
5. Update bios across all platforms
6. Ensure consistent branding
7. Link all platforms to website
8. Add contact information

**Medium (This Month):**
9. Refresh content on each platform
10. Set up cross-platform posting
11. Build analytics dashboard
12. Plan content calendar

---

## 🚀 QUICK WINS

**30-Second Fixes:**
- [ ] Update profile photos everywhere (same image)
- [ ] Add website link to all bios
- [ ] Add email to contact sections
- [ ] Enable notifications for messages

**5-Minute Fixes:**
- [ ] Update bio/about sections (consistent message)
- [ ] Add recent portfolio pieces
- [ ] Update service descriptions
- [ ] Link platforms to each other

**30-Minute Fixes:**
- [ ] Write unified bio (use everywhere)
- [ ] Create content calendar
- [ ] Plan next 5 posts
- [ ] Set up auto-cross-posting

---

## 💡 TIPS FOR DISCOVERY

**Finding Lost Accounts:**
1. Try common username patterns:
   - fishmusicinc
   - fish_music_inc
   - robplowman
   - rob.plowman
   - noizylab
   - noizyfish

2. Check old email addresses:
   - Search in current Gmail
   - Check forwarded emails
   - Look for old welcome messages

3. Use platform recovery:
   - "Forgot password" with email
   - Will show if account exists
   - Don't actually reset (yet)

4. Ask past clients:
   - "How did you find me online?"
   - May reveal forgotten platforms

---

## 📞 NEED HELP?

**Can't access something?**
→ Tell Claude: "Help me recover [platform] account"

**Found an account?**
→ Tell Claude: "Found [platform], what's next?"

**Want automation?**
→ Tell Claude: "Build me [automation type]"

**Ready for full audit?**
→ Tell Claude: "Do complete platform audit"

---

## 🎯 TODAY'S MISSION

**Pick ONE task and complete it:**

[ ] Search Gmail for social media notifications  
[ ] Search Google for "Fish Music Inc" + platform names  
[ ] Check phone for installed social media apps  
[ ] Try logging into LinkedIn/Facebook/Instagram  
[ ] Update one profile with current information  

**Just do ONE. Progress > Perfection.**

---

**Remember:** 
- You don't need to be on every platform
- Quality > Quantity
- Focus on where your clients are
- Automation will handle the rest

**GORUNFREEX1000 = One discovery at a time**

---

Generated: November 12, 2025  
System: GORUNFREEX1000  
For: Rob Plowman Digital Ecosystem
