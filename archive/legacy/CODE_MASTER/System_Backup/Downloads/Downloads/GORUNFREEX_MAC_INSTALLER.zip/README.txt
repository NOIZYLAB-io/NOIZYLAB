
GORUNFREEX ULTRA++ PRO macOS Installer
======================================

Usage:
1. Ensure Python 3.8+ is installed.
2. Place this script in the same directory as:
   - god_sync_pro.py
   - dashboard.py
3. Run:
   python mac_installer.py

Features:
- Installs dependencies
- Verifies GPU availability
- Downloads HuggingFace models
- Creates required directories
- Starts Flask dashboard
- Launches Mac sync service
- Includes Catalina-specific compatibility adjustments
