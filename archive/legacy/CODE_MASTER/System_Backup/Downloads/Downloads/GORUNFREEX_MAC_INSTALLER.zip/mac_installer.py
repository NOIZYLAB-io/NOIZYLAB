
#!/usr/bin/env python3
import os
import subprocess
import sys
import platform

print("GORUNFREEX ULTRA++ PRO macOS Installer")

# Check macOS version
mac_version = platform.mac_ver()[0]
print(f"Detected macOS version: {mac_version}")
if mac_version.startswith("10.15"):
    print("Applying Catalina-specific compatibility settings...")
    # Catalina-specific logic: ensure proper permissions and Python path
    subprocess.run(["xattr", "-r", "-d", "com.apple.quarantine", "."])

# Step 1: Verify Python version
if sys.version_info < (3, 8):
    print("Python 3.8 or higher is required.")
    sys.exit(1)

# Step 2: Install dependencies
dependencies = [
    "watchdog",
    "transformers",
    "torch",
    "torchvision",
    "pillow",
    "flask",
    "cryptography",
    "git+https://github.com/openai/CLIP.git"
]
print("Installing dependencies...")
subprocess.check_call([sys.executable, "-m", "pip", "install"] + dependencies)

# Step 3: Verify GPU availability
import torch
print("GPU Available:", torch.cuda.is_available())

# Step 4: Download HuggingFace models
from transformers import pipeline
print("Downloading models...")
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
classifier = pipeline("text-classification", model="distilbert-base-uncased")
print("Models downloaded and cached.")

# Step 5: Create directory structure
os.makedirs("/Users/Shared/GORUNFREEX", exist_ok=True)
print("Directories created.")

# Step 6: Start Flask dashboard
print("Starting dashboard...")
dashboard_cmd = [sys.executable, "dashboard.py"]
subprocess.Popen(dashboard_cmd)

# Step 7: Launch sync service for Mac
print("Launching Mac sync service...")
subprocess.Popen([sys.executable, "god_sync_pro.py"])
