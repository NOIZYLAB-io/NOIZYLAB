#!/bin/bash
#
# GOD_RESTORE_FROM_BACKUP.sh
# RESTORE SYSTEM AFTER REFORMAT
# GORUNFREEX1000 - ONE COMMAND = COMPLETE RESTORATION
#
# Run this on freshly reformatted GOD after setup

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}║              GOD COMPLETE RESTORE SYSTEM                             ║${NC}"
echo -e "${CYAN}║                    GORUNFREEX1000                                    ║${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check for backup drives
echo -e "${YELLOW}[1/6] LOCATING BACKUP${NC}"
echo ""
echo "Available volumes:"
ls /Volumes/ | grep -v "Macintosh HD"
echo ""

read -p "Enter backup drive name: " BACKUP_DRIVE
BACKUP_ROOT="/Volumes/$BACKUP_DRIVE"

if [[ ! -d "$BACKUP_ROOT" ]]; then
    echo -e "${RED}✗ Backup drive not found${NC}"
    exit 1
fi

# Find backup folders
BACKUPS=($(ls "$BACKUP_ROOT" | grep "GOD_COMPLETE_BACKUP_"))
if [[ ${#BACKUPS[@]} -eq 0 ]]; then
    echo -e "${RED}✗ No backups found${NC}"
    exit 1
fi

echo ""
echo "Available backups:"
INDEX=1
for BACKUP in "${BACKUPS[@]}"; do
    SIZE=$(du -sh "$BACKUP_ROOT/$BACKUP" 2>/dev/null | awk '{print $1}')
    echo "  [$INDEX] $BACKUP - Size: $SIZE"
    ((INDEX++))
done
echo ""

read -p "Select backup [1-${#BACKUPS[@]}]: " BACKUP_NUM
BACKUP_PATH="$BACKUP_ROOT/${BACKUPS[$((BACKUP_NUM-1))]}"

echo -e "${GREEN}✓ Using backup: $BACKUP_PATH${NC}"
echo ""

# Verify backup
echo -e "${YELLOW}[2/6] VERIFYING BACKUP${NC}"
echo ""

if [[ ! -f "$BACKUP_PATH/BACKUP_MANIFEST.txt" ]]; then
    echo -e "${RED}✗ Backup manifest not found - backup may be incomplete${NC}"
    read -p "Continue anyway? (yes/no): " CONTINUE
    if [[ "$CONTINUE" != "yes" ]]; then
        exit 1
    fi
fi

echo -e "${GREEN}✓ Backup verified${NC}"
echo ""

# Restore user data
echo -e "${YELLOW}[3/6] RESTORING USER DATA${NC}"
echo ""

USER_HOME="/Users/rsp_ms"
BACKUP_USER="$BACKUP_PATH/Users_rsp_ms"

if [[ -d "$BACKUP_USER" ]]; then
    echo -e "${CYAN}Restoring home directory...${NC}"
    rsync -ah --progress "$BACKUP_USER/" "$USER_HOME/"
    echo -e "${GREEN}✓ User data restored${NC}"
else
    echo -e "${RED}✗ User backup not found${NC}"
fi
echo ""

# Restore application data
echo -e "${YELLOW}[4/6] RESTORING APPLICATION DATA${NC}"
echo ""

BACKUP_APPS="$BACKUP_PATH/Application_Support"
if [[ -d "$BACKUP_APPS" ]]; then
    APP_SUPPORT="$USER_HOME/Library/Application Support"
    echo -e "${CYAN}Restoring application data...${NC}"
    rsync -ah --progress "$BACKUP_APPS/" "$APP_SUPPORT/"
    echo -e "${GREEN}✓ Application data restored${NC}"
else
    echo -e "${YELLOW}⚠ No application data found${NC}"
fi
echo ""

# Set permissions
echo -e "${YELLOW}[5/6] FIXING PERMISSIONS${NC}"
echo ""
sudo chown -R rsp_ms:staff "$USER_HOME"
chmod -R u+rw "$USER_HOME"
echo -e "${GREEN}✓ Permissions set${NC}"
echo ""

# Summary
echo -e "${YELLOW}[6/6] RESTORATION COMPLETE${NC}"
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}║                  RESTORE COMPLETE ✓                                  ║${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Restored from:${NC} $BACKUP_PATH"
echo ""
echo -e "${YELLOW}POST-RESTORE CHECKLIST:${NC}"
echo "[ ] Verify restored files"
echo "[ ] Reinstall applications"
echo "[ ] Connect external drives"
echo "[ ] Setup MC96 network (10.90.90.90)"
echo "[ ] Configure PLANAR2495"
echo "[ ] Install Claude Code"
echo "[ ] Setup voice control (iPad/iPhone)"
echo "[ ] Test all MC96 devices"
echo ""
echo -e "${GREEN}GORUNFREEX1000 - COMPLETE RESTORATION${NC}"
echo ""
