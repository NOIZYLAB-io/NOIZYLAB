#!/bin/bash
#
# GOD_PRE_BACKUP_CHECK.sh
# QUICK VERIFICATION BEFORE BACKUP
# Runs fast to verify system is ready

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}    GOD PRE-BACKUP CHECK - Quick System Verification${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

CHECKS_PASSED=0
CHECKS_FAILED=0
WARNINGS=0

# Check 1: System identity
echo -n "Checking system... "
if [[ "$(hostname -s)" == "GOD" ]] || [[ "$(hostname)" == *"MacStudio"* ]]; then
    echo -e "${GREEN}✓ Running on GOD${NC}"
    ((CHECKS_PASSED++))
else
    echo -e "${YELLOW}⚠ Not running on GOD (detected: $(hostname))${NC}"
    ((WARNINGS++))
fi

# Check 2: User
echo -n "Checking user... "
if [[ "$(whoami)" == "rsp_ms" ]]; then
    echo -e "${GREEN}✓ Correct user (rsp_ms)${NC}"
    ((CHECKS_PASSED++))
else
    echo -e "${YELLOW}⚠ Running as $(whoami) (expected: rsp_ms)${NC}"
    ((WARNINGS++))
fi

# Check 3: Disk space
echo -n "Checking main drive space... "
MAIN_AVAIL=$(df -h / | tail -1 | awk '{print $4}')
MAIN_USED=$(df -h / | tail -1 | awk '{print $5}' | sed 's/%//')
if [[ $MAIN_USED -lt 95 ]]; then
    echo -e "${GREEN}✓ Available: $MAIN_AVAIL${NC}"
    ((CHECKS_PASSED++))
else
    echo -e "${RED}✗ Disk almost full (${MAIN_USED}% used)${NC}"
    ((CHECKS_FAILED++))
fi

# Check 4: Critical user directories
echo -n "Checking user directories... "
MISSING_DIRS=()
for DIR in "Desktop" "Documents" "NOIZYLAB"; do
    if [[ ! -d "/Users/rsp_ms/$DIR" ]]; then
        MISSING_DIRS+=("$DIR")
    fi
done
if [[ ${#MISSING_DIRS[@]} -eq 0 ]]; then
    echo -e "${GREEN}✓ All critical dirs present${NC}"
    ((CHECKS_PASSED++))
else
    echo -e "${YELLOW}⚠ Missing: ${MISSING_DIRS[*]}${NC}"
    ((WARNINGS++))
fi

# Check 5: External drives
echo ""
echo -e "${CYAN}External drives:${NC}"
EXTERNAL_COUNT=0
for VOL in $(ls /Volumes/ 2>/dev/null | grep -v "Macintosh HD"); do
    AVAIL=$(df -h "/Volumes/$VOL" 2>/dev/null | tail -1 | awk '{print $4}')
    echo -e "  ${GREEN}→${NC} $VOL - Available: $AVAIL"
    ((EXTERNAL_COUNT++))
done

if [[ $EXTERNAL_COUNT -eq 0 ]]; then
    echo -e "${RED}✗ No external drives mounted${NC}"
    echo "  Connect at least one drive for backup destination"
    ((CHECKS_FAILED++))
else
    echo -e "${GREEN}✓ $EXTERNAL_COUNT external drive(s) available${NC}"
    ((CHECKS_PASSED++))
fi

# Check 6: Network status (MC96)
echo ""
echo -n "Checking MC96 network... "
if ping -c 1 -t 1 10.90.90.90 &>/dev/null; then
    echo -e "${GREEN}✓ MC96 switch online (10.90.90.90)${NC}"
    ((CHECKS_PASSED++))
else
    echo -e "${YELLOW}⚠ MC96 switch not responding${NC}"
    ((WARNINGS++))
fi

# Summary
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Passed: $CHECKS_PASSED${NC} | ${YELLOW}Warnings: $WARNINGS${NC} | ${RED}Failed: $CHECKS_FAILED${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

if [[ $CHECKS_FAILED -gt 0 ]]; then
    echo -e "${RED}⚠ CRITICAL ISSUES DETECTED${NC}"
    echo "Fix the failed checks before proceeding with backup."
    echo ""
    exit 1
elif [[ $WARNINGS -gt 0 ]]; then
    echo -e "${YELLOW}⚠ System ready with warnings${NC}"
    echo "Review warnings above. You may proceed with backup."
    echo ""
    exit 0
else
    echo -e "${GREEN}✓ ALL CHECKS PASSED - READY FOR BACKUP${NC}"
    echo ""
    echo "Run: ./GOD_COMPLETE_BACKUP_REFORMAT.sh"
    echo ""
    exit 0
fi
