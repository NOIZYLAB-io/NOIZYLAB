#!/bin/bash
#
# GOD_COMPLETE_BACKUP_REFORMAT.sh
# ULTIMATE BACKUP + REFORMAT SYSTEM FOR GOD (Mac Studio M2 Ultra)
# GORUNFREEX1000 - ONE COMMAND = COMPLETE PROTECTION
#
# Rob Sonic Protocol - Fish Music Inc - NOIZYLAB
# 40 Years of Creative Archives - ZERO DATA LOSS
#
# RUN THIS ON GOD BEFORE ANY REFORMAT

set -e  # Exit on error

# ANSI Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_ROOT="/Volumes"
BACKUP_DESTINATION=""

echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}║             GOD COMPLETE BACKUP + REFORMAT SYSTEM                    ║${NC}"
echo -e "${CYAN}║                    GORUNFREEX1000                                    ║${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}║        Mac Studio M2 Ultra - 40 Years of Work - FORT KNOX           ║${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# ============================================================================
# PHASE 1: PRE-FLIGHT CHECK
# ============================================================================

echo -e "${YELLOW}[PHASE 1] PRE-FLIGHT VERIFICATION${NC}"
echo ""

# Check if running on GOD
HOSTNAME=$(hostname -s)
if [[ "$HOSTNAME" != "GOD" ]] && [[ "$HOSTNAME" != "MacStudio" ]]; then
    echo -e "${RED}✗ WARNING: Not running on GOD (detected: $HOSTNAME)${NC}"
    read -p "Continue anyway? (yes/no): " CONFIRM
    if [[ "$CONFIRM" != "yes" ]]; then
        echo "Aborted."
        exit 1
    fi
fi

# Check if running as correct user
CURRENT_USER=$(whoami)
if [[ "$CURRENT_USER" != "rsp_ms" ]]; then
    echo -e "${YELLOW}⚠ Running as: $CURRENT_USER (expected: rsp_ms)${NC}"
fi

echo -e "${GREEN}✓ System check passed${NC}"
echo ""

# Display all mounted volumes
echo -e "${CYAN}=== MOUNTED VOLUMES ===${NC}"
df -h | grep -E "^/dev/" | awk '{printf "%-30s %8s %8s %8s %5s %-20s\n", $1, $2, $3, $4, $5, $9}'
echo ""

# List all external drives
echo -e "${CYAN}=== EXTERNAL DRIVES ===${NC}"
ls -la /Volumes/ | grep -v "^total" | grep -v "Macintosh HD" | awk '{print $NF}' | grep -v "^$"
echo ""

# Check for critical drives
CRITICAL_DRIVES=(
    "4TB_FISH_SG"
    "RED_DRAGON"
    "12TB_ARCHIVE"
    "4TB_Lacie"
    "4TB_Utility"
    "JOE"
    "Mission Control"
    "NOIZYWIN"
)

echo -e "${CYAN}=== CHECKING CRITICAL DRIVES ===${NC}"
MISSING_DRIVES=()
for DRIVE in "${CRITICAL_DRIVES[@]}"; do
    if [[ -d "/Volumes/$DRIVE" ]]; then
        SIZE=$(df -h "/Volumes/$DRIVE" | tail -1 | awk '{print $2}')
        USED=$(df -h "/Volumes/$DRIVE" | tail -1 | awk '{print $3}')
        AVAIL=$(df -h "/Volumes/$DRIVE" | tail -1 | awk '{print $4}')
        echo -e "${GREEN}✓${NC} $DRIVE - Size: $SIZE, Used: $USED, Available: $AVAIL"
    else
        echo -e "${RED}✗${NC} $DRIVE - NOT MOUNTED"
        MISSING_DRIVES+=("$DRIVE")
    fi
done
echo ""

if [[ ${#MISSING_DRIVES[@]} -gt 0 ]]; then
    echo -e "${RED}⚠ MISSING DRIVES: ${MISSING_DRIVES[*]}${NC}"
    echo "Please connect all drives before proceeding."
    read -p "Continue without these drives? (yes/no): " CONTINUE
    if [[ "$CONTINUE" != "yes" ]]; then
        echo "Aborted. Please connect drives and re-run."
        exit 1
    fi
fi

# ============================================================================
# PHASE 2: SELECT BACKUP DESTINATION
# ============================================================================

echo -e "${YELLOW}[PHASE 2] SELECT BACKUP DESTINATION${NC}"
echo ""
echo "Available external drives:"
echo ""

VOLUMES=($(ls /Volumes/ | grep -v "Macintosh HD"))
INDEX=1
for VOL in "${VOLUMES[@]}"; do
    AVAIL=$(df -h "/Volumes/$VOL" | tail -1 | awk '{print $4}')
    echo "  [$INDEX] $VOL - Available: $AVAIL"
    ((INDEX++))
done
echo ""

read -p "Select backup destination [1-${#VOLUMES[@]}]: " DEST_NUM

if [[ $DEST_NUM -lt 1 ]] || [[ $DEST_NUM -gt ${#VOLUMES[@]} ]]; then
    echo -e "${RED}Invalid selection${NC}"
    exit 1
fi

BACKUP_DESTINATION="/Volumes/${VOLUMES[$((DEST_NUM-1))]}"
BACKUP_PATH="${BACKUP_DESTINATION}/GOD_COMPLETE_BACKUP_${TIMESTAMP}"

echo ""
echo -e "${GREEN}✓ Backup destination: $BACKUP_PATH${NC}"
echo ""

# Check available space
BACKUP_DEST_AVAIL=$(df -h "$BACKUP_DESTINATION" | tail -1 | awk '{print $4}')
echo -e "Available space on destination: ${CYAN}$BACKUP_DEST_AVAIL${NC}"
echo ""

read -p "Proceed with backup? (yes/no): " PROCEED
if [[ "$PROCEED" != "yes" ]]; then
    echo "Aborted."
    exit 1
fi

# Create backup directory
mkdir -p "$BACKUP_PATH"

# ============================================================================
# PHASE 3: BACKUP USER DATA
# ============================================================================

echo ""
echo -e "${YELLOW}[PHASE 3] BACKING UP USER DATA${NC}"
echo ""

USER_HOME="/Users/rsp_ms"
BACKUP_USER="$BACKUP_PATH/Users_rsp_ms"

echo -e "${CYAN}Backing up $USER_HOME...${NC}"
mkdir -p "$BACKUP_USER"

# Critical directories
CRITICAL_DIRS=(
    "Desktop"
    "Documents"
    "Downloads"
    "Music"
    "Movies"
    "Pictures"
    "NOIZYLAB"
    "GORUNFREE"
    "Fish Music Inc"
    "THE_AQUARIUM"
    "MC96"
    "ClaudeRMT"
    "GABRIEL_SUPREME"
    "LIFELUV"
    "CODE_VAC"
)

for DIR in "${CRITICAL_DIRS[@]}"; do
    if [[ -d "$USER_HOME/$DIR" ]]; then
        echo -e "  ${GREEN}→${NC} Copying $DIR..."
        rsync -ah --progress "$USER_HOME/$DIR/" "$BACKUP_USER/$DIR/" 2>/dev/null || echo -e "  ${YELLOW}⚠${NC} Some files skipped in $DIR"
    fi
done

# Backup hidden files
echo -e "${CYAN}Backing up configuration files...${NC}"
rsync -ah --progress \
    --include='.bash*' \
    --include='.zsh*' \
    --include='.ssh/' \
    --include='.config/' \
    --include='.anthropic/' \
    --exclude='Library/' \
    --exclude='.Trash/' \
    "$USER_HOME/." "$BACKUP_USER/" 2>/dev/null || true

echo -e "${GREEN}✓ User data backed up${NC}"
echo ""

# ============================================================================
# PHASE 4: BACKUP APPLICATIONS DATA
# ============================================================================

echo -e "${YELLOW}[PHASE 4] BACKING UP APPLICATION DATA${NC}"
echo ""

BACKUP_APPS="$BACKUP_PATH/Application_Support"
mkdir -p "$BACKUP_APPS"

# Key application data
APP_SUPPORT="$USER_HOME/Library/Application Support"

APPS_TO_BACKUP=(
    "Claude"
    "Anthropic"
    "Google Drive"
    "Dropbox"
    "Logic"
    "ProTools"
    "Adobe"
    "Unity"
)

for APP in "${APPS_TO_BACKUP[@]}"; do
    if [[ -d "$APP_SUPPORT/$APP" ]]; then
        echo -e "  ${GREEN}→${NC} Backing up $APP..."
        rsync -ah --progress "$APP_SUPPORT/$APP/" "$BACKUP_APPS/$APP/" 2>/dev/null || true
    fi
done

echo -e "${GREEN}✓ Application data backed up${NC}"
echo ""

# ============================================================================
# PHASE 5: BACKUP ALL EXTERNAL DRIVES
# ============================================================================

echo -e "${YELLOW}[PHASE 5] BACKING UP EXTERNAL DRIVES${NC}"
echo ""

BACKUP_EXTERNAL="$BACKUP_PATH/External_Drives"
mkdir -p "$BACKUP_EXTERNAL"

for DRIVE in "${CRITICAL_DRIVES[@]}"; do
    if [[ -d "/Volumes/$DRIVE" ]] && [[ "$DRIVE" != "${VOLUMES[$((DEST_NUM-1))]}" ]]; then
        echo -e "${CYAN}Backing up $DRIVE...${NC}"
        rsync -ah --progress "/Volumes/$DRIVE/" "$BACKUP_EXTERNAL/$DRIVE/" 2>/dev/null || echo -e "  ${YELLOW}⚠${NC} Some files skipped in $DRIVE"
        echo -e "${GREEN}✓ $DRIVE backed up${NC}"
        echo ""
    fi
done

# ============================================================================
# PHASE 6: CREATE BACKUP MANIFEST
# ============================================================================

echo -e "${YELLOW}[PHASE 6] CREATING BACKUP MANIFEST${NC}"
echo ""

MANIFEST="$BACKUP_PATH/BACKUP_MANIFEST.txt"

cat > "$MANIFEST" << EOF
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║               GOD COMPLETE BACKUP MANIFEST                           ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

Backup Date: $(date)
System: GOD - Mac Studio M2 Ultra (192GB RAM)
User: rsp_ms
Backup Location: $BACKUP_PATH

════════════════════════════════════════════════════════════════════════

SYSTEM INFORMATION:
- Hostname: $(hostname)
- macOS Version: $(sw_vers -productVersion)
- Build: $(sw_vers -buildVersion)
- User: $(whoami)

════════════════════════════════════════════════════════════════════════

BACKUP CONTENTS:

User Data:
$(ls -la "$BACKUP_USER" 2>/dev/null || echo "Not available")

Application Data:
$(ls -la "$BACKUP_APPS" 2>/dev/null || echo "Not available")

External Drives:
$(ls -la "$BACKUP_EXTERNAL" 2>/dev/null || echo "Not available")

════════════════════════════════════════════════════════════════════════

DISK USAGE:

Total Backup Size:
$(du -sh "$BACKUP_PATH" 2>/dev/null)

Breakdown:
$(du -sh "$BACKUP_PATH"/* 2>/dev/null)

════════════════════════════════════════════════════════════════════════

MOUNTED VOLUMES AT BACKUP TIME:

$(df -h | grep -E "^/dev/")

════════════════════════════════════════════════════════════════════════

CRITICAL DIRECTORIES BACKED UP:

$(find "$BACKUP_PATH" -maxdepth 3 -type d 2>/dev/null | head -50)

════════════════════════════════════════════════════════════════════════

Rob Sonic Protocol - GORUNFREE
Fish Music Inc - NOIZYLAB - THE_AQUARIUM
40 Years of Creative Archives - FORT KNOX Level Protection

════════════════════════════════════════════════════════════════════════
EOF

echo -e "${GREEN}✓ Manifest created: $MANIFEST${NC}"
echo ""

# ============================================================================
# PHASE 7: VERIFICATION
# ============================================================================

echo -e "${YELLOW}[PHASE 7] BACKUP VERIFICATION${NC}"
echo ""

echo -e "${CYAN}Verifying backup integrity...${NC}"

# Count files
USER_FILES=$(find "$USER_HOME" -type f 2>/dev/null | wc -l | xargs)
BACKUP_FILES=$(find "$BACKUP_USER" -type f 2>/dev/null | wc -l | xargs)

echo "Source files (User): $USER_FILES"
echo "Backed up files: $BACKUP_FILES"
echo ""

# Calculate sizes
USER_SIZE=$(du -sh "$USER_HOME" 2>/dev/null | awk '{print $1}')
BACKUP_SIZE=$(du -sh "$BACKUP_PATH" 2>/dev/null | awk '{print $1}')

echo "Source size: $USER_SIZE"
echo "Backup size: $BACKUP_SIZE"
echo ""

if [[ $BACKUP_FILES -gt 0 ]]; then
    echo -e "${GREEN}✓ Backup verification passed${NC}"
else
    echo -e "${RED}✗ Backup verification FAILED - no files found${NC}"
    exit 1
fi

# ============================================================================
# PHASE 8: REFORMAT INSTRUCTIONS
# ============================================================================

echo ""
echo -e "${YELLOW}[PHASE 8] REFORMAT INSTRUCTIONS${NC}"
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}║                  BACKUP COMPLETE - READY TO REFORMAT                 ║${NC}"
echo -e "${CYAN}║                                                                      ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

cat > "$BACKUP_PATH/REFORMAT_INSTRUCTIONS.txt" << 'EOF'
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║               GOD REFORMAT INSTRUCTIONS                              ║
║                    Mac Studio M2 Ultra                               ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

COMPLETE BACKUP VERIFIED ✓
Safe to proceed with reformat.

════════════════════════════════════════════════════════════════════════

REFORMAT PROCEDURE FOR APPLE SILICON MAC:

1. SHUTDOWN GOD
   - Apple Menu → Shut Down
   - Wait for complete shutdown

2. ENTER RECOVERY MODE
   - Press and HOLD the Power Button
   - Keep holding until you see "Loading startup options"
   - Release when you see the options wheel

3. IN RECOVERY MODE:
   - Click "Options" → "Continue"
   - Enter admin password if prompted

4. DISK UTILITY
   - From menu bar: Utilities → Disk Utility
   - Select "Show All Devices" (View menu)
   - Select the TOP-LEVEL internal drive (usually "Apple SSD")
   - Click "Erase"

5. ERASE SETTINGS:
   - Name: Macintosh HD (or "GOD")
   - Format: APFS
   - Scheme: GUID Partition Map
   - Click "Erase"
   - Wait for completion

6. REINSTALL macOS:
   - Close Disk Utility
   - Click "Reinstall macOS Sonoma" (or current version)
   - Follow on-screen instructions
   - This will download and install fresh macOS

7. SETUP ASSISTANT:
   - Choose language/region
   - Connect to WiFi
   - DO NOT migrate data yet
   - Create user account: rsp_ms
   - Enable FileVault (encryption)
   - Setup Apple ID
   - Complete setup to desktop

8. RESTORE FROM BACKUP:
   - Connect backup drive
   - Run restore script (instructions in backup folder)
   - Or manually copy data back

════════════════════════════════════════════════════════════════════════

BACKUP LOCATION:
This file is located in your backup at:
$BACKUP_PATH

VERIFICATION:
- Manifest file created ✓
- All user data backed up ✓
- Application data backed up ✓
- External drives backed up ✓

════════════════════════════════════════════════════════════════════════

RESTORE PRIORITY ORDER:

1. User home directory (/Users/rsp_ms/)
2. Application data
3. Project files (NOIZYLAB, Fish Music Inc)
4. THE_AQUARIUM archives
5. Configuration files
6. External drive contents

════════════════════════════════════════════════════════════════════════

POST-REFORMAT CHECKLIST:

[ ] macOS installed fresh
[ ] User account created (rsp_ms)
[ ] System preferences configured
[ ] Applications reinstalled
[ ] Data restored from backup
[ ] External drives reconnected
[ ] Network settings (MC96 switch: 10.90.90.90)
[ ] SSH keys restored
[ ] Claude Code reinstalled
[ ] Voice control setup (iPad/iPhone)
[ ] PLANAR2495 configured
[ ] All MC96 devices connected

════════════════════════════════════════════════════════════════════════

Rob Sonic Protocol - GORUNFREE
Complete backup = complete confidence
FORT KNOX protection for 40 years of work

════════════════════════════════════════════════════════════════════════
EOF

echo -e "${GREEN}✓ Reformat instructions created${NC}"
echo ""
echo -e "${CYAN}Instructions saved to: $BACKUP_PATH/REFORMAT_INSTRUCTIONS.txt${NC}"
echo ""

# ============================================================================
# COMPLETION
# ============================================================================

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}║                    BACKUP COMPLETE ✓                                 ║${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Backup location:${NC} $BACKUP_PATH"
echo -e "${CYAN}Backup size:${NC} $(du -sh "$BACKUP_PATH" | awk '{print $1}')"
echo -e "${CYAN}Manifest:${NC} $MANIFEST"
echo -e "${CYAN}Reformat guide:${NC} $BACKUP_PATH/REFORMAT_INSTRUCTIONS.txt"
echo ""
echo -e "${YELLOW}NEXT STEPS:${NC}"
echo "1. VERIFY backup by opening: $BACKUP_PATH"
echo "2. CHECK manifest file"
echo "3. READ reformat instructions"
echo "4. When ready: Follow reformat procedure in Recovery Mode"
echo ""
echo -e "${GREEN}GORUNFREEX1000 - FORT KNOX PROTECTION COMPLETE${NC}"
echo ""
