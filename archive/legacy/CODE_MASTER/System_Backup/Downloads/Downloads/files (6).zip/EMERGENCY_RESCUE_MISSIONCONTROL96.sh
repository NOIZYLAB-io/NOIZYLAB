#!/bin/bash
#
# EMERGENCY_RESCUE_MISSIONCONTROL96.sh
# CRITICAL DATA EXTRACTION - CORRUPTED USER ACCOUNT
# GORUNFREEX1000 - ONE COMMAND = COMPLETE RESCUE
#
# Target: /Users/rsp_ms/Desktop/MissionControl96
# 2.8TB - 40 Years of Work - ZERO LOSS TOLERANCE
#
# RUN FROM RECOVERY MODE OR AS ROOT

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

clear

echo -e "${RED}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║                                                                      ║${NC}"
echo -e "${RED}║              ⚠️  EMERGENCY DATA RESCUE  ⚠️                            ║${NC}"
echo -e "${RED}║                                                                      ║${NC}"
echo -e "${RED}║           MissionControl96 - 2.8TB - 40 Years of Work                ║${NC}"
echo -e "${RED}║                  USER ACCOUNT CORRUPTED                              ║${NC}"
echo -e "${RED}║                                                                      ║${NC}"
echo -e "${RED}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}CRITICAL: This script extracts data from corrupted user account${NC}"
echo -e "${YELLOW}Target: MissionControl96 ghost drive on Desktop${NC}"
echo ""

# Timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESCUE_FOLDER="MC96_RESCUE_${TIMESTAMP}"

# ============================================================================
# PHASE 1: LOCATE SOURCE
# ============================================================================

echo -e "${CYAN}[PHASE 1] LOCATING MISSIONCONTROL96${NC}"
echo ""

# Possible locations for corrupted account
POSSIBLE_SOURCES=(
    "/Users/rsp_ms/Desktop/MissionControl96"
    "/Users/rsp_ms/MissionControl96"
    "/Users/*/Desktop/MissionControl96"
    "/Volumes/Macintosh HD/Users/rsp_ms/Desktop/MissionControl96"
    "/Volumes/*/Users/rsp_ms/Desktop/MissionControl96"
)

SOURCE_PATH=""
for PATH_CHECK in "${POSSIBLE_SOURCES[@]}"; do
    if [[ -d "$PATH_CHECK" ]]; then
        SOURCE_PATH="$PATH_CHECK"
        echo -e "${GREEN}✓ FOUND: $SOURCE_PATH${NC}"
        break
    fi
done

if [[ -z "$SOURCE_PATH" ]]; then
    echo -e "${RED}✗ MissionControl96 not found at expected locations${NC}"
    echo ""
    echo "Searching entire system (this may take a moment)..."
    SOURCE_PATH=$(find /Users /Volumes -name "MissionControl96" -type d 2>/dev/null | head -1)
    
    if [[ -n "$SOURCE_PATH" ]]; then
        echo -e "${GREEN}✓ FOUND: $SOURCE_PATH${NC}"
    else
        echo -e "${RED}✗ CRITICAL: Cannot locate MissionControl96${NC}"
        echo ""
        echo "Available user directories:"
        ls -la /Users/
        echo ""
        echo "Please manually locate MissionControl96 and update script."
        exit 1
    fi
fi

# Check size
echo ""
echo -e "${CYAN}Checking source size...${NC}"
SOURCE_SIZE=$(du -sh "$SOURCE_PATH" 2>/dev/null | awk '{print $1}')
SOURCE_SIZE_BYTES=$(du -s "$SOURCE_PATH" 2>/dev/null | awk '{print $1}')
SOURCE_FILES=$(find "$SOURCE_PATH" -type f 2>/dev/null | wc -l | xargs)

echo -e "${WHITE}Source: $SOURCE_PATH${NC}"
echo -e "${WHITE}Size: $SOURCE_SIZE${NC}"
echo -e "${WHITE}Files: $SOURCE_FILES${NC}"
echo ""

if [[ $SOURCE_FILES -eq 0 ]]; then
    echo -e "${RED}✗ No files found in source - may be inaccessible${NC}"
    echo ""
    echo "Attempting to access with elevated permissions..."
fi

# ============================================================================
# PHASE 2: SELECT DESTINATION
# ============================================================================

echo -e "${CYAN}[PHASE 2] SELECT RESCUE DESTINATION${NC}"
echo ""
echo "Available external drives:"
echo ""

VOLUMES=($(ls /Volumes/ 2>/dev/null | grep -v "Macintosh HD" | grep -v "^$"))
if [[ ${#VOLUMES[@]} -eq 0 ]]; then
    echo -e "${RED}✗ NO EXTERNAL DRIVES DETECTED${NC}"
    echo ""
    echo -e "${YELLOW}CRITICAL: You must connect an external drive for rescue!${NC}"
    echo "Need: 3TB+ free space recommended"
    echo ""
    read -p "Press Enter after connecting drive, or Ctrl+C to abort..."
    
    # Re-scan for volumes
    VOLUMES=($(ls /Volumes/ 2>/dev/null | grep -v "Macintosh HD" | grep -v "^$"))
    if [[ ${#VOLUMES[@]} -eq 0 ]]; then
        echo -e "${RED}✗ Still no external drives detected${NC}"
        exit 1
    fi
fi

INDEX=1
for VOL in "${VOLUMES[@]}"; do
    AVAIL=$(df -h "/Volumes/$VOL" 2>/dev/null | tail -1 | awk '{print $4}')
    AVAIL_BYTES=$(df -k "/Volumes/$VOL" 2>/dev/null | tail -1 | awk '{print $4}')
    
    # Check if enough space
    ENOUGH_SPACE=""
    if [[ $AVAIL_BYTES -gt 3000000000 ]]; then  # 3TB in KB
        ENOUGH_SPACE="${GREEN}✓ Enough space${NC}"
    else
        ENOUGH_SPACE="${YELLOW}⚠ May be tight${NC}"
    fi
    
    echo -e "  [$INDEX] $VOL - Available: $AVAIL - $ENOUGH_SPACE"
    ((INDEX++))
done
echo ""

read -p "Select rescue destination [1-${#VOLUMES[@]}]: " DEST_NUM

if [[ $DEST_NUM -lt 1 ]] || [[ $DEST_NUM -gt ${#VOLUMES[@]} ]]; then
    echo -e "${RED}Invalid selection${NC}"
    exit 1
fi

DEST_VOLUME="/Volumes/${VOLUMES[$((DEST_NUM-1))]}"
DEST_PATH="$DEST_VOLUME/$RESCUE_FOLDER"

echo ""
echo -e "${GREEN}✓ Rescue destination: $DEST_PATH${NC}"
echo ""

# Verify space
DEST_AVAIL=$(df -h "$DEST_VOLUME" | tail -1 | awk '{print $4}')
echo -e "Destination available: ${CYAN}$DEST_AVAIL${NC}"
echo -e "Source size: ${CYAN}$SOURCE_SIZE${NC}"
echo ""

read -p "Proceed with rescue? (yes/no): " PROCEED
if [[ "$PROCEED" != "yes" ]]; then
    echo "Aborted."
    exit 1
fi

# Create rescue directory
mkdir -p "$DEST_PATH"

# ============================================================================
# PHASE 3: EMERGENCY DATA EXTRACTION
# ============================================================================

echo ""
echo -e "${RED}[PHASE 3] EMERGENCY DATA EXTRACTION${NC}"
echo ""
echo -e "${YELLOW}Extracting MissionControl96...${NC}"
echo -e "${YELLOW}This may take 1-4 hours for 2.8TB${NC}"
echo ""

# Log file
LOG_FILE="$DEST_PATH/RESCUE_LOG.txt"
touch "$LOG_FILE"

echo "═══════════════════════════════════════════════════════════════════════" | tee -a "$LOG_FILE"
echo "EMERGENCY RESCUE LOG" | tee -a "$LOG_FILE"
echo "Started: $(date)" | tee -a "$LOG_FILE"
echo "Source: $SOURCE_PATH" | tee -a "$LOG_FILE"
echo "Destination: $DEST_PATH" | tee -a "$LOG_FILE"
echo "═══════════════════════════════════════════════════════════════════════" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Try rsync first (preserves everything)
echo -e "${CYAN}Using rsync for maximum data integrity...${NC}"
echo ""

# Rsync with options:
# -a = archive mode (preserve permissions, times, ownership)
# -h = human readable
# -v = verbose
# -P = progress + partial (resume if interrupted)
# --stats = show statistics
# -x = don't cross filesystem boundaries
# --ignore-errors = continue on errors

sudo rsync -ahvP --stats --ignore-errors -x \
    "$SOURCE_PATH/" "$DEST_PATH/MissionControl96/" 2>&1 | tee -a "$LOG_FILE"

RSYNC_EXIT=$?

echo "" | tee -a "$LOG_FILE"
echo "Rsync completed with exit code: $RSYNC_EXIT" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# ============================================================================
# PHASE 4: VERIFICATION
# ============================================================================

echo -e "${CYAN}[PHASE 4] VERIFICATION${NC}"
echo ""

echo -e "${YELLOW}Verifying rescued data...${NC}"
echo ""

# Count files
RESCUED_FILES=$(find "$DEST_PATH/MissionControl96" -type f 2>/dev/null | wc -l | xargs)
RESCUED_SIZE=$(du -sh "$DEST_PATH/MissionControl96" 2>/dev/null | awk '{print $1}')

echo "Source files: $SOURCE_FILES" | tee -a "$LOG_FILE"
echo "Rescued files: $RESCUED_FILES" | tee -a "$LOG_FILE"
echo "Source size: $SOURCE_SIZE" | tee -a "$LOG_FILE"
echo "Rescued size: $RESCUED_SIZE" | tee -a "$LOG_FILE"
echo ""

if [[ $RESCUED_FILES -gt 0 ]]; then
    PERCENT=$((RESCUED_FILES * 100 / SOURCE_FILES))
    echo -e "${GREEN}✓ Rescue success: $RESCUED_FILES files ($PERCENT% of source)${NC}" | tee -a "$LOG_FILE"
    
    if [[ $PERCENT -lt 95 ]]; then
        echo -e "${YELLOW}⚠ Warning: Not all files copied (${PERCENT}%)${NC}" | tee -a "$LOG_FILE"
        echo "This may be due to permissions or corrupted files." | tee -a "$LOG_FILE"
    fi
else
    echo -e "${RED}✗ RESCUE FAILED - No files copied${NC}" | tee -a "$LOG_FILE"
    echo "Check permissions and source accessibility." | tee -a "$LOG_FILE"
    exit 1
fi

# ============================================================================
# PHASE 5: CREATE RESCUE MANIFEST
# ============================================================================

echo ""
echo -e "${CYAN}[PHASE 5] CREATING RESCUE MANIFEST${NC}"
echo ""

MANIFEST="$DEST_PATH/RESCUE_MANIFEST.txt"

cat > "$MANIFEST" << EOF
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║          EMERGENCY MISSIONCONTROL96 RESCUE MANIFEST                  ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

CRITICAL DATA EXTRACTION - CORRUPTED USER ACCOUNT

Rescue Date: $(date)
System: GOD - Mac Studio M2 Ultra (192GB RAM)
User: rsp_ms (CORRUPTED ACCOUNT)
Rescue Location: $DEST_PATH

════════════════════════════════════════════════════════════════════════

SOURCE INFORMATION:
- Path: $SOURCE_PATH
- Size: $SOURCE_SIZE
- Files: $SOURCE_FILES files
- Status: Extracted from corrupted user account

RESCUED DATA:
- Path: $DEST_PATH/MissionControl96
- Size: $RESCUED_SIZE
- Files: $RESCUED_FILES files
- Success Rate: $((RESCUED_FILES * 100 / SOURCE_FILES))%

════════════════════════════════════════════════════════════════════════

RESCUE DETAILS:

Method: rsync (archive mode)
Permissions: Preserved
Timestamps: Preserved
Ownership: Preserved
Errors: Logged (see RESCUE_LOG.txt)

════════════════════════════════════════════════════════════════════════

DIRECTORY STRUCTURE:

$(find "$DEST_PATH/MissionControl96" -maxdepth 2 -type d 2>/dev/null | head -30)

════════════════════════════════════════════════════════════════════════

TOP-LEVEL CONTENTS:

$(ls -lah "$DEST_PATH/MissionControl96/" 2>/dev/null | head -50)

════════════════════════════════════════════════════════════════════════

FILE TYPES RESCUED:

$(find "$DEST_PATH/MissionControl96" -type f 2>/dev/null | sed 's/.*\.//' | sort | uniq -c | sort -rn | head -20)

════════════════════════════════════════════════════════════════════════

LARGEST FILES:

$(find "$DEST_PATH/MissionControl96" -type f -exec ls -lh {} \; 2>/dev/null | sort -k5 -hr | head -20 | awk '{printf "%-10s %s\n", $5, $9}')

════════════════════════════════════════════════════════════════════════

CRITICAL NOTES:

✓ This is a COMPLETE COPY of MissionControl96
✓ Source remains intact (read-only operation)
✓ Safe to reformat GOD after verification
✓ 40 years of creative work RESCUED
✓ THE_AQUARIUM data preserved

⚠ VERIFICATION REQUIRED:
1. Open rescued folder and spot-check files
2. Verify critical projects are accessible
3. Check file dates and sizes match expectations
4. Confirm no corruption in rescued files

════════════════════════════════════════════════════════════════════════

NEXT STEPS:

1. VERIFY rescued data (open files, check integrity)
2. Keep this rescue drive SAFE and DISCONNECTED during reformat
3. After GOD reformat, copy data back to proper location
4. Maintain multiple backups (FORT KNOX protocol)
5. Run full GOD backup script for complete system backup

════════════════════════════════════════════════════════════════════════

Rob Sonic Protocol - GORUNFREE
Fish Music Inc - NOIZYLAB - THE_AQUARIUM
Emergency Rescue - FORT KNOX Protection
40 Years of Work - ZERO DATA LOSS

════════════════════════════════════════════════════════════════════════

Rescue completed: $(date)
Status: SUCCESS
Files rescued: $RESCUED_FILES
Total size: $RESCUED_SIZE

════════════════════════════════════════════════════════════════════════
EOF

echo -e "${GREEN}✓ Manifest created: $MANIFEST${NC}"
echo ""

# ============================================================================
# PHASE 6: POST-RESCUE INSTRUCTIONS
# ============================================================================

echo -e "${CYAN}[PHASE 6] POST-RESCUE INSTRUCTIONS${NC}"
echo ""

cat > "$DEST_PATH/POST_RESCUE_INSTRUCTIONS.txt" << 'EOF'
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║              POST-RESCUE INSTRUCTIONS                                ║
║         MissionControl96 Successfully Extracted                      ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝

✓ RESCUE COMPLETE
✓ DATA SAFE ON THIS DRIVE
✓ READY TO PROCEED WITH REFORMAT

════════════════════════════════════════════════════════════════════════

IMMEDIATE ACTIONS:

1. VERIFY RESCUED DATA
   - Open: MissionControl96 folder
   - Spot-check: Random files from different years
   - Confirm: Files open correctly
   - Check: File sizes seem correct

2. KEEP THIS DRIVE SAFE
   - DO NOT disconnect during verification
   - DO NOT write new data to this drive yet
   - Keep in safe location during reformat
   - This is your ONLY copy until reformat complete

3. OPTIONAL: CREATE SECOND BACKUP
   - Copy this entire rescue folder to another drive
   - FORT KNOX = minimum 2 copies
   - Better safe than sorry with 40 years of work

════════════════════════════════════════════════════════════════════════

REFORMAT GOD (After verification):

1. Run full backup script:
   ./GOD_COMPLETE_BACKUP_REFORMAT.sh
   (This backs up EVERYTHING else on GOD)

2. Follow reformat procedure (provided in backup)

3. After fresh macOS install:
   - Create user: rsp_ms
   - Run restore script
   - Copy MissionControl96 back to proper location

════════════════════════════════════════════════════════════════════════

WHERE TO PUT MISSIONCONTROL96 AFTER REFORMAT:

Recommended locations:
- /Users/rsp_ms/Desktop/MissionControl96 (original location)
- /Users/rsp_ms/THE_AQUARIUM/MissionControl96 (archive location)
- External drive for long-term storage

DO NOT keep only on internal drive - maintain external backup!

════════════════════════════════════════════════════════════════════════

VERIFICATION CHECKLIST:

[ ] Opened rescue folder successfully
[ ] Random files open correctly
[ ] File count seems reasonable
[ ] File sizes look correct
[ ] No obvious corruption
[ ] Read manifest file
[ ] Read rescue log
[ ] Created second backup (optional but recommended)

Ready to proceed with full GOD backup + reformat? YES / NO

════════════════════════════════════════════════════════════════════════

Rob Sonic Protocol - GORUNFREE
Emergency rescue complete - Data safe
Proceed with confidence

════════════════════════════════════════════════════════════════════════
EOF

echo -e "${GREEN}✓ Instructions created${NC}"
echo ""

# ============================================================================
# COMPLETION
# ============================================================================

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}║              ✓ EMERGENCY RESCUE COMPLETE ✓                           ║${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}║         MissionControl96 - 40 Years - SAFE                           ║${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Rescue location:${NC} $DEST_PATH"
echo -e "${CYAN}Files rescued:${NC} $RESCUED_FILES"
echo -e "${CYAN}Total size:${NC} $RESCUED_SIZE"
echo ""
echo -e "${CYAN}Manifest:${NC} $MANIFEST"
echo -e "${CYAN}Log file:${NC} $LOG_FILE"
echo -e "${CYAN}Instructions:${NC} $DEST_PATH/POST_RESCUE_INSTRUCTIONS.txt"
echo ""
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}CRITICAL NEXT STEPS:${NC}"
echo ""
echo "1. VERIFY rescued data - open files and check"
echo "2. Keep this drive SAFE during reformat"
echo "3. Run full GOD backup: ./GOD_COMPLETE_BACKUP_REFORMAT.sh"
echo "4. Then proceed with reformat"
echo ""
echo -e "${GREEN}YOUR 40 YEARS OF WORK IS SAFE ✓${NC}"
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""
