# VOICE-FRIENDLY SETUP INSTRUCTIONS
## Automated DNS Fix for fishmusicinc.com

---

## WHAT THIS DOES

**ONE command fixes everything automatically:**
- Updates SPF record (removes old hosting)
- Upgrades DMARC security
- Deletes old junk records
- **NO clicking required** - all automated

---

## ONE-TIME SETUP (Get API Token)

You need a Cloudflare API token **once**. After that, everything is automated.

### GET TOKEN (Voice assistance recommended):

1. **Say to voice assistant:** "Open Cloudflare API tokens page"
   - URL: https://dash.cloudflare.com/profile/api-tokens

2. **Click once:** "Create Token" button

3. **Click once:** "Use template" next to "Edit zone DNS"

4. **Under "Zone Resources":**
   - Zone: Select "fishmusicinc.com"

5. **Click once:** "Continue to summary"

6. **Click once:** "Create Token"

7. **Copy the token** (it's shown once - save it!)

8. **In Terminal, say:**
   ```
   export CLOUDFLARE_API_TOKEN='paste_your_token_here'
   ```

**Token is saved - you only do this ONCE.**

---

## EXECUTE THE FIX (One Command)

### In Terminal:

```bash
cd ~/Downloads  # or wherever you saved the script
chmod +x FIX_FISHMUSICINC_DNS.sh
./FIX_FISHMUSICINC_DNS.sh
```

**Script runs automatically - fixes everything in 10 seconds.**

---

## WHAT IT FIXES

✅ **SPF Record:**
- Old: `v=spf1 include:_spf.webador.com include:_netblocks.google.com...`
- New: `v=spf1 include:_spf.google.com ~all`

✅ **DMARC Record:**
- Old: `v=DMARC1; p=none`
- New: `v=DMARC1; p=quarantine; rua=mailto:rp@fishmusicinc.com`

✅ **Cleanup:**
- Deletes: mandrill._domainkey (old)
- Deletes: _autodiscover._tcp (old)

---

## AFTER THE FIX (Add Google DKIM)

**You'll still need to add Google DKIM** (requires key from Google):

### Get DKIM Key:
1. Voice assistant: "Open Google Admin Console"
   - URL: https://admin.google.com
2. Navigate: Apps → Gmail → Authenticate email
3. Click: "Generate new record"
4. Copy the long TXT value

### Add to Cloudflare:
```bash
./ADD_GOOGLE_DKIM.sh
# Paste the DKIM value when prompted
```

**Script adds it automatically.**

---

## ALTERNATIVE: GET HELP

If setting up the API token is difficult, you can:

1. **Ask someone to help** get the token (one-time)
2. **Use screen sharing** with a friend/assistant
3. **Tell Claude:** "I need help with the token" and I'll walk you through it

**After token setup, everything else is ONE COMMAND.**

---

## FILES CREATED

**Main Fix Script:**
`/mnt/user-data/outputs/FIX_FISHMUSICINC_DNS.sh`

**DKIM Addition Script:**
`/mnt/user-data/outputs/ADD_GOOGLE_DKIM.sh`

**This Guide:**
`/mnt/user-data/outputs/VOICE_FRIENDLY_SETUP.md`

---

## EXECUTION SUMMARY

**One-time setup:** Get API token (5 min with assistance)
**Automated fix:** Run one command (10 seconds)
**DKIM addition:** Run one command (10 seconds + paste key)

**Total hands-on time:** ~2 minutes of typing/pasting
**Everything else:** Automated

---

## NEED HELP?

Tell Claude:
- "Help me get the API token"
- "Run the fix for me"
- "What's the status?"

Claude will guide you through it.

---

**Built for voice-first workflow - minimal manual interaction required.**
