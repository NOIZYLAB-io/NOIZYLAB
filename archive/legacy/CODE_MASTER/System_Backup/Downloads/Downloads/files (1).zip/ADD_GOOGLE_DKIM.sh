#!/bin/bash
###############################################################################
# ADD GOOGLE WORKSPACE DKIM RECORD
# Run after getting DKIM key from Google Workspace Admin Console
###############################################################################

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   ADD GOOGLE WORKSPACE DKIM                                ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Domain and Account
DOMAIN="fishmusicinc.com"
ACCOUNT_ID="5ba03939f87a498d0bbed185ee123946"
API_BASE="https://api.cloudflare.com/client/v4"

# Check for API token
if [ -z "$CLOUDFLARE_API_TOKEN" ]; then
    echo "❌ ERROR: CLOUDFLARE_API_TOKEN not set"
    echo "Run: export CLOUDFLARE_API_TOKEN='your_token_here'"
    exit 1
fi

# Prompt for DKIM key
echo "First, get your DKIM key from Google:"
echo "1. Go to: https://admin.google.com"
echo "2. Apps → Gmail → Authenticate email"
echo "3. Generate DKIM key"
echo "4. Copy the LONG TXT record value"
echo ""
read -p "Paste the DKIM TXT record value here: " DKIM_VALUE

if [ -z "$DKIM_VALUE" ]; then
    echo "❌ No DKIM value provided"
    exit 1
fi

echo ""
echo "✅ DKIM value received"
echo ""

# Get Zone ID
echo "🔍 Finding zone..."
ZONE_RESPONSE=$(curl -s -X GET "${API_BASE}/zones?account.id=${ACCOUNT_ID}&name=${DOMAIN}" \
  -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
  -H "Content-Type: application/json")

ZONE_ID=$(echo "$ZONE_RESPONSE" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    if data.get('success') and data.get('result') and len(data['result']) > 0:
        print(data['result'][0]['id'])
    else:
        print('ERROR')
except:
    print('ERROR')
" 2>/dev/null)

if [ "$ZONE_ID" == "ERROR" ]; then
    echo "❌ Could not find zone"
    exit 1
fi

echo "✅ Zone found"
echo ""

# Add DKIM record
echo "🔧 Adding Google DKIM record..."

ADD_RESPONSE=$(curl -s -X POST "${API_BASE}/zones/${ZONE_ID}/dns_records" \
  -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
  -H "Content-Type: application/json" \
  --data "{
    \"type\": \"TXT\",
    \"name\": \"google._domainkey\",
    \"content\": \"${DKIM_VALUE}\",
    \"proxied\": false,
    \"ttl\": 1
  }")

SUCCESS=$(echo "$ADD_RESPONSE" | python3 -c "import sys, json; print(json.load(sys.stdin).get('success', False))")

if [ "$SUCCESS" == "True" ]; then
    echo "✅ DKIM record added!"
    echo ""
    echo "Next steps:"
    echo "1. Go back to Google Admin Console"
    echo "2. Click 'Start authentication'"
    echo "3. Wait 10 minutes"
    echo "4. Refresh page - should show ✓ Authenticating email"
else
    echo "❌ Failed to add DKIM record"
    ERROR=$(echo "$ADD_RESPONSE" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data.get('errors', [{}])[0].get('message', 'Unknown error'))")
    echo "Error: ${ERROR}"
fi

echo ""
