# INSTAGRAM - COMPLETE SETUP GUIDE
## Fish Music Inc. + NOIZYLAB Visual Brand Strategy

**Platform:** Instagram  
**Priority:** 🔥 HIGH  
**Accounts Needed:** 2 (@fishmusicinc + @noizylab)  
**Time to Set Up:** 20 minutes per account  
**ROI:** Visual portfolio, client discovery, brand awareness

---

## 🎯 DUAL ACCOUNT STRATEGY

### **@fishmusicinc - Fish Music Inc.**
**Purpose:** Professional portfolio, client acquisition
**Tone:** Creative, artistic, behind-the-scenes
**Audience:** Film/TV/game producers, creative directors, audio enthusiasts

### **@noizylab - NOIZYLAB**
**Purpose:** Local service promotion, customer acquisition
**Tone:** Technical, helpful, trustworthy
**Audience:** Local Ottawa/Toronto area, small businesses, tech users

---

## 📋 SETUP CHECKLIST - @FISHMUSICINC

### **Step 1: Create Account (5 min)**

**On Mobile (Easiest):**
1. Download Instagram app
2. Tap "Sign up"
3. Enter email: rp@fishmusicinc.com
4. Create username: **fishmusicinc**
5. Create strong password (save in password manager)
6. Set up name: **Fish Music Inc.**
7. Skip finding contacts (for now)
8. **CRITICAL:** Enable Two-Factor Authentication immediately

**On Desktop:**
1. Go to instagram.com
2. Click "Sign up"
3. Same process as mobile

---

### **Step 2: Profile Setup (10 min)**

**A. Profile Picture:**
- Upload Fish Music Inc. logo
- Size: 320x320px minimum
- Format: PNG or JPG
- **Action:** Create/upload logo

**B. Bio (150 characters max):**
```
🎵 Original Music & Sound Design
🎬 Film | TV | Games | Interactive
🏆 40 Years | Major Credits
📧 rp@fishmusicinc.com
🌐 fishmusicinc.com
```

**Alternative Bio:**
```
Composer & Sound Designer 🎼
Film • TV • Games • Interactive
Ottawa, Canada 🍁
"Always make it sound interesting!"
↓ Portfolio & Contact
```

**C. Link in Bio:**
- Add: https://fishmusicinc.com
- **Pro Tip:** Use Linktree or similar to add multiple links:
  - Website
  - Demo reel (YouTube)
  - Contact form
  - LinkedIn

**D. Profile Type:**
- Switch to "Professional Account"
- Select "Creator" (better analytics than Business for personal brand)
- Category: "Musician/Band" or "Media/News Company"

**E. Contact Options:**
- Add email: rp@fishmusicinc.com
- Add phone (optional): Your business line
- Add address (optional): Ottawa, ON

---

### **Step 3: Initial Content Strategy**

**A. First 9 Posts (The Grid):**
Your first 9 posts create the initial impression. Plan them!

**Grid Layout:**
```
[Post 1]  [Post 2]  [Post 3]
[Post 4]  [Post 5]  [Post 6]
[Post 7]  [Post 8]  [Post 9]
```

**Recommended First 9:**
1. **Studio Shot** - Your workspace, professional setup
2. **Demo Reel Screenshot** - "40 Years of Sound Design"
3. **Major Credit** - Dead Space or big project
4. **Behind-the-Scenes** - Mixing console, working
5. **Quote Graphic** - "Always try new things..."
6. **Client Work** - Project showcase (with permission)
7. **Gear Shot** - Your favorite equipment
8. **Process** - Waveforms, DAW screenshot
9. **Welcome Post** - "Follow for more..."

**B. Content Pillars (Ongoing):**

**1. Portfolio Showcase (40%)**
- Project highlights
- Demo reel clips
- Client work samples
- Before/after audio (with visuals)

**2. Behind-the-Scenes (30%)**
- Studio life
- Creative process
- Day in the life
- Gear & tools

**3. Educational (20%)**
- Quick tips
- Sound design tricks
- Industry insights
- Tutorial snippets

**4. Personal/Brand (10%)**
- Team moments
- Industry events
- Awards/recognition
- Milestone celebrations

---

### **Step 4: Instagram Features to Use**

**A. Stories (Daily):**
- Behind-the-scenes snippets
- Work-in-progress clips
- Quick tips & tricks
- Polls & questions (engagement)
- **Highlights:** Save best stories to profile
  - Portfolio
  - Studio
  - Tips
  - Client Work

**B. Reels (2-3x/week):**
- Short-form video content
- 15-90 seconds
- High engagement potential
- Ideas:
  - "Sound design for this scene..."
  - "My favorite plugin for..."
  - "Studio tour in 60 seconds"
  - Time-lapse of mixing session

**C. IGTV / Long-Form Video:**
- Extended content (3-10 min)
- Deeper dives
- Full tutorials
- Project breakdowns

**D. Guides:**
- Curate posts into themed guides
- "My Best Work"
- "Getting Started in Game Audio"
- "Studio Setup Essentials"

---

### **Step 5: Hashtag Strategy**

**Create Hashtag Groups (30 hashtags max per post):**

**Group A: Broad Industry (10)**
```
#MusicComposer #SoundDesign #FilmMusic #GameAudio 
#VideoGameMusic #AudioProduction #FilmScore #Composer 
#SoundDesigner #OriginalMusic
```

**Group B: Specific Niche (10)**
```
#GameComposer #FilmComposer #IndieGameAudio #AAASoundDesign
#InteractiveAudio #PostProduction #AudioForPicture #VGMAudio
#GameSoundDesign #FilmSoundDesign
```

**Group C: Location/Personal (5)**
```
#OttawaComposer #CanadianComposer #OttawaMusic 
#CanadianAudio #OttawaCreative
```

**Group D: Rotating/Post-Specific (5)**
```
[Change based on post content]
#DeadSpace #HorrorAudio #ActionMusic #DramaScore etc.
```

**Pro Tip:** Save hashtag groups in Notes app, copy-paste easily

---

### **Step 6: Engagement Strategy**

**Daily Actions (15 min):**
- Like 20-30 posts in your niche
- Comment on 5-10 posts (meaningful comments)
- Respond to all comments on your posts
- Check DMs, respond promptly

**Follow Strategy:**
- Game developers
- Film producers
- Other composers (non-competitive)
- Audio gear companies
- Industry publications
- Potential clients

**Don't:**
- Follow/unfollow spam
- Use bots or automation
- Buy followers
- Post irrelevant content

---

## 📋 SETUP CHECKLIST - @NOIZYLAB

### **Step 1: Create Second Account (5 min)**

**In Instagram App:**
1. Go to Profile
2. Tap menu (three lines)
3. Settings → Add Account
4. Sign up with different email: noizylab@fishmusicinc.com (or separate)
5. Username: **noizylab**
6. Set up name: **NOIZYLAB**
7. Enable 2FA

---

### **Step 2: NOIZYLAB Profile Setup (10 min)**

**A. Profile Picture:**
- NOIZYLAB logo (create one if needed)
- Professional, tech-focused design

**B. Bio:**
```
⚙️ Professional CPU Repair Services
💻 Fast • Reliable • Expert
📍 Ottawa/Toronto Area
⏰ 12 Repairs Daily
📞 [Phone]
📧 noizylab@fishmusicinc.com
```

**C. Link in Bio:**
- NOIZYLAB website (when created) OR
- Booking form / Contact page

**D. Profile Type:**
- Professional Account
- Category: "Business & Utility Services" or "Computers & Electronics"

**E. Contact Options:**
- Business email
- Business phone
- Service area location

---

### **Step 3: NOIZYLAB Content Strategy**

**A. First 9 Posts:**
1. **Service Overview** - What you offer
2. **Before/After** - Successful repair
3. **Workspace** - Clean, professional lab
4. **Quick Tip** - CPU maintenance advice
5. **Customer Testimonial** - Success story
6. **Tool Shot** - Professional equipment
7. **Process** - Diagnostic/repair in action
8. **Pricing Graphic** - Transparent pricing
9. **CTA** - "Book your repair today"

**B. Content Pillars:**

**1. Service Information (30%)**
- What you fix
- Pricing transparency
- Turnaround times
- Service areas

**2. Educational Content (30%)**
- CPU maintenance tips
- Troubleshooting guides
- DIY prevention
- Tech education

**3. Customer Success (25%)**
- Before/after repairs
- Testimonials
- Reviews
- Success stories

**4. Behind-the-Scenes (15%)**
- Lab environment
- Tools & equipment
- Repair process
- Professional standards

---

### **Step 4: NOIZYLAB Hashtag Strategy**

**Group A: Service-Based (10)**
```
#ComputerRepair #CPURepair #TechSupport #PCRepair 
#LaptopRepair #ComputerService #TechRepair #ITServices
#ComputerFix #TechHelp
```

**Group B: Location-Based (10)**
```
#OttawaRepair #OttawaTech #OttawaComputer #OttawaBusiness
#TorontoRepair #TorontoTech #OntarioComputer #LocalTech
#OttawaServices #CanadiaTech
```

**Group C: Problem-Solving (5)**
```
#SlowComputer #ComputerProblems #PCIssues #TechIssues
#ComputerCrash
```

**Group D: Trust/Credibility (5)**
```
#ProfessionalRepair #ExpertTech #ReliableService 
#FastRepair #QualityService
```

---

### **Step 5: Local Business Strategy**

**NOIZYLAB-Specific Actions:**
- Tag location on every post (Ottawa/Toronto)
- Use local hashtags heavily
- Partner with local businesses
- Join local Ottawa/Toronto tech groups
- Share customer reviews prominently
- Post service specials/promotions
- Before/after transformations
- Educational content that builds trust

---

## 📅 POSTING SCHEDULE

### **@FISHMUSICINC:**
- **Feed Posts:** 3-5x per week
- **Stories:** Daily (15+ stories/week)
- **Reels:** 2-3x per week
- **Best Times:** 12-1pm, 5-7pm EST (when creatives browse)

### **@NOIZYLAB:**
- **Feed Posts:** 5-7x per week (more frequent, local service)
- **Stories:** Daily (service tips, quick fixes)
- **Best Times:** 8-9am, 12-1pm, 6-7pm EST (commute times)

---

## 🎨 VISUAL BRAND GUIDELINES

### **@FISHMUSICINC:**
**Color Palette:** Choose 3-4 consistent colors
- Option: Dark blue, gold, white, black (sophisticated)
- Option: Purple, cyan, black, white (creative/tech)

**Style:**
- Professional but artistic
- Behind-the-scenes feel
- High quality imagery
- Consistent filters/presets

**Typography:**
- Clean, modern fonts
- Readable text overlays
- Consistent style

### **@NOIZYLAB:**
**Color Palette:**
- Option: Blue, orange, white, gray (tech/trust)
- Option: Green, black, white (reliable/tech)

**Style:**
- Clean, professional
- Trustworthy aesthetic
- Before/after emphasis
- Service-focused

---

## 📸 CONTENT CREATION TOOLS

**Photography:**
- iPhone/smartphone (often sufficient)
- Good lighting (natural window light or ring light)
- Clean backgrounds
- Focus on subject

**Editing Apps:**
- **Canva** - Graphics, text overlays (FREE)
- **Lightroom Mobile** - Photo editing (FREE)
- **InShot** - Video editing (FREE)
- **CapCut** - Reels editing (FREE)
- **Unfold** - Story templates (FREE/PAID)

**Scheduling:**
- **Later** - Schedule posts in advance (FREE tier)
- **Buffer** - Cross-platform scheduling
- **Meta Business Suite** - Official Instagram scheduler

---

## 🤖 AUTOMATION & VOICE INTEGRATION

### **GABRIEL SUPREME Commands:**
```
"Claude, post to Instagram: [dictate caption]"
"Claude, schedule Instagram post for tomorrow at 2pm"
"Claude, check Instagram engagement"
"Claude, respond to Instagram DMs"
"Claude, generate hashtags for sound design post"
"Claude, create Instagram caption for studio photo"
```

### **Automation Workflow:**
1. Take photo/video → Voice command to upload
2. Claude generates caption with hashtags
3. Schedule or post immediately
4. Claude monitors engagement
5. Claude alerts to important comments/DMs

---

## 📊 ANALYTICS & GROWTH

### **Track These Metrics:**
- **Follower Growth** - Net new followers per week
- **Engagement Rate** - Likes + comments / followers (aim for 3%+)
- **Reach** - How many unique accounts see your content
- **Best Performing Posts** - What content works
- **Story Views** - How many watch your stories
- **Profile Visits** - Interest in your brand

### **Growth Tactics:**
1. **Consistency** - Post regularly, same times
2. **Engagement** - Respond to everyone, be active
3. **Collaborations** - Partner with other creators
4. **Hashtags** - Use all 30, mix popular + niche
5. **Reels** - Prioritize reels (highest reach)
6. **Stories** - Keep audience engaged daily
7. **Call-to-Action** - Always ask for engagement

### **Follower Goals:**
- **Month 1:** 100-300 followers
- **Month 3:** 500-1,000 followers
- **Month 6:** 1,500-3,000 followers
- **Year 1:** 5,000-10,000 followers (organic)

---

## 🔗 CROSS-PLATFORM INTEGRATION

**After Instagram Post:**
1. **Stories:** Share to Instagram Stories
2. **Facebook:** Cross-post automatically
3. **Threads:** Share to Threads (Meta integration)
4. **X (Twitter):** Tweet with image
5. **LinkedIn:** Professional posts
6. **Pinterest:** Save creative work

**Automated Cross-Posting:**
- Link Instagram to Facebook (auto-share)
- Use Buffer/Later for multi-platform
- Customize captions per platform

---

## ✅ LAUNCH CHECKLIST

### **@FISHMUSICINC:**
```
□ Account created
□ Professional account enabled
□ Profile picture uploaded
□ Bio written with keywords
□ Link added (website)
□ Contact info added
□ 2FA enabled
□ First 9 posts planned
□ First 3 posts uploaded
□ Story highlights created
□ Hashtag groups saved
□ Following 50-100 relevant accounts
□ Engaged with 20+ posts
□ Cross-promoted on other platforms
```

### **@NOIZYLAB:**
```
□ Second account created
□ Professional/Business account
□ Profile picture (logo)
□ Service-focused bio
□ Contact info prominent
□ Location tagged
□ Service posts created
□ Before/after content ready
□ Local hashtags researched
□ Following local businesses
□ Posted 3-5 initial posts
□ Listed on Google Business (link)
```

---

## 🚨 INSTAGRAM DON'TS

1. **Don't Buy Followers** - Fake engagement, hurts algorithm
2. **Don't Spam Hashtags** - Use relevant only
3. **Don't Ignore Comments** - Always respond
4. **Don't Post Inconsistently** - Kills momentum
5. **Don't Use Poor Quality Images** - Reflects on brand
6. **Don't Violate Copyright** - Only your content or licensed
7. **Don't Over-Promote** - Balance sales with value
8. **Don't Use Bots** - Against TOS, get banned

---

## 📞 SETUP ASSISTANCE

**Option A: Voice-Guided Setup**
- Tell Claude each screen you see
- Claude guides through process
- Use voice navigation features
- Time: 30-45 minutes per account

**Option B: Hire Social Media VA**
- Provide this guide + content
- They set up accounts
- You approve/review
- Cost: $100-200 for both accounts

**Option C: Partial Assistance**
- Someone helps with initial setup
- Claude helps with ongoing content/strategy
- You focus on creating authentic content

---

## 🎯 30-DAY CHALLENGE

**Week 1:**
- Set up both accounts
- Post first 3 pieces of content each
- Follow 100 relevant accounts
- Engage daily (15 min)

**Week 2:**
- Post 3-4x on each account
- Create first Reels
- Set up story highlights
- Track what works

**Week 3:**
- Maintain posting rhythm
- Experiment with content types
- Increase engagement time
- Start conversations in comments

**Week 4:**
- Review analytics
- Double down on what works
- Adjust strategy
- Plan month 2 content

**Result:** Strong foundation, growing audience, momentum established

---

**Created by:** GORUNFREEX1000  
**For:** Rob Plowman / Fish Music Inc. / NOIZYLAB  
**Purpose:** Maximum Instagram impact, voice-first accessibility  

**TWO ACCOUNTS = DOUBLE REACH** 📸
