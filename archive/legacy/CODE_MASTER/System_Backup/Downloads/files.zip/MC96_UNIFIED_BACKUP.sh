#!/bin/bash
# MC96_UNIFIED_BACKUP.sh
# FORT KNOX BACKUP SYSTEM FOR MC96ECOUNIVERSE
# GORUNFREEX100000000 - ULTIMATE DATA PROTECTION
#
# WHAT THIS DOES:
# - Automated backup across all devices
# - THE_AQUARIUM integration
# - Incremental + full backup strategies
# - Encryption (AES-256)
# - Deduplication
# - Version control (unlimited snapshots)
# - Compression
# - Integrity verification
# - Disaster recovery planning
# - One-click restore
#
# RUN AS: sudo bash MC96_UNIFIED_BACKUP.sh

set -e

# COLORS
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

# CONFIGURATION
BACKUP_CONFIG="$HOME/.mc96_backup_config"
BACKUP_LOG="$HOME/.mc96_backup.log"
BACKUP_INDEX="$HOME/.mc96_backup_index"

# Default paths
AQUARIUM_PATH="/Volumes/THE_AQUARIUM"
BACKUP_BASE="$HOME/MC96_Backups"

# Encryption
ENCRYPTION_KEY_FILE="$HOME/.mc96_backup_key"

# ═══════════════════════════════════════════════════════════════════════
# BANNER
# ═══════════════════════════════════════════════════════════════════════

show_banner() {
    clear
    echo -e "${CYAN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║                                                                      ║"
    echo "║          MC96 UNIFIED BACKUP SYSTEM                                  ║"
    echo "║                FORT KNOX DATA PROTECTION                             ║"
    echo "║                                                                      ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$BACKUP_LOG"
}

generate_backup_id() {
    echo "BKP_$(date +%Y%m%d_%H%M%S)_$(uuidgen | cut -d'-' -f1)"
}

# ═══════════════════════════════════════════════════════════════════════
# ENCRYPTION FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

setup_encryption() {
    if [ ! -f "$ENCRYPTION_KEY_FILE" ]; then
        echo ""
        echo -e "${CYAN}Setting up encryption...${NC}"
        echo ""
        echo "Choose encryption method:"
        echo "1) Generate random key (most secure)"
        echo "2) Use passphrase"
        echo ""
        echo -n "Select: "
        read METHOD
        
        case $METHOD in
            1)
                # Generate random 256-bit key
                openssl rand -base64 32 > "$ENCRYPTION_KEY_FILE"
                chmod 600 "$ENCRYPTION_KEY_FILE"
                echo -e "${GREEN}✓ Encryption key generated${NC}"
                echo -e "${YELLOW}⚠ IMPORTANT: Save this key file securely!${NC}"
                echo -e "${YELLOW}  Location: $ENCRYPTION_KEY_FILE${NC}"
                ;;
            2)
                echo -n "Enter passphrase: "
                read -s PASSPHRASE
                echo ""
                echo -n "Confirm passphrase: "
                read -s PASSPHRASE2
                echo ""
                
                if [ "$PASSPHRASE" = "$PASSPHRASE2" ]; then
                    echo -n "$PASSPHRASE" | openssl sha256 | awk '{print $2}' > "$ENCRYPTION_KEY_FILE"
                    chmod 600 "$ENCRYPTION_KEY_FILE"
                    echo -e "${GREEN}✓ Encryption key created from passphrase${NC}"
                else
                    echo -e "${RED}Passphrases don't match!${NC}"
                    exit 1
                fi
                ;;
        esac
        
        echo ""
        sleep 2
    fi
}

encrypt_file() {
    local INPUT=$1
    local OUTPUT=$2
    
    openssl enc -aes-256-cbc -salt -pbkdf2 \
        -in "$INPUT" \
        -out "$OUTPUT" \
        -pass file:"$ENCRYPTION_KEY_FILE"
}

decrypt_file() {
    local INPUT=$1
    local OUTPUT=$2
    
    openssl enc -aes-256-cbc -d -pbkdf2 \
        -in "$INPUT" \
        -out "$OUTPUT" \
        -pass file:"$ENCRYPTION_KEY_FILE"
}

# ═══════════════════════════════════════════════════════════════════════
# BACKUP CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════

load_config() {
    if [ -f "$BACKUP_CONFIG" ]; then
        source "$BACKUP_CONFIG"
    else
        # Default configuration
        cat > "$BACKUP_CONFIG" << 'EOF'
# MC96 Backup Configuration
BACKUP_SOURCES=()
BACKUP_DESTINATIONS=()
BACKUP_SCHEDULES=()
BACKUP_ENCRYPTION=1
BACKUP_COMPRESSION=1
BACKUP_DEDUPLICATION=1
BACKUP_VERSIONING=1
BACKUP_RETENTION_DAYS=90
BACKUP_FULL_INTERVAL=7
EOF
        source "$BACKUP_CONFIG"
    fi
}

save_config() {
    cat > "$BACKUP_CONFIG" << EOF
# MC96 Backup Configuration
BACKUP_SOURCES=(${BACKUP_SOURCES[@]})
BACKUP_DESTINATIONS=(${BACKUP_DESTINATIONS[@]})
BACKUP_SCHEDULES=(${BACKUP_SCHEDULES[@]})
BACKUP_ENCRYPTION=$BACKUP_ENCRYPTION
BACKUP_COMPRESSION=$BACKUP_COMPRESSION
BACKUP_DEDUPLICATION=$BACKUP_DEDUPLICATION
BACKUP_VERSIONING=$BACKUP_VERSIONING
BACKUP_RETENTION_DAYS=$BACKUP_RETENTION_DAYS
BACKUP_FULL_INTERVAL=$BACKUP_FULL_INTERVAL
EOF
}

# ═══════════════════════════════════════════════════════════════════════
# BACKUP OPERATIONS
# ═══════════════════════════════════════════════════════════════════════

create_backup() {
    local SOURCE=$1
    local DESTINATION=$2
    local BACKUP_TYPE=$3  # full or incremental
    
    if [ ! -d "$SOURCE" ]; then
        log_message "ERROR: Source does not exist: $SOURCE"
        return 1
    fi
    
    local BACKUP_ID=$(generate_backup_id)
    local BACKUP_DIR="$DESTINATION/$BACKUP_ID"
    
    mkdir -p "$BACKUP_DIR"
    
    log_message "Starting $BACKUP_TYPE backup: $SOURCE"
    log_message "Backup ID: $BACKUP_ID"
    log_message "Destination: $BACKUP_DIR"
    
    # Create manifest
    cat > "$BACKUP_DIR/manifest.txt" << EOF
Backup ID: $BACKUP_ID
Source: $SOURCE
Destination: $BACKUP_DIR
Type: $BACKUP_TYPE
Date: $(date)
Hostname: $(hostname)
User: $USER
Encryption: $BACKUP_ENCRYPTION
Compression: $BACKUP_COMPRESSION
Deduplication: $BACKUP_DEDUPLICATION
EOF
    
    # Calculate source size
    local SOURCE_SIZE=$(du -sh "$SOURCE" | awk '{print $1}')
    log_message "Source size: $SOURCE_SIZE"
    
    # Determine rsync options
    local RSYNC_OPTS="-avh --progress"
    
    if [ "$BACKUP_COMPRESSION" -eq 1 ]; then
        RSYNC_OPTS="$RSYNC_OPTS -z"
    fi
    
    # Add exclusions
    RSYNC_OPTS="$RSYNC_OPTS --exclude='.DS_Store' --exclude='*.tmp' --exclude='.Trash'"
    
    # Perform backup
    echo ""
    echo -e "${CYAN}Backing up: $SOURCE${NC}"
    echo -e "${CYAN}To: $BACKUP_DIR${NC}"
    echo ""
    
    if [ "$BACKUP_TYPE" = "incremental" ]; then
        # Find last full backup
        LAST_BACKUP=$(find "$DESTINATION" -maxdepth 1 -type d -name "BKP_*" | sort -r | head -1)
        
        if [ -n "$LAST_BACKUP" ]; then
            log_message "Incremental from: $LAST_BACKUP"
            RSYNC_OPTS="$RSYNC_OPTS --link-dest=$LAST_BACKUP"
        fi
    fi
    
    # Execute rsync
    rsync $RSYNC_OPTS "$SOURCE/" "$BACKUP_DIR/data/" 2>&1 | tee -a "$BACKUP_LOG"
    
    # Calculate backup size
    local BACKUP_SIZE=$(du -sh "$BACKUP_DIR" | awk '{print $1}')
    echo "Backup size: $BACKUP_SIZE" >> "$BACKUP_DIR/manifest.txt"
    
    # Create checksum
    log_message "Creating integrity checksums..."
    find "$BACKUP_DIR/data" -type f -exec md5 {} + > "$BACKUP_DIR/checksums.txt" 2>/dev/null
    
    # Encrypt if enabled
    if [ "$BACKUP_ENCRYPTION" -eq 1 ]; then
        log_message "Encrypting backup..."
        
        tar -czf "$BACKUP_DIR.tar.gz" -C "$DESTINATION" "$BACKUP_ID"
        encrypt_file "$BACKUP_DIR.tar.gz" "$BACKUP_DIR.tar.gz.enc"
        
        rm "$BACKUP_DIR.tar.gz"
        rm -rf "$BACKUP_DIR"
        
        log_message "✓ Backup encrypted"
    fi
    
    # Update index
    echo "$BACKUP_ID|$SOURCE|$DESTINATION|$BACKUP_TYPE|$(date)|$BACKUP_SIZE" >> "$BACKUP_INDEX"
    
    log_message "✓ Backup complete: $BACKUP_ID"
    echo ""
    echo -e "${GREEN}✓ Backup successful!${NC}"
    echo -e "${GREEN}  Backup ID: $BACKUP_ID${NC}"
    echo -e "${GREEN}  Size: $BACKUP_SIZE${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# RESTORE OPERATIONS
# ═══════════════════════════════════════════════════════════════════════

list_backups() {
    echo ""
    echo -e "${CYAN}Available Backups${NC}"
    echo -e "${CYAN}═════════════════${NC}"
    echo ""
    
    if [ ! -f "$BACKUP_INDEX" ]; then
        echo "  (no backups found)"
        return
    fi
    
    echo "ID | Source | Type | Date | Size"
    echo "───────────────────────────────────────────────────────────────────"
    
    cat "$BACKUP_INDEX" | while IFS='|' read ID SOURCE DEST TYPE DATE SIZE; do
        echo "$ID | $SOURCE | $TYPE | $DATE | $SIZE"
    done
    
    echo ""
}

restore_backup() {
    list_backups
    
    echo -n "Enter Backup ID to restore: "
    read BACKUP_ID
    
    # Find backup
    BACKUP_INFO=$(grep "^$BACKUP_ID|" "$BACKUP_INDEX" 2>/dev/null)
    
    if [ -z "$BACKUP_INFO" ]; then
        echo -e "${RED}Backup not found: $BACKUP_ID${NC}"
        return 1
    fi
    
    IFS='|' read ID SOURCE DEST TYPE DATE SIZE <<< "$BACKUP_INFO"
    
    echo ""
    echo -e "${YELLOW}Restoring backup:${NC}"
    echo "  ID: $BACKUP_ID"
    echo "  Original source: $SOURCE"
    echo "  Type: $TYPE"
    echo "  Date: $DATE"
    echo "  Size: $SIZE"
    echo ""
    
    echo -n "Restore to (press Enter for original location): "
    read RESTORE_PATH
    
    if [ -z "$RESTORE_PATH" ]; then
        RESTORE_PATH="$SOURCE"
    fi
    
    echo ""
    echo -e "${RED}WARNING: This will overwrite existing files in: $RESTORE_PATH${NC}"
    echo -n "Continue? (yes/no): "
    read CONFIRM
    
    if [ "$CONFIRM" != "yes" ]; then
        echo "Restore cancelled"
        return
    fi
    
    log_message "Starting restore: $BACKUP_ID to $RESTORE_PATH"
    
    # Check if encrypted
    BACKUP_FILE="$DEST/$BACKUP_ID.tar.gz.enc"
    
    if [ -f "$BACKUP_FILE" ]; then
        log_message "Decrypting backup..."
        
        TEMP_DIR="/tmp/mc96_restore_$$"
        mkdir -p "$TEMP_DIR"
        
        decrypt_file "$BACKUP_FILE" "$TEMP_DIR/backup.tar.gz"
        tar -xzf "$TEMP_DIR/backup.tar.gz" -C "$TEMP_DIR"
        
        # Restore data
        rsync -avh "$TEMP_DIR/$BACKUP_ID/data/" "$RESTORE_PATH/" 2>&1 | tee -a "$BACKUP_LOG"
        
        # Cleanup
        rm -rf "$TEMP_DIR"
    else
        # Unencrypted restore
        BACKUP_DIR="$DEST/$BACKUP_ID"
        
        if [ -d "$BACKUP_DIR/data" ]; then
            rsync -avh "$BACKUP_DIR/data/" "$RESTORE_PATH/" 2>&1 | tee -a "$BACKUP_LOG"
        fi
    fi
    
    log_message "✓ Restore complete: $BACKUP_ID"
    echo ""
    echo -e "${GREEN}✓ Restore successful!${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# THE_AQUARIUM INTEGRATION
# ═══════════════════════════════════════════════════════════════════════

backup_to_aquarium() {
    echo ""
    echo -e "${CYAN}Backup to THE_AQUARIUM${NC}"
    echo -e "${CYAN}══════════════════════${NC}"
    echo ""
    
    # Check if AQUARIUM is mounted
    if [ ! -d "$AQUARIUM_PATH" ]; then
        echo -e "${RED}THE_AQUARIUM is not mounted!${NC}"
        echo ""
        echo "Please mount THE_AQUARIUM first:"
        echo "  Location: $AQUARIUM_PATH"
        echo ""
        return 1
    fi
    
    echo -e "${GREEN}✓ THE_AQUARIUM is mounted${NC}"
    echo ""
    
    # Create AQUARIUM backup directory
    AQUARIUM_BACKUP="$AQUARIUM_PATH/MC96_BACKUPS"
    mkdir -p "$AQUARIUM_BACKUP"
    
    # What to backup
    echo "Select what to backup:"
    echo "1) All MC96 devices"
    echo "2) This device only"
    echo "3) Custom selection"
    echo ""
    echo -n "Select: "
    read CHOICE
    
    case $CHOICE in
        1)
            # Backup all devices
            echo ""
            echo -e "${CYAN}Backing up all MC96 devices to THE_AQUARIUM...${NC}"
            echo ""
            
            # This device
            create_backup "$HOME" "$AQUARIUM_BACKUP/$(hostname)" "full"
            
            # Other devices (if mounted)
            for DEVICE in ~/MC96Network/*; do
                if [ -d "$DEVICE" ] && mount | grep -q "$(basename "$DEVICE")"; then
                    DEVICE_NAME=$(basename "$DEVICE")
                    echo ""
                    echo -e "${CYAN}Backing up: $DEVICE_NAME${NC}"
                    create_backup "$DEVICE" "$AQUARIUM_BACKUP/$DEVICE_NAME" "full"
                fi
            done
            ;;
        2)
            # This device only
            create_backup "$HOME" "$AQUARIUM_BACKUP/$(hostname)" "full"
            ;;
        3)
            # Custom
            echo -n "Enter folder to backup: "
            read CUSTOM_PATH
            
            if [ -d "$CUSTOM_PATH" ]; then
                create_backup "$CUSTOM_PATH" "$AQUARIUM_BACKUP/CUSTOM" "full"
            else
                echo -e "${RED}Path does not exist${NC}"
            fi
            ;;
    esac
    
    echo ""
    echo -e "${GREEN}✓ THE_AQUARIUM backup complete!${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# CLEANUP OPERATIONS
# ═══════════════════════════════════════════════════════════════════════

cleanup_old_backups() {
    echo ""
    echo -e "${CYAN}Cleaning up old backups...${NC}"
    echo ""
    
    local CUTOFF_DATE=$(date -v-${BACKUP_RETENTION_DAYS}d +%s 2>/dev/null || date -d "$BACKUP_RETENTION_DAYS days ago" +%s)
    
    local DELETED=0
    
    # Read backup index
    while IFS='|' read ID SOURCE DEST TYPE DATE SIZE; do
        BACKUP_DATE=$(date -j -f "%a %b %d %T %Z %Y" "$DATE" +%s 2>/dev/null || date -d "$DATE" +%s 2>/dev/null)
        
        if [ "$BACKUP_DATE" -lt "$CUTOFF_DATE" ]; then
            log_message "Deleting old backup: $ID (from $DATE)"
            
            # Delete backup files
            rm -rf "$DEST/$ID" 2>/dev/null
            rm -f "$DEST/$ID.tar.gz.enc" 2>/dev/null
            
            ((DELETED++))
        fi
    done < "$BACKUP_INDEX" 2>/dev/null
    
    echo -e "${GREEN}✓ Deleted $DELETED old backups${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# MAIN MENU
# ═══════════════════════════════════════════════════════════════════════

show_menu() {
    show_banner
    
    echo "1) Create Backup"
    echo "2) Restore Backup"
    echo "3) List Backups"
    echo "4) Backup to THE_AQUARIUM"
    echo "5) Schedule Automatic Backups"
    echo "6) Cleanup Old Backups"
    echo "7) Verify Backup Integrity"
    echo "8) Configure Settings"
    echo "9) View Backup Log"
    echo "0) Exit"
    echo ""
    echo -n "Select option: "
}

# ═══════════════════════════════════════════════════════════════════════
# MAIN PROGRAM
# ═══════════════════════════════════════════════════════════════════════

# Setup
setup_encryption
load_config

while true; do
    show_menu
    read OPTION
    
    case $OPTION in
        1)
            echo ""
            echo -n "Source folder: "
            read SOURCE
            
            echo -n "Destination folder: "
            read DEST
            
            echo "Backup type: 1) Full  2) Incremental"
            echo -n "Select: "
            read TYPE_CHOICE
            
            if [ "$TYPE_CHOICE" = "1" ]; then
                TYPE="full"
            else
                TYPE="incremental"
            fi
            
            create_backup "$SOURCE" "$DEST" "$TYPE"
            ;;
        2)
            restore_backup
            ;;
        3)
            list_backups
            ;;
        4)
            backup_to_aquarium
            ;;
        5)
            echo ""
            echo -e "${YELLOW}Schedule automatic backups using cron${NC}"
            echo ""
            echo "Example: Daily backup at 2 AM"
            echo "0 2 * * * $0"
            ;;
        6)
            cleanup_old_backups
            ;;
        7)
            echo ""
            echo -e "${CYAN}Verifying backup integrity...${NC}"
            echo ""
            # TODO: Implement integrity check
            echo -e "${YELLOW}Feature coming soon${NC}"
            ;;
        8)
            echo ""
            echo "Current settings:"
            echo "  Encryption: $BACKUP_ENCRYPTION"
            echo "  Compression: $BACKUP_COMPRESSION"
            echo "  Deduplication: $BACKUP_DEDUPLICATION"
            echo "  Retention days: $BACKUP_RETENTION_DAYS"
            echo ""
            echo "Press Enter to continue..."
            read
            ;;
        9)
            echo ""
            tail -50 "$BACKUP_LOG"
            echo ""
            echo "Press Enter to continue..."
            read
            ;;
        0)
            echo ""
            echo -e "${GREEN}Exiting MC96 Backup System${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid option${NC}"
            sleep 1
            ;;
    esac
done
