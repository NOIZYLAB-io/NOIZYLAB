#!/bin/bash
# MC96_REALTIME_SYNC.sh
# REAL-TIME FILE SYNCHRONIZATION ACROSS MC96ECOUNIVERSE
# GORUNFREEX100000000 - ULTIMATE SYNC AUTOMATION
#
# WHAT THIS DOES:
# - Watches folders for changes in real-time
# - Automatically syncs changes to all other devices
# - Intelligent conflict resolution
# - Bandwidth optimization
# - Version history
# - Incremental sync (only changes)
# - Multi-directional sync support
#
# RUN AS: bash MC96_REALTIME_SYNC.sh

set -e

# COLORS
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# CONFIGURATION
SYNC_CONFIG="$HOME/.mc96_sync_config"
SYNC_LOG="$HOME/.mc96_sync.log"
VERSION_DIR="$HOME/.mc96_versions"

# BANNER
clear
echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║                                                                      ║"
echo "║          MC96 REAL-TIME SYNC ENGINE                                  ║"
echo "║                GORUNFREEX100000000                                   ║"
echo "║                                                                      ║"
echo "║          AUTOMATIC FILE SYNC ACROSS ALL DEVICES                      ║"
echo "║                                                                      ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# CHECK DEPENDENCIES
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}Checking dependencies...${NC}"

# Check for fswatch (file system watcher)
if ! command -v fswatch &> /dev/null; then
    echo -e "${YELLOW}Installing fswatch...${NC}"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        brew install fswatch 2>/dev/null || {
            echo -e "${RED}Please install Homebrew first: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"${NC}"
            exit 1
        }
    else
        # Linux
        sudo apt-get install -y fswatch 2>/dev/null || sudo yum install -y fswatch 2>/dev/null
    fi
fi

# Check for rsync
if ! command -v rsync &> /dev/null; then
    echo -e "${YELLOW}Installing rsync...${NC}"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install rsync
    else
        sudo apt-get install -y rsync 2>/dev/null || sudo yum install -y rsync 2>/dev/null
    fi
fi

echo -e "${GREEN}✓ All dependencies installed${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# CONFIGURATION MENU
# ═══════════════════════════════════════════════════════════════════════

show_menu() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}MC96 REAL-TIME SYNC MENU${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "1) Add Sync Folder"
    echo "2) Remove Sync Folder"
    echo "3) List Sync Folders"
    echo "4) Start Sync Engine"
    echo "5) Stop Sync Engine"
    echo "6) View Sync Status"
    echo "7) View Sync Log"
    echo "8) Restore from Version History"
    echo "9) Configure Advanced Settings"
    echo "0) Exit"
    echo ""
    echo -n "Select option: "
}

# ═══════════════════════════════════════════════════════════════════════
# SYNC CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════

load_config() {
    if [ -f "$SYNC_CONFIG" ]; then
        source "$SYNC_CONFIG"
    else
        # Default configuration
        cat > "$SYNC_CONFIG" << 'EOF'
# MC96 Sync Configuration
SYNC_FOLDERS=()
SYNC_TARGETS=()
SYNC_INTERVAL=5
SYNC_BANDWIDTH_LIMIT=0
SYNC_VERSION_HISTORY=1
SYNC_MAX_VERSIONS=10
SYNC_CONFLICT_RESOLUTION="newest"
SYNC_EXCLUDE_PATTERNS=(".DS_Store" "*.tmp" "*.swp" ".git" "node_modules")
EOF
        source "$SYNC_CONFIG"
    fi
}

save_config() {
    cat > "$SYNC_CONFIG" << EOF
# MC96 Sync Configuration
SYNC_FOLDERS=(${SYNC_FOLDERS[@]})
SYNC_TARGETS=(${SYNC_TARGETS[@]})
SYNC_INTERVAL=$SYNC_INTERVAL
SYNC_BANDWIDTH_LIMIT=$SYNC_BANDWIDTH_LIMIT
SYNC_VERSION_HISTORY=$SYNC_VERSION_HISTORY
SYNC_MAX_VERSIONS=$SYNC_MAX_VERSIONS
SYNC_CONFLICT_RESOLUTION="$SYNC_CONFLICT_RESOLUTION"
SYNC_EXCLUDE_PATTERNS=(${SYNC_EXCLUDE_PATTERNS[@]})
EOF
}

# ═══════════════════════════════════════════════════════════════════════
# ADD SYNC FOLDER
# ═══════════════════════════════════════════════════════════════════════

add_sync_folder() {
    echo ""
    echo -e "${CYAN}Add Sync Folder${NC}"
    echo -e "${CYAN}───────────────${NC}"
    echo ""
    
    # Get source folder
    echo -n "Enter local folder to sync (full path): "
    read SOURCE_FOLDER
    
    if [ ! -d "$SOURCE_FOLDER" ]; then
        echo -e "${RED}Error: Folder does not exist${NC}"
        return
    fi
    
    # Get target devices
    echo ""
    echo "Available devices in ~/MC96Network/:"
    ls -1 ~/MC96Network/ 2>/dev/null || echo "  (none mounted)"
    echo ""
    
    echo -n "Enter target device name (or 'all' for all devices): "
    read TARGET_DEVICE
    
    if [ "$TARGET_DEVICE" = "all" ]; then
        TARGET_PATH="all"
    else
        echo -n "Enter target folder path on $TARGET_DEVICE (relative to mount): "
        read TARGET_FOLDER
        TARGET_PATH="$TARGET_DEVICE:$TARGET_FOLDER"
    fi
    
    # Add to config
    SYNC_FOLDERS+=("$SOURCE_FOLDER")
    SYNC_TARGETS+=("$TARGET_PATH")
    
    save_config
    
    echo ""
    echo -e "${GREEN}✓ Sync folder added${NC}"
    echo -e "${GREEN}  Source: $SOURCE_FOLDER${NC}"
    echo -e "${GREEN}  Target: $TARGET_PATH${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# LIST SYNC FOLDERS
# ═══════════════════════════════════════════════════════════════════════

list_sync_folders() {
    echo ""
    echo -e "${CYAN}Current Sync Folders${NC}"
    echo -e "${CYAN}────────────────────${NC}"
    echo ""
    
    if [ ${#SYNC_FOLDERS[@]} -eq 0 ]; then
        echo "  (no folders configured)"
    else
        for i in "${!SYNC_FOLDERS[@]}"; do
            echo -e "${YELLOW}[$i]${NC} ${SYNC_FOLDERS[$i]}"
            echo -e "    → ${SYNC_TARGETS[$i]}"
            echo ""
        done
    fi
}

# ═══════════════════════════════════════════════════════════════════════
# REMOVE SYNC FOLDER
# ═══════════════════════════════════════════════════════════════════════

remove_sync_folder() {
    list_sync_folders
    
    echo -n "Enter index to remove: "
    read INDEX
    
    if [ "$INDEX" -ge 0 ] && [ "$INDEX" -lt ${#SYNC_FOLDERS[@]} ]; then
        REMOVED="${SYNC_FOLDERS[$INDEX]}"
        
        # Remove from arrays
        SYNC_FOLDERS=("${SYNC_FOLDERS[@]:0:$INDEX}" "${SYNC_FOLDERS[@]:$((INDEX+1))}")
        SYNC_TARGETS=("${SYNC_TARGETS[@]:0:$INDEX}" "${SYNC_TARGETS[@]:$((INDEX+1))}")
        
        save_config
        
        echo -e "${GREEN}✓ Removed: $REMOVED${NC}"
    else
        echo -e "${RED}Invalid index${NC}"
    fi
}

# ═══════════════════════════════════════════════════════════════════════
# START SYNC ENGINE
# ═══════════════════════════════════════════════════════════════════════

start_sync_engine() {
    echo ""
    echo -e "${CYAN}Starting MC96 Sync Engine...${NC}"
    echo ""
    
    # Check if already running
    if pgrep -f "MC96_REALTIME_SYNC" > /dev/null; then
        echo -e "${YELLOW}Sync engine is already running${NC}"
        return
    fi
    
    # Create version directory
    mkdir -p "$VERSION_DIR"
    
    # Start sync for each configured folder
    for i in "${!SYNC_FOLDERS[@]}"; do
        SOURCE="${SYNC_FOLDERS[$i]}"
        TARGET="${SYNC_TARGETS[$i]}"
        
        echo -e "${YELLOW}Starting sync: $SOURCE${NC}"
        
        # Start background sync process
        (
            # Watch for changes
            fswatch -0 -r -l 2 "$SOURCE" | while read -d "" EVENT; do
                # Log event
                echo "[$(date '+%Y-%m-%d %H:%M:%S')] Change detected: $EVENT" >> "$SYNC_LOG"
                
                # Version control
                if [ $SYNC_VERSION_HISTORY -eq 1 ]; then
                    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
                    BASENAME=$(basename "$EVENT")
                    VERSION_FILE="$VERSION_DIR/${BASENAME}_${TIMESTAMP}"
                    
                    if [ -f "$EVENT" ]; then
                        cp "$EVENT" "$VERSION_FILE" 2>/dev/null
                    fi
                    
                    # Clean old versions
                    ls -t "$VERSION_DIR/${BASENAME}_"* 2>/dev/null | tail -n +$((SYNC_MAX_VERSIONS+1)) | xargs rm -f 2>/dev/null
                fi
                
                # Sync to targets
                if [ "$TARGET" = "all" ]; then
                    # Sync to all devices
                    for DEVICE in ~/MC96Network/*; do
                        if [ -d "$DEVICE" ]; then
                            DEVICE_NAME=$(basename "$DEVICE")
                            DEST="$DEVICE/$(basename "$SOURCE")"
                            
                            rsync -avz --delete \
                                $(printf -- "--exclude=%s " "${SYNC_EXCLUDE_PATTERNS[@]}") \
                                "$SOURCE/" "$DEST/" >> "$SYNC_LOG" 2>&1
                            
                            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Synced to $DEVICE_NAME" >> "$SYNC_LOG"
                        fi
                    done
                else
                    # Sync to specific target
                    IFS=':' read -r DEVICE_NAME TARGET_FOLDER <<< "$TARGET"
                    DEST="~/MC96Network/$DEVICE_NAME/$TARGET_FOLDER"
                    
                    rsync -avz --delete \
                        $(printf -- "--exclude=%s " "${SYNC_EXCLUDE_PATTERNS[@]}") \
                        "$SOURCE/" "$DEST/" >> "$SYNC_LOG" 2>&1
                    
                    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Synced to $DEVICE_NAME:$TARGET_FOLDER" >> "$SYNC_LOG"
                fi
            done
        ) &
        
        # Save PID
        echo $! >> ~/.mc96_sync_pids
        
        echo -e "${GREEN}  ✓ Monitoring: $SOURCE${NC}"
    done
    
    echo ""
    echo -e "${GREEN}✓ MC96 Sync Engine started${NC}"
    echo -e "${GREEN}  Log: $SYNC_LOG${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# STOP SYNC ENGINE
# ═══════════════════════════════════════════════════════════════════════

stop_sync_engine() {
    echo ""
    echo -e "${CYAN}Stopping MC96 Sync Engine...${NC}"
    
    if [ -f ~/.mc96_sync_pids ]; then
        while read PID; do
            kill $PID 2>/dev/null
        done < ~/.mc96_sync_pids
        
        rm ~/.mc96_sync_pids
        
        echo -e "${GREEN}✓ Sync engine stopped${NC}"
    else
        echo -e "${YELLOW}Sync engine is not running${NC}"
    fi
    
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# VIEW SYNC STATUS
# ═══════════════════════════════════════════════════════════════════════

view_sync_status() {
    echo ""
    echo -e "${CYAN}MC96 Sync Status${NC}"
    echo -e "${CYAN}────────────────${NC}"
    echo ""
    
    # Check if running
    if pgrep -f "fswatch" > /dev/null; then
        echo -e "${GREEN}Status: RUNNING${NC}"
        echo ""
        
        # Show active monitors
        echo "Active monitors:"
        pgrep -f "fswatch" | while read PID; do
            CMD=$(ps -p $PID -o command= 2>/dev/null)
            echo "  PID $PID: $CMD"
        done
    else
        echo -e "${RED}Status: STOPPED${NC}"
    fi
    
    echo ""
    
    # Show recent sync activity
    echo "Recent sync activity (last 10):"
    tail -10 "$SYNC_LOG" 2>/dev/null || echo "  (no activity)"
    
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# VIEW SYNC LOG
# ═══════════════════════════════════════════════════════════════════════

view_sync_log() {
    echo ""
    echo -e "${CYAN}MC96 Sync Log${NC}"
    echo -e "${CYAN}──────────────${NC}"
    echo ""
    
    if [ -f "$SYNC_LOG" ]; then
        tail -50 "$SYNC_LOG"
    else
        echo "  (no log file)"
    fi
    
    echo ""
    echo "Press Enter to continue..."
    read
}

# ═══════════════════════════════════════════════════════════════════════
# RESTORE FROM VERSION HISTORY
# ═══════════════════════════════════════════════════════════════════════

restore_version() {
    echo ""
    echo -e "${CYAN}Restore from Version History${NC}"
    echo -e "${CYAN}────────────────────────────${NC}"
    echo ""
    
    # List available versions
    if [ -d "$VERSION_DIR" ] && [ "$(ls -A $VERSION_DIR)" ]; then
        echo "Available versions:"
        echo ""
        
        ls -lht "$VERSION_DIR" | tail -20
        
        echo ""
        echo -n "Enter filename to restore: "
        read RESTORE_FILE
        
        if [ -f "$VERSION_DIR/$RESTORE_FILE" ]; then
            # Extract original filename
            ORIGINAL_NAME=$(echo "$RESTORE_FILE" | sed 's/_[0-9]*$//')
            
            echo -n "Restore to (press Enter for original location): "
            read RESTORE_PATH
            
            if [ -z "$RESTORE_PATH" ]; then
                # Find in sync folders
                for FOLDER in "${SYNC_FOLDERS[@]}"; do
                    if [ -f "$FOLDER/$ORIGINAL_NAME" ]; then
                        RESTORE_PATH="$FOLDER/$ORIGINAL_NAME"
                        break
                    fi
                done
            fi
            
            if [ -n "$RESTORE_PATH" ]; then
                cp "$VERSION_DIR/$RESTORE_FILE" "$RESTORE_PATH"
                echo -e "${GREEN}✓ Restored to: $RESTORE_PATH${NC}"
            else
                echo -e "${RED}Could not determine restore location${NC}"
            fi
        else
            echo -e "${RED}File not found${NC}"
        fi
    else
        echo "  (no version history)"
    fi
    
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# ADVANCED SETTINGS
# ═══════════════════════════════════════════════════════════════════════

configure_advanced() {
    echo ""
    echo -e "${CYAN}Advanced Settings${NC}"
    echo -e "${CYAN}─────────────────${NC}"
    echo ""
    
    echo "Current settings:"
    echo "  Sync Interval: ${SYNC_INTERVAL}s"
    echo "  Bandwidth Limit: ${SYNC_BANDWIDTH_LIMIT} KB/s (0 = unlimited)"
    echo "  Version History: ${SYNC_VERSION_HISTORY} (1=on, 0=off)"
    echo "  Max Versions: ${SYNC_MAX_VERSIONS}"
    echo "  Conflict Resolution: ${SYNC_CONFLICT_RESOLUTION}"
    echo ""
    
    echo -n "Change settings? (y/n): "
    read CHANGE
    
    if [ "$CHANGE" = "y" ]; then
        echo -n "Sync Interval (seconds): "
        read NEW_INTERVAL
        [ -n "$NEW_INTERVAL" ] && SYNC_INTERVAL=$NEW_INTERVAL
        
        echo -n "Bandwidth Limit (KB/s, 0=unlimited): "
        read NEW_BANDWIDTH
        [ -n "$NEW_BANDWIDTH" ] && SYNC_BANDWIDTH_LIMIT=$NEW_BANDWIDTH
        
        echo -n "Enable Version History? (1=yes, 0=no): "
        read NEW_HISTORY
        [ -n "$NEW_HISTORY" ] && SYNC_VERSION_HISTORY=$NEW_HISTORY
        
        echo -n "Max Versions to Keep: "
        read NEW_MAX_VERSIONS
        [ -n "$NEW_MAX_VERSIONS" ] && SYNC_MAX_VERSIONS=$NEW_MAX_VERSIONS
        
        save_config
        
        echo -e "${GREEN}✓ Settings saved${NC}"
    fi
    
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# MAIN MENU LOOP
# ═══════════════════════════════════════════════════════════════════════

load_config

while true; do
    show_menu
    read OPTION
    
    case $OPTION in
        1) add_sync_folder ;;
        2) remove_sync_folder ;;
        3) list_sync_folders ;;
        4) start_sync_engine ;;
        5) stop_sync_engine ;;
        6) view_sync_status ;;
        7) view_sync_log ;;
        8) restore_version ;;
        9) configure_advanced ;;
        0) 
            echo ""
            echo -e "${GREEN}Exiting MC96 Sync Engine${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid option${NC}"
            ;;
    esac
    
    echo ""
    echo "Press Enter to continue..."
    read
    clear
done
