#!/bin/bash
# MC96_MASTER_CONTROL.sh
# ULTIMATE MASTER CONTROL PANEL FOR MC96ECOUNIVERSE
# GORUNFREEX100000000 - ONE INTERFACE TO RULE THEM ALL
#
# WHAT THIS DOES:
# - Unified control panel for ALL MC96 tools
# - One-click access to all systems
# - System health overview
# - Quick actions
# - Voice command ready
# - Network status at a glance
# - Backup management
# - Sync control
# - Performance monitoring
#
# RUN AS: bash MC96_MASTER_CONTROL.sh

set -e

# COLORS
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'

# PATHS
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NETWORK_BASE="10.90.90"

# Device definitions
declare -A DEVICES
DEVICES=(
    ["10.90.90.10"]="GOD"
    ["10.90.90.20"]="GABRIEL"
    ["10.90.90.30"]="MIKE"
    ["10.90.90.15"]="DaFixer"
    ["10.90.90.90"]="MC96_Switch"
)

# ═══════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

check_device_status() {
    local IP=$1
    if ping -c 1 -W 1 $IP &> /dev/null; then
        echo "ONLINE"
        return 0
    else
        echo "OFFLINE"
        return 1
    fi
}

get_network_health() {
    local ONLINE=0
    local TOTAL=${#DEVICES[@]}
    
    for IP in "${!DEVICES[@]}"; do
        if ping -c 1 -W 1 $IP &> /dev/null 2>&1; then
            ((ONLINE++))
        fi
    done
    
    local HEALTH_PERCENT=$(echo "scale=0; $ONLINE * 100 / $TOTAL" | bc)
    echo "$HEALTH_PERCENT"
}

check_sync_status() {
    if pgrep -f "fswatch" > /dev/null 2>&1; then
        echo "RUNNING"
    else
        echo "STOPPED"
    fi
}

get_last_backup() {
    if [ -f "$HOME/.mc96_backup_index" ]; then
        local LAST=$(tail -1 "$HOME/.mc96_backup_index" | cut -d'|' -f5)
        echo "$LAST"
    else
        echo "Never"
    fi
}

# ═══════════════════════════════════════════════════════════════════════
# DISPLAY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

draw_header() {
    clear
    echo -e "${CYAN}${BOLD}"
    cat << "EOF"
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║               MC96 ECOUNIVERSE - MASTER CONTROL                      ║
║                                                                      ║
║                 █▀▄▀█ █▀▀ █▀█ █▀▀                                    ║
║                 █ ▀ █ █   ██▄ ███                                    ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo ""
    echo -e "${DIM}$(date '+%A, %B %d, %Y - %H:%M:%S')${NC}"
    echo -e "${DIM}Machine: $(hostname) | User: $USER${NC}"
    echo ""
}

draw_system_status() {
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║  SYSTEM STATUS                                                       ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # Network Health
    local HEALTH=$(get_network_health)
    if [ "$HEALTH" -eq 100 ]; then
        local HEALTH_COLOR=$GREEN
        local HEALTH_ICON="✓"
    elif [ "$HEALTH" -ge 80 ]; then
        local HEALTH_COLOR=$GREEN
        local HEALTH_ICON="✓"
    elif [ "$HEALTH" -ge 50 ]; then
        local HEALTH_COLOR=$YELLOW
        local HEALTH_ICON="⚠"
    else
        local HEALTH_COLOR=$RED
        local HEALTH_ICON="✗"
    fi
    
    echo -e "  ${BOLD}Network Health:${NC}     ${HEALTH_COLOR}${HEALTH_ICON} ${HEALTH}%${NC}"
    
    # Sync Status
    local SYNC_STATUS=$(check_sync_status)
    if [ "$SYNC_STATUS" = "RUNNING" ]; then
        echo -e "  ${BOLD}Real-Time Sync:${NC}     ${GREEN}✓ $SYNC_STATUS${NC}"
    else
        echo -e "  ${BOLD}Real-Time Sync:${NC}     ${YELLOW}○ $SYNC_STATUS${NC}"
    fi
    
    # Last Backup
    local LAST_BACKUP=$(get_last_backup)
    echo -e "  ${BOLD}Last Backup:${NC}        ${CYAN}$LAST_BACKUP${NC}"
    
    # Disk Space
    local DISK_USAGE=$(df -h ~ | tail -1 | awk '{print $5}' | cut -d'%' -f1)
    if [ "$DISK_USAGE" -lt 70 ]; then
        local DISK_COLOR=$GREEN
    elif [ "$DISK_USAGE" -lt 90 ]; then
        local DISK_COLOR=$YELLOW
    else
        local DISK_COLOR=$RED
    fi
    echo -e "  ${BOLD}Disk Usage:${NC}         ${DISK_COLOR}${DISK_USAGE}%${NC}"
    
    echo ""
}

draw_device_grid() {
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║  MC96 DEVICES                                                        ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    for IP in "${!DEVICES[@]}"; do
        NAME="${DEVICES[$IP]}"
        STATUS=$(check_device_status $IP)
        
        if [ "$STATUS" = "ONLINE" ]; then
            echo -e "  ${GREEN}●${NC} ${BOLD}$NAME${NC} ${DIM}($IP)${NC} ${GREEN}$STATUS${NC}"
        else
            echo -e "  ${RED}●${NC} ${BOLD}$NAME${NC} ${DIM}($IP)${NC} ${RED}$STATUS${NC}"
        fi
    done
    
    echo ""
}

draw_menu() {
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║  MASTER CONTROL MENU                                                 ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    echo -e "  ${BOLD}${CYAN}NETWORK TOOLS${NC}"
    echo -e "  ${BOLD}1)${NC} Network Setup       ${DIM}→ Configure all devices${NC}"
    echo -e "  ${BOLD}2)${NC} Network Monitor     ${DIM}→ Real-time health dashboard${NC}"
    echo -e "  ${BOLD}3)${NC} Network Dashboard   ${DIM}→ Quick status view${NC}"
    echo ""
    
    echo -e "  ${BOLD}${GREEN}SYNC & BACKUP${NC}"
    echo -e "  ${BOLD}4)${NC} Real-Time Sync      ${DIM}→ Auto file synchronization${NC}"
    echo -e "  ${BOLD}5)${NC} Unified Backup      ${DIM}→ FORT KNOX backup system${NC}"
    echo -e "  ${BOLD}6)${NC} THE_AQUARIUM Backup ${DIM}→ Quick AQUARIUM backup${NC}"
    echo ""
    
    echo -e "  ${BOLD}${YELLOW}QUICK ACTIONS${NC}"
    echo -e "  ${BOLD}7)${NC} Mount All Devices   ${DIM}→ Connect to all network devices${NC}"
    echo -e "  ${BOLD}8)${NC} Unmount All         ${DIM}→ Safely disconnect all${NC}"
    echo -e "  ${BOLD}9)${NC} Heal Network        ${DIM}→ Auto-fix connection issues${NC}"
    echo ""
    
    echo -e "  ${BOLD}${MAGENTA}SYSTEM${NC}"
    echo -e "  ${BOLD}A)${NC} View Logs           ${DIM}→ System logs${NC}"
    echo -e "  ${BOLD}B)${NC} Performance Test    ${DIM}→ Network speed test${NC}"
    echo -e "  ${BOLD}C)${NC} System Info         ${DIM}→ Detailed information${NC}"
    echo -e "  ${BOLD}D)${NC} Remote Shell        ${DIM}→ SSH to another device${NC}"
    echo ""
    
    echo -e "  ${BOLD}0)${NC} Exit"
    echo ""
    echo -n "  ${BOLD}Select:${NC} "
}

# ═══════════════════════════════════════════════════════════════════════
# ACTION FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

mount_all_devices() {
    echo ""
    echo -e "${CYAN}Mounting all network devices...${NC}"
    echo ""
    
    # Run auto-mount script if it exists
    if [ -f "$HOME/mc96_auto_mount.sh" ]; then
        bash "$HOME/mc96_auto_mount.sh"
    else
        # Manual mount
        for IP in "${!DEVICES[@]}"; do
            NAME="${DEVICES[$IP]}"
            
            if [ "$IP" != "$(ifconfig | grep 'inet 10.90.90' | awk '{print $2}')" ]; then
                echo -e "${YELLOW}Mounting: $NAME ($IP)${NC}"
                
                MOUNT_POINT="$HOME/MC96Network/$NAME"
                mkdir -p "$MOUNT_POINT"
                
                mount_smbfs "//mc96net@$IP/share" "$MOUNT_POINT" 2>/dev/null && \
                    echo -e "${GREEN}  ✓ Mounted${NC}" || \
                    echo -e "${YELLOW}  ○ Could not mount${NC}"
            fi
        done
    fi
    
    echo ""
    echo "Press Enter to continue..."
    read
}

unmount_all_devices() {
    echo ""
    echo -e "${CYAN}Unmounting all network devices...${NC}"
    echo ""
    
    if [ -d "$HOME/MC96Network" ]; then
        for MOUNT in "$HOME/MC96Network"/*; do
            if [ -d "$MOUNT" ] && mount | grep -q "$(basename "$MOUNT")"; then
                echo -e "${YELLOW}Unmounting: $(basename "$MOUNT")${NC}"
                umount "$MOUNT" 2>/dev/null && \
                    echo -e "${GREEN}  ✓ Unmounted${NC}" || \
                    echo -e "${RED}  ✗ Failed${NC}"
            fi
        done
    fi
    
    echo ""
    echo "Press Enter to continue..."
    read
}

heal_network() {
    echo ""
    echo -e "${CYAN}Running network healing...${NC}"
    echo ""
    
    for IP in "${!DEVICES[@]}"; do
        NAME="${DEVICES[$IP]}"
        
        echo -e "${YELLOW}Checking: $NAME ($IP)${NC}"
        
        if ! ping -c 1 -W 1 $IP &> /dev/null; then
            echo -e "${RED}  ✗ Device offline - cannot heal${NC}"
        else
            echo -e "${GREEN}  ✓ Device online${NC}"
            
            # Check if mounted
            MOUNT_POINT="$HOME/MC96Network/$NAME"
            if [ -d "$MOUNT_POINT" ] && ! mount | grep -q "$(basename "$MOUNT_POINT")"; then
                echo -e "${YELLOW}  → Remounting...${NC}"
                mount_smbfs "//mc96net@$IP/share" "$MOUNT_POINT" 2>/dev/null && \
                    echo -e "${GREEN}    ✓ Remounted${NC}" || \
                    echo -e "${RED}    ✗ Failed to remount${NC}"
            fi
        fi
    done
    
    echo ""
    echo -e "${GREEN}✓ Network healing complete${NC}"
    echo ""
    echo "Press Enter to continue..."
    read
}

performance_test() {
    echo ""
    echo -e "${CYAN}Running network performance test...${NC}"
    echo ""
    
    for IP in "${!DEVICES[@]}"; do
        NAME="${DEVICES[$IP]}"
        
        if ping -c 1 -W 1 $IP &> /dev/null; then
            echo -e "${BOLD}$NAME ($IP):${NC}"
            
            # Latency test
            LATENCY=$(ping -c 5 -W 1 $IP 2>/dev/null | grep 'avg' | awk -F'/' '{print $5}' | cut -d'.' -f1)
            echo -e "  Latency: ${CYAN}${LATENCY}ms${NC}"
            
            # Packet loss
            LOSS=$(ping -c 10 -W 1 $IP 2>/dev/null | grep 'packet loss' | awk '{print $6}' | cut -d'%' -f1)
            echo -e "  Packet Loss: ${CYAN}${LOSS}%${NC}"
            
            echo ""
        fi
    done
    
    echo "Press Enter to continue..."
    read
}

view_logs() {
    echo ""
    echo -e "${CYAN}System Logs${NC}"
    echo -e "${CYAN}═══════════${NC}"
    echo ""
    echo "1) Network Monitor Log"
    echo "2) Sync Log"
    echo "3) Backup Log"
    echo "4) Alert Log"
    echo "0) Back"
    echo ""
    echo -n "Select: "
    read LOG_CHOICE
    
    case $LOG_CHOICE in
        1) tail -50 "$HOME/.mc96_monitor.log" 2>/dev/null || echo "No log file" ;;
        2) tail -50 "$HOME/.mc96_sync.log" 2>/dev/null || echo "No log file" ;;
        3) tail -50 "$HOME/.mc96_backup.log" 2>/dev/null || echo "No log file" ;;
        4) tail -50 "$HOME/.mc96_alerts.log" 2>/dev/null || echo "No log file" ;;
    esac
    
    echo ""
    echo "Press Enter to continue..."
    read
}

system_info() {
    clear
    echo -e "${CYAN}${BOLD}MC96 SYSTEM INFORMATION${NC}"
    echo -e "${CYAN}═══════════════════════${NC}"
    echo ""
    
    echo -e "${BOLD}System:${NC}"
    echo "  Hostname: $(hostname)"
    echo "  User: $USER"
    echo "  OS: $(uname -s)"
    echo "  Kernel: $(uname -r)"
    echo ""
    
    echo -e "${BOLD}Network:${NC}"
    MY_IP=$(ifconfig | grep "inet $NETWORK_BASE" | awk '{print $2}' | head -1)
    echo "  IP Address: $MY_IP"
    echo "  Network Base: $NETWORK_BASE.0/24"
    echo ""
    
    echo -e "${BOLD}Storage:${NC}"
    df -h ~ | tail -1
    echo ""
    
    echo -e "${BOLD}Memory:${NC}"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "  Total: $(sysctl -n hw.memsize | awk '{print $1/1024/1024/1024 " GB"}')"
    else
        free -h | grep Mem
    fi
    echo ""
    
    echo -e "${BOLD}MC96 Network Mounts:${NC}"
    if [ -d "$HOME/MC96Network" ]; then
        ls -la "$HOME/MC96Network" 2>/dev/null
    else
        echo "  (none)"
    fi
    echo ""
    
    echo "Press Enter to continue..."
    read
}

remote_shell() {
    echo ""
    echo -e "${CYAN}Remote Shell Access${NC}"
    echo -e "${CYAN}═══════════════════${NC}"
    echo ""
    
    echo "Available devices:"
    local i=1
    declare -a DEVICE_LIST
    for IP in "${!DEVICES[@]}"; do
        if ping -c 1 -W 1 $IP &> /dev/null; then
            echo "  $i) ${DEVICES[$IP]} ($IP)"
            DEVICE_LIST[$i]="$IP"
            ((i++))
        fi
    done
    
    echo ""
    echo -n "Select device (or 0 to cancel): "
    read DEVICE_CHOICE
    
    if [ "$DEVICE_CHOICE" -gt 0 ] && [ -n "${DEVICE_LIST[$DEVICE_CHOICE]}" ]; then
        TARGET_IP="${DEVICE_LIST[$DEVICE_CHOICE]}"
        echo ""
        echo -e "${CYAN}Connecting to ${DEVICES[$TARGET_IP]} ($TARGET_IP)...${NC}"
        echo ""
        ssh "mc96net@$TARGET_IP"
    fi
}

# ═══════════════════════════════════════════════════════════════════════
# MAIN PROGRAM LOOP
# ═══════════════════════════════════════════════════════════════════════

while true; do
    draw_header
    draw_system_status
    draw_device_grid
    draw_menu
    
    read OPTION
    
    case $OPTION in
        1)
            # Network Setup
            if [ -f "$SCRIPT_DIR/MC96_NETWORK_MASTER_SETUP_MAC.sh" ]; then
                sudo bash "$SCRIPT_DIR/MC96_NETWORK_MASTER_SETUP_MAC.sh"
            else
                echo ""
                echo -e "${YELLOW}Setup script not found in: $SCRIPT_DIR${NC}"
                echo "Press Enter to continue..."
                read
            fi
            ;;
        2)
            # Network Monitor
            if [ -f "$SCRIPT_DIR/MC96_NETWORK_MONITOR.sh" ]; then
                bash "$SCRIPT_DIR/MC96_NETWORK_MONITOR.sh"
            else
                echo ""
                echo -e "${YELLOW}Monitor script not found${NC}"
                echo "Press Enter to continue..."
                read
            fi
            ;;
        3)
            # Network Dashboard
            if [ -f "$HOME/mc96_network_dashboard.sh" ]; then
                bash "$HOME/mc96_network_dashboard.sh"
            else
                echo ""
                echo -e "${YELLOW}Dashboard script not found${NC}"
                echo "Press Enter to continue..."
                read
            fi
            ;;
        4)
            # Real-Time Sync
            if [ -f "$SCRIPT_DIR/MC96_REALTIME_SYNC.sh" ]; then
                bash "$SCRIPT_DIR/MC96_REALTIME_SYNC.sh"
            else
                echo ""
                echo -e "${YELLOW}Sync script not found${NC}"
                echo "Press Enter to continue..."
                read
            fi
            ;;
        5)
            # Unified Backup
            if [ -f "$SCRIPT_DIR/MC96_UNIFIED_BACKUP.sh" ]; then
                sudo bash "$SCRIPT_DIR/MC96_UNIFIED_BACKUP.sh"
            else
                echo ""
                echo -e "${YELLOW}Backup script not found${NC}"
                echo "Press Enter to continue..."
                read
            fi
            ;;
        6)
            # Quick AQUARIUM Backup
            echo ""
            echo -e "${CYAN}Quick backup to THE_AQUARIUM...${NC}"
            echo ""
            if [ -d "/Volumes/THE_AQUARIUM" ]; then
                rsync -avh --progress "$HOME" "/Volumes/THE_AQUARIUM/QuickBackup_$(hostname)_$(date +%Y%m%d)/"
                echo ""
                echo -e "${GREEN}✓ Backup complete!${NC}"
            else
                echo -e "${RED}THE_AQUARIUM not mounted${NC}"
            fi
            echo ""
            echo "Press Enter to continue..."
            read
            ;;
        7)
            mount_all_devices
            ;;
        8)
            unmount_all_devices
            ;;
        9)
            heal_network
            ;;
        A|a)
            view_logs
            ;;
        B|b)
            performance_test
            ;;
        C|c)
            system_info
            ;;
        D|d)
            remote_shell
            ;;
        0)
            clear
            echo ""
            echo -e "${CYAN}${BOLD}"
            echo "╔══════════════════════════════════════════════════════════════════════╗"
            echo "║                                                                      ║"
            echo "║          MC96 MASTER CONTROL - SHUTTING DOWN                         ║"
            echo "║                                                                      ║"
            echo "║          All systems nominal. GORUNFREE achieved.                    ║"
            echo "║                                                                      ║"
            echo "╚══════════════════════════════════════════════════════════════════════╝"
            echo -e "${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo ""
            echo -e "${RED}Invalid option${NC}"
            sleep 1
            ;;
    esac
done
