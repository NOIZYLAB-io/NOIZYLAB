# MC96_NETWORK_MASTER_SETUP_WIN.ps1
# ONE COMMAND NETWORK SETUP FOR WINDOWS
# GORUNFREEX100000000 - ULTIMATE NETWORK AUTOMATION
#
# WHAT THIS DOES:
# - Auto-discovers all MC96 devices on network
# - Enables SMB file sharing
# - Creates unified user account
# - Shares important folders
# - Mounts all other devices as network drives
# - Sets up auto-mount at login
# - Configures firewall
# - Tests all connections
# - Creates network dashboard
#
# RUN AS ADMINISTRATOR

#Requires -RunAsAdministrator

$ErrorActionPreference = "Continue"

# CONFIGURATION
$MC96_USER = "mc96net"
$MC96_PASS = "MC96Supreme2025"  # CHANGE THIS!
$NETWORK_BASE = "10.90.90"

# COLORS (Windows Console)
function Write-Color {
    param([string]$Text, [string]$Color = "White")
    Write-Host $Text -ForegroundColor $Color
}

# BANNER
Clear-Host
Write-Color "╔══════════════════════════════════════════════════════════════════════╗" "Cyan"
Write-Color "║                                                                      ║" "Cyan"
Write-Color "║          MC96 NETWORK MASTER SETUP - WINDOWS VERSION                 ║" "Cyan"
Write-Color "║                GORUNFREEX100000000                                   ║" "Cyan"
Write-Color "║                                                                      ║" "Cyan"
Write-Color "║          ONE COMMAND → COMPLETE NETWORK AUTOMATION                   ║" "Cyan"
Write-Color "║                                                                      ║" "Cyan"
Write-Color "╚══════════════════════════════════════════════════════════════════════╝" "Cyan"
Write-Host ""

Write-Color "Running as: $env:USERNAME" "Yellow"
Write-Color "Computer: $env:COMPUTERNAME" "Yellow"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 1: DISCOVER MC96 NETWORK
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 1: Discovering MC96ECOUNIVERSE Network..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

# Get this machine's IP
$MY_IP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -like "$NETWORK_BASE.*" }).IPAddress
Write-Color "✓ This machine: $MY_IP" "Green"
Write-Host ""

# Discover all devices on network
Write-Color "Scanning network $NETWORK_BASE.0/24..." "Yellow"
$Devices = @()

1..254 | ForEach-Object {
    $IP = "$NETWORK_BASE.$_"
    if ($IP -ne $MY_IP) {
        if (Test-Connection -ComputerName $IP -Count 1 -Quiet -TimeoutSeconds 1) {
            # Try to get hostname
            try {
                $HostName = [System.Net.Dns]::GetHostEntry($IP).HostName
            }
            catch {
                $HostName = "Device-$_"
            }
            
            $Devices += @{
                IP = $IP
                Name = $HostName
            }
            
            Write-Color "  ✓ Found: $IP ($HostName)" "Green"
        }
    }
}

Write-Host ""
Write-Color "✓ Discovered $($Devices.Count) devices on MC96 network" "Green"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 2: CREATE UNIFIED USER ACCOUNT
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 2: Creating Unified Network User..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

# Check if user exists
$UserExists = Get-LocalUser -Name $MC96_USER -ErrorAction SilentlyContinue

if ($UserExists) {
    Write-Color "User $MC96_USER already exists - resetting password..." "Yellow"
    $SecurePassword = ConvertTo-SecureString $MC96_PASS -AsPlainText -Force
    Set-LocalUser -Name $MC96_USER -Password $SecurePassword
}
else {
    Write-Color "Creating user: $MC96_USER" "Yellow"
    
    $SecurePassword = ConvertTo-SecureString $MC96_PASS -AsPlainText -Force
    New-LocalUser -Name $MC96_USER -Password $SecurePassword -Description "MC96 Network Admin" -PasswordNeverExpires
    
    # Add to Administrators group
    Add-LocalGroupMember -Group "Administrators" -Member $MC96_USER -ErrorAction SilentlyContinue
    
    Write-Color "✓ User $MC96_USER created" "Green"
}

Write-Color "✓ Username: $MC96_USER" "Green"
Write-Color "✓ Password: [configured]" "Green"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 3: ENABLE SMB FILE SHARING
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 3: Enabling SMB File Sharing..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

# Enable Network Discovery
Write-Color "Enabling Network Discovery..." "Yellow"
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes | Out-Null

# Enable File and Printer Sharing
Write-Color "Enabling File and Printer Sharing..." "Yellow"
netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes | Out-Null

# Enable SMB
Write-Color "Configuring SMB..." "Yellow"
Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction SilentlyContinue
Set-SmbServerConfiguration -EnableSMB2Protocol $true -Force -ErrorAction SilentlyContinue

Write-Color "✓ SMB enabled and configured" "Green"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 4: SHARE IMPORTANT FOLDERS
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 4: Sharing Important Folders..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

$MACHINE_NAME = $env:COMPUTERNAME
Write-Color "Machine name: $MACHINE_NAME" "Yellow"
Write-Host ""

# Create MC96 share folder
$MC96_SHARE_PATH = "C:\MC96_Share"
if (!(Test-Path $MC96_SHARE_PATH)) {
    New-Item -ItemType Directory -Path $MC96_SHARE_PATH -Force | Out-Null
}

# Share the MC96 folder
Write-Color "Sharing C:\MC96_Share..." "Yellow"
Remove-SmbShare -Name "${MACHINE_NAME}_MC96" -Force -ErrorAction SilentlyContinue
New-SmbShare -Name "${MACHINE_NAME}_MC96" -Path $MC96_SHARE_PATH -FullAccess "Everyone" -ErrorAction SilentlyContinue

# Share user folder
Write-Color "Sharing user profile..." "Yellow"
$USER_PATH = $env:USERPROFILE
Remove-SmbShare -Name "${MACHINE_NAME}_Home" -Force -ErrorAction SilentlyContinue
New-SmbShare -Name "${MACHINE_NAME}_Home" -Path $USER_PATH -FullAccess "Everyone" -ErrorAction SilentlyContinue

# Share Documents
if (Test-Path "$USER_PATH\Documents") {
    Write-Color "Sharing Documents..." "Yellow"
    Remove-SmbShare -Name "${MACHINE_NAME}_Documents" -Force -ErrorAction SilentlyContinue
    New-SmbShare -Name "${MACHINE_NAME}_Documents" -Path "$USER_PATH\Documents" -FullAccess "Everyone" -ErrorAction SilentlyContinue
}

# Share Desktop
if (Test-Path "$USER_PATH\Desktop") {
    Write-Color "Sharing Desktop..." "Yellow"
    Remove-SmbShare -Name "${MACHINE_NAME}_Desktop" -Force -ErrorAction SilentlyContinue
    New-SmbShare -Name "${MACHINE_NAME}_Desktop" -Path "$USER_PATH\Desktop" -FullAccess "Everyone" -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Color "✓ Folder sharing configured" "Green"
Write-Host ""

# List all shares
Write-Color "Current shares:" "Cyan"
Get-SmbShare | Where-Object { $_.Name -notlike "*$" } | ForEach-Object {
    Write-Host "  $($_.Name) → $($_.Path)"
}
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 5: MOUNT NETWORK DEVICES
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 5: Mounting All Network Devices..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

# Drive letters to use
$DriveLetters = @('G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P')
$DriveIndex = 0
$MountedCount = 0

foreach ($Device in $Devices) {
    if ($Device.IP -eq $MY_IP) {
        continue
    }
    
    if ($DriveIndex -ge $DriveLetters.Count) {
        Write-Color "  ⚠ No more drive letters available" "Yellow"
        break
    }
    
    $DriveLetter = $DriveLetters[$DriveIndex]
    Write-Color "Attempting to mount: $($Device.Name) ($($Device.IP)) as ${DriveLetter}:..." "Yellow"
    
    # Remove existing mapping
    net use "${DriveLetter}:" /delete 2>$null | Out-Null
    
    # Try to mount (try common share names)
    $ShareNames = @("share", "${Device.Name}_MC96", "${Device.Name}_Home")
    $Mounted = $false
    
    foreach ($ShareName in $ShareNames) {
        $NetworkPath = "\\$($Device.IP)\$ShareName"
        
        try {
            net use "${DriveLetter}:" $NetworkPath /user:$MC96_USER $MC96_PASS /persistent:yes 2>$null | Out-Null
            
            if ($LASTEXITCODE -eq 0) {
                Write-Color "  ✓ Mounted successfully as ${DriveLetter}: ($ShareName)" "Green"
                $MountedCount++
                $DriveIndex++
                $Mounted = $true
                break
            }
        }
        catch {
            # Try next share name
        }
    }
    
    if (!$Mounted) {
        Write-Color "  ○ Could not mount (may need SMB enabled on remote)" "Yellow"
    }
}

Write-Host ""
Write-Color "✓ Successfully mounted $MountedCount devices" "Green"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 6: CREATE AUTO-MOUNT SCRIPT
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 6: Creating Auto-Mount Script for Login..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

$AUTO_MOUNT_SCRIPT = "C:\MC96\mount_network.ps1"
New-Item -ItemType Directory -Path "C:\MC96" -Force -ErrorAction SilentlyContinue | Out-Null

# Create device mapping
$DeviceMapping = ""
foreach ($Device in $Devices) {
    if ($Device.IP -ne $MY_IP) {
        $DeviceMapping += "    @{Name='$($Device.Name)'; IP='$($Device.IP)'}," + "`n"
    }
}

$AutoMountContent = @"
# MC96 Auto-Mount Script
# Mounts all MC96 network devices at login

`$MC96_USER = "$MC96_USER"
`$MC96_PASS = "$MC96_PASS"

# Device list
`$Devices = @(
$DeviceMapping
)

# Drive letters to use
`$DriveLetters = @('G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P')
`$DriveIndex = 0

Write-Host "MC96 Network Auto-Mount Starting..." -ForegroundColor Cyan

foreach (`$Device in `$Devices) {
    if (`$DriveIndex -ge `$DriveLetters.Count) { break }
    
    `$DriveLetter = `$DriveLetters[`$DriveIndex]
    
    # Remove existing mapping
    net use "`${DriveLetter}:" /delete 2>`$null | Out-Null
    
    # Try common share names
    `$ShareNames = @("share", "`$(`$Device.Name)_MC96", "`$(`$Device.Name)_Home")
    
    foreach (`$ShareName in `$ShareNames) {
        `$NetworkPath = "\\`$(`$Device.IP)\`$ShareName"
        
        try {
            net use "`${DriveLetter}:" `$NetworkPath /user:`$MC96_USER `$MC96_PASS /persistent:yes 2>`$null | Out-Null
            
            if (`$LASTEXITCODE -eq 0) {
                Write-Host "  ✓ Mounted: `$(`$Device.Name) as `${DriveLetter}:" -ForegroundColor Green
                `$DriveIndex++
                break
            }
        }
        catch { }
    }
}

Write-Host "MC96 Network Auto-Mount Complete!" -ForegroundColor Green
"@

$AutoMountContent | Out-File $AUTO_MOUNT_SCRIPT -Encoding UTF8

Write-Color "✓ Auto-mount script created: $AUTO_MOUNT_SCRIPT" "Green"
Write-Host ""

# Create scheduled task for auto-mount
$TaskName = "MC96_Network_AutoMount"

# Remove existing task
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue

# Create new task
$Action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$AUTO_MOUNT_SCRIPT`""
$Trigger = New-ScheduledTaskTrigger -AtLogon
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal | Out-Null

Write-Color "✓ Scheduled task created for auto-mount at login" "Green"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 7: CREATE NETWORK DASHBOARD
# ═══════════════════════════════════════════════════════════════════════

Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Color "PHASE 7: Creating Network Dashboard..." "Cyan"
Write-Color "═══════════════════════════════════════════════════════════════════════" "Cyan"
Write-Host ""

$DASHBOARD_SCRIPT = "C:\MC96\network_dashboard.ps1"

$DashboardContent = @"
# MC96 Network Dashboard

Clear-Host
Write-Host "╔══════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                                                                      ║" -ForegroundColor Cyan
Write-Host "║          MC96ECOUNIVERSE - NETWORK STATUS DASHBOARD                  ║" -ForegroundColor Cyan
Write-Host "║                                                                      ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# My IP
`$MY_IP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { `$_.IPAddress -like "10.90.90.*" }).IPAddress
Write-Host "This Machine: `$MY_IP (`$env:COMPUTERNAME)"
Write-Host ""

# Network devices
Write-Host "Network Devices:"
Write-Host "────────────────────────────────────────────────────────────────────────"
1..50 | ForEach-Object {
    `$IP = "10.90.90.`$_"
    if (Test-Connection -ComputerName `$IP -Count 1 -Quiet -TimeoutSeconds 1) {
        try {
            `$HostName = [System.Net.Dns]::GetHostEntry(`$IP).HostName
        }
        catch {
            `$HostName = "Unknown"
        }
        Write-Host "  ✓ `$IP - `$HostName - ONLINE" -ForegroundColor Green
    }
}
Write-Host ""

# Mounted drives
Write-Host "Mounted Network Drives:"
Write-Host "────────────────────────────────────────────────────────────────────────"
Get-PSDrive | Where-Object { `$_.Provider.Name -eq "FileSystem" -and `$_.DisplayRoot -like "\\*" } | ForEach-Object {
    Write-Host "  ✓ `$(`$_.Name): → `$(`$_.DisplayRoot)" -ForegroundColor Green
}
Write-Host ""

# Active shares
Write-Host "Active Shares on This Machine:"
Write-Host "────────────────────────────────────────────────────────────────────────"
Get-SmbShare | Where-Object { `$_.Name -notlike "*`$" } | ForEach-Object {
    Write-Host "  `$(`$_.Name) → `$(`$_.Path)"
}
Write-Host ""

Write-Host "Press any key to exit..."
`$null = `$Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
"@

$DashboardContent | Out-File $DASHBOARD_SCRIPT -Encoding UTF8

Write-Color "✓ Dashboard created: $DASHBOARD_SCRIPT" "Green"
Write-Host ""

# Create desktop shortcut
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\MC96 Network Dashboard.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$DASHBOARD_SCRIPT`""
$Shortcut.IconLocation = "imageres.dll,75"
$Shortcut.Save()

Write-Color "✓ Desktop shortcut created" "Green"
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════
# SETUP COMPLETE
# ═══════════════════════════════════════════════════════════════════════

Write-Host ""
Write-Color "╔══════════════════════════════════════════════════════════════════════╗" "Green"
Write-Color "║                                                                      ║" "Green"
Write-Color "║          MC96 NETWORK SETUP COMPLETE!                                ║" "Green"
Write-Color "║                                                                      ║" "Green"
Write-Color "╚══════════════════════════════════════════════════════════════════════╝" "Green"
Write-Host ""

Write-Color "WHAT WAS CONFIGURED:" "Cyan"
Write-Host ""
Write-Host "  ✓ Discovered $($Devices.Count) devices on MC96 network"
Write-Host "  ✓ Created unified user: $MC96_USER"
Write-Host "  ✓ Enabled SMB file sharing"
Write-Host "  ✓ Shared important folders"
Write-Host "  ✓ Configured firewall"
Write-Host "  ✓ Mounted $MountedCount network devices"
Write-Host "  ✓ Created auto-mount script"
Write-Host "  ✓ Created network dashboard"
Write-Host ""

Write-Color "NETWORK ACCESS:" "Cyan"
Write-Host ""
Write-Host "  Username: " -NoNewline
Write-Color "$MC96_USER" "Green"
Write-Host "  Password: " -NoNewline
Write-Color "[configured]" "Green"
Write-Host ""

Write-Color "USEFUL SCRIPTS:" "Cyan"
Write-Host ""
Write-Color "  $AUTO_MOUNT_SCRIPT" "Yellow"
Write-Host "    → Mount all network devices manually"
Write-Host ""
Write-Color "  $DASHBOARD_SCRIPT" "Yellow"
Write-Host "    → View network status dashboard"
Write-Host ""

Write-Color "NEXT STEPS:" "Cyan"
Write-Host ""
Write-Host "  1. Run this script on ALL OTHER WINDOWS PCs in MC96 network"
Write-Host "  2. Run MC96_NETWORK_MASTER_SETUP_MAC.sh on all Macs"
Write-Host "  3. Reboot all machines to activate auto-mount"
Write-Host "  4. Access any device from any device!"
Write-Host ""

Write-Color "MC96ECOUNIVERSE is now unified! 🚀" "Green"
Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
