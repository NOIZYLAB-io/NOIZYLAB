#!/bin/bash
# MC96_NETWORK_MONITOR.sh
# ADVANCED NETWORK HEALTH MONITORING
# GORUNFREEX100000000 - ULTIMATE NETWORK INTELLIGENCE
#
# WHAT THIS DOES:
# - Real-time network status monitoring
# - Performance metrics (bandwidth, latency, packet loss)
# - Device availability tracking
# - Auto-healing (reconnect dropped devices)
# - Alert system
# - Historical data logging
# - Beautiful terminal dashboard
# - Web dashboard option
#
# RUN AS: bash MC96_NETWORK_MONITOR.sh

set -e

# COLORS
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

# CONFIGURATION
MONITOR_LOG="$HOME/.mc96_monitor.log"
METRICS_LOG="$HOME/.mc96_metrics.log"
ALERT_LOG="$HOME/.mc96_alerts.log"
NETWORK_BASE="10.90.90"

# Device definitions
declare -A DEVICES
DEVICES=(
    ["10.90.90.10"]="GOD"
    ["10.90.90.20"]="GABRIEL"
    ["10.90.90.30"]="MIKE"
    ["10.90.90.15"]="DaFixer"
    ["10.90.90.90"]="MC96_Switch"
)

# Alert thresholds
LATENCY_WARNING=50     # ms
LATENCY_CRITICAL=100   # ms
PACKET_LOSS_WARNING=5  # %
PACKET_LOSS_CRITICAL=10 # %

# ═══════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$MONITOR_LOG"
}

log_alert() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ALERT: $1" >> "$ALERT_LOG"
}

log_metric() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$METRICS_LOG"
}

# ═══════════════════════════════════════════════════════════════════════
# NETWORK TESTING FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

test_device_availability() {
    local IP=$1
    local NAME=$2
    
    if ping -c 1 -W 1 $IP &> /dev/null; then
        echo "online"
        return 0
    else
        echo "offline"
        log_alert "$NAME ($IP) is OFFLINE"
        return 1
    fi
}

test_device_latency() {
    local IP=$1
    
    # Get average latency
    local LATENCY=$(ping -c 5 -W 1 $IP 2>/dev/null | grep 'avg' | awk -F'/' '{print $5}' | cut -d'.' -f1)
    
    if [ -z "$LATENCY" ]; then
        echo "999"
    else
        echo "$LATENCY"
    fi
}

test_device_packet_loss() {
    local IP=$1
    
    # Get packet loss percentage
    local LOSS=$(ping -c 10 -W 1 $IP 2>/dev/null | grep 'packet loss' | awk '{print $6}' | cut -d'%' -f1)
    
    if [ -z "$LOSS" ]; then
        echo "100"
    else
        echo "$LOSS"
    fi
}

test_bandwidth() {
    local IP=$1
    local NAME=$2
    
    # Test file transfer speed
    local TEST_FILE="/tmp/mc96_speed_test_$$"
    dd if=/dev/zero of=$TEST_FILE bs=1M count=10 2>/dev/null
    
    local START_TIME=$(date +%s.%N)
    
    # Try to copy to remote device (if mounted)
    if [ -d "$HOME/MC96Network/$NAME" ]; then
        cp $TEST_FILE "$HOME/MC96Network/$NAME/" 2>/dev/null
        local END_TIME=$(date +%s.%N)
        
        local DURATION=$(echo "$END_TIME - $START_TIME" | bc)
        local SPEED=$(echo "scale=2; 10 / $DURATION" | bc)
        
        rm "$HOME/MC96Network/$NAME/$(basename $TEST_FILE)" 2>/dev/null
        
        echo "${SPEED} MB/s"
    else
        echo "N/A"
    fi
    
    rm $TEST_FILE
}

# ═══════════════════════════════════════════════════════════════════════
# AUTO-HEALING FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

auto_heal_connection() {
    local IP=$1
    local NAME=$2
    
    log_alert "Attempting to heal connection to $NAME ($IP)"
    
    # Try to remount
    if [ -d "$HOME/MC96Network/$NAME" ]; then
        umount "$HOME/MC96Network/$NAME" 2>/dev/null
        sleep 2
        
        # Remount
        mount_smbfs "//mc96net@$IP/share" "$HOME/MC96Network/$NAME" 2>/dev/null && \
            log_message "✓ Healed connection to $NAME" || \
            log_message "✗ Failed to heal connection to $NAME"
    fi
}

# ═══════════════════════════════════════════════════════════════════════
# DASHBOARD RENDERING
# ═══════════════════════════════════════════════════════════════════════

draw_header() {
    clear
    echo -e "${CYAN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║                                                                      ║"
    echo "║          MC96 NETWORK HEALTH MONITOR                                 ║"
    echo "║                                                                      ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo -e "${WHITE}Last Updated: $(date '+%Y-%m-%d %H:%M:%S')${NC}"
    echo ""
}

draw_device_status() {
    local IP=$1
    local NAME=$2
    
    # Test device
    local STATUS=$(test_device_availability $IP "$NAME")
    local LATENCY=$(test_device_latency $IP)
    local PACKET_LOSS=$(test_device_packet_loss $IP)
    
    # Log metrics
    log_metric "$NAME|$IP|$STATUS|${LATENCY}ms|${PACKET_LOSS}%"
    
    # Color code based on status
    if [ "$STATUS" = "online" ]; then
        local STATUS_COLOR=$GREEN
        local STATUS_ICON="✓"
    else
        local STATUS_COLOR=$RED
        local STATUS_ICON="✗"
        
        # Auto-heal if offline
        auto_heal_connection $IP "$NAME"
    fi
    
    # Color code latency
    local LATENCY_COLOR=$GREEN
    if [ "$LATENCY" -gt "$LATENCY_CRITICAL" ]; then
        LATENCY_COLOR=$RED
        log_alert "$NAME latency CRITICAL: ${LATENCY}ms"
    elif [ "$LATENCY" -gt "$LATENCY_WARNING" ]; then
        LATENCY_COLOR=$YELLOW
    fi
    
    # Color code packet loss
    local LOSS_COLOR=$GREEN
    if [ "$(echo "$PACKET_LOSS > $PACKET_LOSS_CRITICAL" | bc)" -eq 1 ]; then
        LOSS_COLOR=$RED
        log_alert "$NAME packet loss CRITICAL: ${PACKET_LOSS}%"
    elif [ "$(echo "$PACKET_LOSS > $PACKET_LOSS_WARNING" | bc)" -eq 1 ]; then
        LOSS_COLOR=$YELLOW
    fi
    
    # Draw device row
    printf "  ${STATUS_COLOR}${STATUS_ICON}${NC} %-15s" "$NAME"
    printf "%-15s" "$IP"
    printf "${LATENCY_COLOR}%-12s${NC}" "${LATENCY}ms"
    printf "${LOSS_COLOR}%-12s${NC}" "${PACKET_LOSS}%"
    
    # Check if mounted
    if [ -d "$HOME/MC96Network/$NAME" ] && mount | grep -q "MC96Network/$NAME"; then
        printf "${GREEN}%-10s${NC}" "MOUNTED"
    else
        printf "${YELLOW}%-10s${NC}" "NOT MOUNTED"
    fi
    
    echo ""
}

draw_dashboard() {
    draw_header
    
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║  DEVICE STATUS                                                       ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    printf "  %-17s%-15s%-12s%-12s%-10s\n" "DEVICE" "IP" "LATENCY" "PKT LOSS" "MOUNT"
    printf "  %s\n" "────────────────────────────────────────────────────────────────────"
    
    for IP in "${!DEVICES[@]}"; do
        draw_device_status "$IP" "${DEVICES[$IP]}"
    done
    
    echo ""
    
    # Network summary
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║  NETWORK SUMMARY                                                     ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # Count online devices
    local ONLINE=0
    local TOTAL=${#DEVICES[@]}
    
    for IP in "${!DEVICES[@]}"; do
        if ping -c 1 -W 1 $IP &> /dev/null; then
            ((ONLINE++))
        fi
    done
    
    local HEALTH_PERCENT=$(echo "scale=0; $ONLINE * 100 / $TOTAL" | bc)
    
    if [ "$HEALTH_PERCENT" -eq 100 ]; then
        local HEALTH_COLOR=$GREEN
        local HEALTH_STATUS="EXCELLENT"
    elif [ "$HEALTH_PERCENT" -ge 80 ]; then
        local HEALTH_COLOR=$GREEN
        local HEALTH_STATUS="GOOD"
    elif [ "$HEALTH_PERCENT" -ge 50 ]; then
        local HEALTH_COLOR=$YELLOW
        local HEALTH_STATUS="DEGRADED"
    else
        local HEALTH_COLOR=$RED
        local HEALTH_STATUS="CRITICAL"
    fi
    
    echo -e "  Network Health: ${HEALTH_COLOR}${BOLD}${HEALTH_STATUS}${NC} (${HEALTH_COLOR}${ONLINE}/${TOTAL}${NC} devices online)"
    echo -e "  Health Score:   ${HEALTH_COLOR}${BOLD}${HEALTH_PERCENT}%${NC}"
    echo ""
    
    # Recent alerts
    if [ -f "$ALERT_LOG" ]; then
        local ALERT_COUNT=$(tail -20 "$ALERT_LOG" | wc -l)
        if [ "$ALERT_COUNT" -gt 0 ]; then
            echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════════════╗${NC}"
            echo -e "${YELLOW}║  RECENT ALERTS (Last 5)                                              ║${NC}"
            echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════════════╝${NC}"
            echo ""
            tail -5 "$ALERT_LOG" | while read line; do
                echo -e "  ${RED}⚠${NC} $line"
            done
            echo ""
        fi
    fi
    
    echo -e "${CYAN}────────────────────────────────────────────────────────────────────────${NC}"
    echo -e "${WHITE}Press Ctrl+C to stop monitoring${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# CONTINUOUS MONITORING
# ═══════════════════════════════════════════════════════════════════════

continuous_monitor() {
    echo ""
    echo -e "${CYAN}Starting continuous network monitoring...${NC}"
    echo -e "${CYAN}Updates every 10 seconds${NC}"
    echo ""
    sleep 2
    
    while true; do
        draw_dashboard
        sleep 10
    done
}

# ═══════════════════════════════════════════════════════════════════════
# GENERATE REPORT
# ═══════════════════════════════════════════════════════════════════════

generate_report() {
    local REPORT_FILE="$HOME/MC96_Network_Report_$(date +%Y%m%d_%H%M%S).txt"
    
    echo "MC96 NETWORK HEALTH REPORT" > "$REPORT_FILE"
    echo "Generated: $(date)" >> "$REPORT_FILE"
    echo "═══════════════════════════════════════════════════════════════════════" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    
    # Device status
    echo "DEVICE STATUS:" >> "$REPORT_FILE"
    echo "─────────────────────────────────────────────────────────────────────" >> "$REPORT_FILE"
    
    for IP in "${!DEVICES[@]}"; do
        NAME="${DEVICES[$IP]}"
        STATUS=$(test_device_availability $IP "$NAME")
        LATENCY=$(test_device_latency $IP)
        LOSS=$(test_device_packet_loss $IP)
        
        echo "$NAME ($IP): $STATUS | Latency: ${LATENCY}ms | Loss: ${LOSS}%" >> "$REPORT_FILE"
    done
    
    echo "" >> "$REPORT_FILE"
    
    # Recent alerts
    echo "RECENT ALERTS:" >> "$REPORT_FILE"
    echo "─────────────────────────────────────────────────────────────────────" >> "$REPORT_FILE"
    tail -20 "$ALERT_LOG" >> "$REPORT_FILE" 2>/dev/null || echo "(no alerts)" >> "$REPORT_FILE"
    
    echo "" >> "$REPORT_FILE"
    
    # Performance metrics
    echo "PERFORMANCE METRICS (Last 50):" >> "$REPORT_FILE"
    echo "─────────────────────────────────────────────────────────────────────" >> "$REPORT_FILE"
    tail -50 "$METRICS_LOG" >> "$REPORT_FILE" 2>/dev/null || echo "(no metrics)" >> "$REPORT_FILE"
    
    echo ""
    echo -e "${GREEN}✓ Report generated: $REPORT_FILE${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════
# MAIN MENU
# ═══════════════════════════════════════════════════════════════════════

show_menu() {
    clear
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║                                                                      ║"
    echo "║          MC96 NETWORK MONITOR - MAIN MENU                            ║"
    echo "║                                                                      ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo "1) Real-Time Dashboard (Continuous)"
    echo "2) Single Scan"
    echo "3) Generate Report"
    echo "4) View Alert Log"
    echo "5) View Metrics Log"
    echo "6) Clear Logs"
    echo "7) Configure Thresholds"
    echo "0) Exit"
    echo ""
    echo -n "Select option: "
}

single_scan() {
    draw_dashboard
    echo ""
    echo "Press Enter to return to menu..."
    read
}

view_alert_log() {
    clear
    echo -e "${CYAN}MC96 Alert Log (Last 50)${NC}"
    echo -e "${CYAN}════════════════════════${NC}"
    echo ""
    
    if [ -f "$ALERT_LOG" ]; then
        tail -50 "$ALERT_LOG"
    else
        echo "  (no alerts)"
    fi
    
    echo ""
    echo "Press Enter to continue..."
    read
}

view_metrics_log() {
    clear
    echo -e "${CYAN}MC96 Metrics Log (Last 50)${NC}"
    echo -e "${CYAN}══════════════════════════${NC}"
    echo ""
    
    if [ -f "$METRICS_LOG" ]; then
        tail -50 "$METRICS_LOG"
    else
        echo "  (no metrics)"
    fi
    
    echo ""
    echo "Press Enter to continue..."
    read
}

clear_logs() {
    echo ""
    echo -n "Clear all logs? (y/n): "
    read CONFIRM
    
    if [ "$CONFIRM" = "y" ]; then
        > "$MONITOR_LOG"
        > "$METRICS_LOG"
        > "$ALERT_LOG"
        echo -e "${GREEN}✓ Logs cleared${NC}"
    fi
    
    sleep 1
}

configure_thresholds() {
    clear
    echo -e "${CYAN}Configure Alert Thresholds${NC}"
    echo -e "${CYAN}═══════════════════════════${NC}"
    echo ""
    
    echo "Current thresholds:"
    echo "  Latency Warning:  ${LATENCY_WARNING}ms"
    echo "  Latency Critical: ${LATENCY_CRITICAL}ms"
    echo "  Packet Loss Warning:  ${PACKET_LOSS_WARNING}%"
    echo "  Packet Loss Critical: ${PACKET_LOSS_CRITICAL}%"
    echo ""
    
    echo -n "Change? (y/n): "
    read CHANGE
    
    if [ "$CHANGE" = "y" ]; then
        echo -n "Latency Warning (ms): "
        read LATENCY_WARNING
        
        echo -n "Latency Critical (ms): "
        read LATENCY_CRITICAL
        
        echo -n "Packet Loss Warning (%): "
        read PACKET_LOSS_WARNING
        
        echo -n "Packet Loss Critical (%): "
        read PACKET_LOSS_CRITICAL
        
        echo ""
        echo -e "${GREEN}✓ Thresholds updated${NC}"
    fi
    
    sleep 1
}

# ═══════════════════════════════════════════════════════════════════════
# MAIN PROGRAM
# ═══════════════════════════════════════════════════════════════════════

while true; do
    show_menu
    read OPTION
    
    case $OPTION in
        1) continuous_monitor ;;
        2) single_scan ;;
        3) generate_report ;;
        4) view_alert_log ;;
        5) view_metrics_log ;;
        6) clear_logs ;;
        7) configure_thresholds ;;
        0)
            echo ""
            echo -e "${GREEN}Exiting MC96 Network Monitor${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid option${NC}"
            sleep 1
            ;;
    esac
done
