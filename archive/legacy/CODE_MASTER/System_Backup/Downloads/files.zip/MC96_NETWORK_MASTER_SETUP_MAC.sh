#!/bin/bash
# MC96_NETWORK_MASTER_SETUP_MAC.sh
# ONE COMMAND NETWORK SETUP FOR ALL MACS
# GORUNFREEX100000000 - ULTIMATE NETWORK AUTOMATION
#
# WHAT THIS DOES:
# - Auto-discovers all MC96 devices on network
# - Enables SMB file sharing
# - Creates unified user account
# - Shares important folders
# - Mounts all other devices
# - Sets up auto-mount at login
# - Configures firewall
# - Tests all connections
# - Creates network dashboard
# - Sets up real-time sync (optional)
#
# RUN AS: sudo bash MC96_NETWORK_MASTER_SETUP_MAC.sh

set -e

# COLORS
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# CONFIGURATION
MC96_USER="mc96net"
MC96_PASS="MC96Supreme2025"  # CHANGE THIS!
NETWORK_BASE="10.90.90"
MOUNT_BASE="$HOME/MC96Network"

# BANNER
clear
echo -e "${CYAN}"
echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║                                                                      ║"
echo "║          MC96 NETWORK MASTER SETUP - MAC VERSION                     ║"
echo "║                GORUNFREEX100000000                                   ║"
echo "║                                                                      ║"
echo "║          ONE COMMAND → COMPLETE NETWORK AUTOMATION                   ║"
echo "║                                                                      ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# CHECK ROOT
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Please run as root: sudo bash $0${NC}"
    exit 1
fi

# GET ACTUAL USER
ACTUAL_USER="${SUDO_USER:-$USER}"
ACTUAL_HOME=$(eval echo "~$ACTUAL_USER")

echo -e "${YELLOW}Running as: $ACTUAL_USER${NC}"
echo -e "${YELLOW}Home directory: $ACTUAL_HOME${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 1: DISCOVER MC96 NETWORK
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 1: Discovering MC96ECOUNIVERSE Network...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Get this machine's IP
MY_IP=$(ifconfig | grep "inet $NETWORK_BASE" | awk '{print $2}' | head -1)
echo -e "${GREEN}✓ This machine: $MY_IP${NC}"
echo ""

# Discover all devices on network
echo -e "${YELLOW}Scanning network $NETWORK_BASE.0/24...${NC}"
DEVICES=()
DEVICE_NAMES=()

for i in {1..254}; do
    IP="$NETWORK_BASE.$i"
    if [ "$IP" != "$MY_IP" ]; then
        if ping -c 1 -W 1 $IP &> /dev/null; then
            # Try to get hostname
            HOSTNAME=$(host $IP 2>/dev/null | awk '{print $NF}' | sed 's/\.$//')
            if [ -z "$HOSTNAME" ] || [ "$HOSTNAME" == "found:" ]; then
                HOSTNAME="Device-$i"
            fi
            
            DEVICES+=("$IP")
            DEVICE_NAMES+=("$HOSTNAME")
            
            echo -e "${GREEN}  ✓ Found: $IP ($HOSTNAME)${NC}"
        fi
    fi
done

echo ""
echo -e "${GREEN}✓ Discovered ${#DEVICES[@]} devices on MC96 network${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 2: CREATE UNIFIED USER ACCOUNT
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 2: Creating Unified Network User...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Check if user exists
if id "$MC96_USER" &>/dev/null; then
    echo -e "${YELLOW}User $MC96_USER already exists - resetting password...${NC}"
    dscl . -passwd /Users/$MC96_USER "$MC96_PASS"
else
    echo -e "${YELLOW}Creating user: $MC96_USER${NC}"
    
    # Create user
    dscl . -create /Users/$MC96_USER
    dscl . -create /Users/$MC96_USER UserShell /bin/bash
    dscl . -create /Users/$MC96_USER RealName "MC96 Network Admin"
    dscl . -create /Users/$MC96_USER UniqueID 503
    dscl . -create /Users/$MC96_USER PrimaryGroupID 20
    dscl . -create /Users/$MC96_USER NFSHomeDirectory /Users/$MC96_USER
    dscl . -passwd /Users/$MC96_USER "$MC96_PASS"
    
    # Create home directory
    createhomedir -c -u $MC96_USER
    
    # Add to admin group
    dscl . -append /Groups/admin GroupMembership $MC96_USER
    
    echo -e "${GREEN}✓ User $MC96_USER created${NC}"
fi

echo -e "${GREEN}✓ Username: $MC96_USER${NC}"
echo -e "${GREEN}✓ Password: [configured]${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 3: ENABLE SMB FILE SHARING
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 3: Enabling SMB File Sharing...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Enable SMB
echo -e "${YELLOW}Enabling SMB daemon...${NC}"
launchctl load -w /System/Library/LaunchDaemons/com.apple.smbd.plist 2>/dev/null || true

# Configure SMB user
echo -e "${YELLOW}Configuring SMB for user $MC96_USER...${NC}"
dscl . -append /Users/$MC96_USER SMBHome "$MC96_USER"

echo -e "${GREEN}✓ SMB enabled and configured${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 4: SHARE IMPORTANT FOLDERS
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 4: Sharing Important Folders...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Detect machine name for share naming
MACHINE_NAME=$(scutil --get ComputerName | tr ' ' '_')
echo -e "${YELLOW}Machine name: $MACHINE_NAME${NC}"
echo ""

# Share home directory
echo -e "${YELLOW}Sharing home directory...${NC}"
sharing -a "$ACTUAL_HOME" -S "${MACHINE_NAME}_Home" -g 000 2>/dev/null || true

# Share common folders if they exist
if [ -d "$ACTUAL_HOME/Music" ]; then
    echo -e "${YELLOW}Sharing Music folder...${NC}"
    sharing -a "$ACTUAL_HOME/Music" -S "${MACHINE_NAME}_Music" -g 000 2>/dev/null || true
fi

if [ -d "$ACTUAL_HOME/Documents" ]; then
    echo -e "${YELLOW}Sharing Documents folder...${NC}"
    sharing -a "$ACTUAL_HOME/Documents" -S "${MACHINE_NAME}_Documents" -g 000 2>/dev/null || true
fi

if [ -d "$ACTUAL_HOME/Desktop" ]; then
    echo -e "${YELLOW}Sharing Desktop folder...${NC}"
    sharing -a "$ACTUAL_HOME/Desktop" -S "${MACHINE_NAME}_Desktop" -g 000 2>/dev/null || true
fi

# Check for external drives
echo -e "${YELLOW}Checking for external drives...${NC}"
for VOLUME in /Volumes/*; do
    if [ "$VOLUME" != "/Volumes/Macintosh HD" ] && [ -d "$VOLUME" ]; then
        VOLUME_NAME=$(basename "$VOLUME" | tr ' ' '_')
        echo -e "${YELLOW}  Sharing: $VOLUME_NAME${NC}"
        sharing -a "$VOLUME" -S "${MACHINE_NAME}_${VOLUME_NAME}" -g 000 2>/dev/null || true
    fi
done

echo ""
echo -e "${GREEN}✓ Folder sharing configured${NC}"
echo ""

# List all shares
echo -e "${CYAN}Current shares:${NC}"
sharing -l 2>/dev/null | grep -v "^$" || echo "  (none visible)"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 5: CONFIGURE FIREWALL
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 5: Configuring Firewall for Network Access...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Check if firewall is on
FIREWALL_STATE=$(/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate | grep -o 'enabled\|disabled')

if [ "$FIREWALL_STATE" == "enabled" ]; then
    echo -e "${YELLOW}Firewall is enabled - adding SMB exception...${NC}"
    /usr/libexec/ApplicationFirewall/socketfilterfw --add /usr/sbin/smbd 2>/dev/null || true
    /usr/libexec/ApplicationFirewall/socketfilterfw --unblockapp /usr/sbin/smbd 2>/dev/null || true
    echo -e "${GREEN}✓ SMB allowed through firewall${NC}"
else
    echo -e "${GREEN}✓ Firewall is disabled - no configuration needed${NC}"
fi

echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 6: CREATE MOUNT POINTS AND MOUNT NETWORK DEVICES
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 6: Mounting All Network Devices...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Create mount base directory
mkdir -p "$ACTUAL_HOME/MC96Network"
chown $ACTUAL_USER:staff "$ACTUAL_HOME/MC96Network"

# Mount each discovered device
MOUNTED_COUNT=0
for i in "${!DEVICES[@]}"; do
    DEVICE_IP="${DEVICES[$i]}"
    DEVICE_NAME="${DEVICE_NAMES[$i]}"
    
    if [ "$DEVICE_IP" == "$MY_IP" ]; then
        continue
    fi
    
    echo -e "${YELLOW}Attempting to mount: $DEVICE_NAME ($DEVICE_IP)...${NC}"
    
    # Create mount point
    MOUNT_POINT="$ACTUAL_HOME/MC96Network/$DEVICE_NAME"
    mkdir -p "$MOUNT_POINT"
    chown $ACTUAL_USER:staff "$MOUNT_POINT"
    
    # Try to mount
    # Note: This will fail if the device doesn't have SMB enabled, which is OK
    sudo -u $ACTUAL_USER mount_smbfs "//$MC96_USER:$MC96_PASS@$DEVICE_IP/share" "$MOUNT_POINT" 2>/dev/null && \
        echo -e "${GREEN}  ✓ Mounted successfully${NC}" && \
        ((MOUNTED_COUNT++)) || \
        echo -e "${YELLOW}  ○ Could not mount (may need SMB enabled on remote)${NC}"
done

echo ""
echo -e "${GREEN}✓ Successfully mounted $MOUNTED_COUNT devices${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 7: CREATE AUTO-MOUNT SCRIPT
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 7: Creating Auto-Mount Script for Login...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

# Create auto-mount script
AUTO_MOUNT_SCRIPT="$ACTUAL_HOME/mc96_auto_mount.sh"

cat > "$AUTO_MOUNT_SCRIPT" << 'EOFSCRIPT'
#!/bin/bash
# MC96 Auto-Mount Script
# Mounts all MC96 network devices at login

MOUNT_BASE="$HOME/MC96Network"
MC96_USER="mc96net"
MC96_PASS="MC96Supreme2025"

# Create base directory
mkdir -p "$MOUNT_BASE"

# Device list (will be populated by setup script)
DEVICES_TO_MOUNT

# Mount each device
for DEVICE in "${DEVICES[@]}"; do
    IFS=':' read -r NAME IP <<< "$DEVICE"
    MOUNT_POINT="$MOUNT_BASE/$NAME"
    
    mkdir -p "$MOUNT_POINT"
    
    # Unmount if already mounted
    umount "$MOUNT_POINT" 2>/dev/null
    
    # Try to mount
    mount_smbfs "//$MC96_USER:$MC96_PASS@$IP/share" "$MOUNT_POINT" 2>/dev/null && \
        echo "✓ Mounted: $NAME ($IP)" || \
        echo "○ Could not mount: $NAME ($IP)"
done

echo "MC96 Network Mount Complete!"
EOFSCRIPT

# Add device list to script
DEVICE_ARRAY="DEVICES=(\n"
for i in "${!DEVICES[@]}"; do
    if [ "${DEVICES[$i]}" != "$MY_IP" ]; then
        DEVICE_ARRAY+="    \"${DEVICE_NAMES[$i]}:${DEVICES[$i]}\"\n"
    fi
done
DEVICE_ARRAY+=")"

# Replace placeholder
sed -i '' "s|DEVICES_TO_MOUNT|$DEVICE_ARRAY|" "$AUTO_MOUNT_SCRIPT"

# Set permissions
chmod +x "$AUTO_MOUNT_SCRIPT"
chown $ACTUAL_USER:staff "$AUTO_MOUNT_SCRIPT"

echo -e "${GREEN}✓ Auto-mount script created: $AUTO_MOUNT_SCRIPT${NC}"
echo ""

# Create LaunchAgent for auto-mount
LAUNCH_AGENT_DIR="$ACTUAL_HOME/Library/LaunchAgents"
mkdir -p "$LAUNCH_AGENT_DIR"

LAUNCH_AGENT_PLIST="$LAUNCH_AGENT_DIR/com.mc96.network.automount.plist"

cat > "$LAUNCH_AGENT_PLIST" << EOFPLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.mc96.network.automount</string>
    <key>ProgramArguments</key>
    <array>
        <string>$AUTO_MOUNT_SCRIPT</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$ACTUAL_HOME/mc96_mount.log</string>
    <key>StandardErrorPath</key>
    <string>$ACTUAL_HOME/mc96_mount_error.log</string>
</dict>
</plist>
EOFPLIST

chown $ACTUAL_USER:staff "$LAUNCH_AGENT_PLIST"

echo -e "${GREEN}✓ LaunchAgent created for auto-mount at login${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# PHASE 8: CREATE NETWORK DASHBOARD
# ═══════════════════════════════════════════════════════════════════════

echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}PHASE 8: Creating Network Dashboard...${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
echo ""

DASHBOARD_SCRIPT="$ACTUAL_HOME/mc96_network_dashboard.sh"

cat > "$DASHBOARD_SCRIPT" << 'EOFDASH'
#!/bin/bash
# MC96 Network Dashboard

clear
echo "╔══════════════════════════════════════════════════════════════════════╗"
echo "║                                                                      ║"
echo "║          MC96ECOUNIVERSE - NETWORK STATUS DASHBOARD                  ║"
echo "║                                                                      ║"
echo "╚══════════════════════════════════════════════════════════════════════╝"
echo ""

# My IP
MY_IP=$(ifconfig | grep "inet 10.90.90" | awk '{print $2}' | head -1)
echo "This Machine: $MY_IP"
echo ""

# Network devices
echo "Network Devices:"
echo "────────────────────────────────────────────────────────────────────────"
for i in {10..50}; do
    IP="10.90.90.$i"
    if ping -c 1 -W 1 $IP &> /dev/null; then
        HOSTNAME=$(host $IP 2>/dev/null | awk '{print $NF}' | sed 's/\.$//')
        [ -z "$HOSTNAME" ] && HOSTNAME="Unknown"
        echo "  ✓ $IP - $HOSTNAME - ONLINE"
    fi
done
echo ""

# Mounted shares
echo "Mounted Network Shares:"
echo "────────────────────────────────────────────────────────────────────────"
mount | grep smbfs | while read -r line; do
    echo "  ✓ $line"
done
echo ""

# Active shares
echo "Active Shares on This Machine:"
echo "────────────────────────────────────────────────────────────────────────"
sharing -l 2>/dev/null | grep -v "^$" || echo "  (none)"
echo ""

echo "Press any key to exit..."
read -n 1
EOFDASH

chmod +x "$DASHBOARD_SCRIPT"
chown $ACTUAL_USER:staff "$DASHBOARD_SCRIPT"

echo -e "${GREEN}✓ Dashboard created: $DASHBOARD_SCRIPT${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════
# SETUP COMPLETE
# ═══════════════════════════════════════════════════════════════════════

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}║          MC96 NETWORK SETUP COMPLETE!                                ║${NC}"
echo -e "${GREEN}║                                                                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${CYAN}WHAT WAS CONFIGURED:${NC}"
echo ""
echo -e "  ✓ Discovered ${#DEVICES[@]} devices on MC96 network"
echo -e "  ✓ Created unified user: $MC96_USER"
echo -e "  ✓ Enabled SMB file sharing"
echo -e "  ✓ Shared important folders"
echo -e "  ✓ Configured firewall"
echo -e "  ✓ Mounted $MOUNTED_COUNT network devices"
echo -e "  ✓ Created auto-mount script"
echo -e "  ✓ Created network dashboard"
echo ""

echo -e "${CYAN}NETWORK ACCESS:${NC}"
echo ""
echo -e "  Username: ${GREEN}$MC96_USER${NC}"
echo -e "  Password: ${GREEN}[configured]${NC}"
echo ""

echo -e "${CYAN}USEFUL COMMANDS:${NC}"
echo ""
echo -e "  ${YELLOW}$AUTO_MOUNT_SCRIPT${NC}"
echo -e "    → Mount all network devices manually"
echo ""
echo -e "  ${YELLOW}$DASHBOARD_SCRIPT${NC}"
echo -e "    → View network status dashboard"
echo ""
echo -e "  ${YELLOW}ls ~/MC96Network/${NC}"
echo -e "    → Browse all mounted devices"
echo ""

echo -e "${CYAN}NEXT STEPS:${NC}"
echo ""
echo -e "  1. Run this script on ${YELLOW}ALL OTHER MACS${NC} in MC96 network"
echo -e "  2. Run ${YELLOW}MC96_NETWORK_MASTER_SETUP_WIN.ps1${NC} on Windows PCs"
echo -e "  3. Reboot all machines to activate auto-mount"
echo -e "  4. Access any device from any device!"
echo ""

echo -e "${GREEN}MC96ECOUNIVERSE is now unified! 🚀${NC}"
echo ""
