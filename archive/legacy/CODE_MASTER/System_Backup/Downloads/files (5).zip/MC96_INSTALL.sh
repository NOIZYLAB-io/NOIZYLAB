#!/bin/bash
###############################################################################
#
#   ███╗   ███╗ ██████╗ █████╗  ██████╗     ██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗     
#   ████╗ ████║██╔════╝██╔══██╗██╔════╝    ██╔╝████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║     
#   ██╔████╔██║██║     ╚██████║███████╗   ██╔╝ ██╔██╗ ██║███████╗   ██║   ███████║██║     ██║     
#   ██║╚██╔╝██║██║      ╚═══██║██╔═══██╗ ██╔╝  ██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║     
#   ██║ ╚═╝ ██║╚██████╗ █████╔╝╚██████╔╝██╔╝   ██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗
#   ╚═╝     ╚═╝ ╚═════╝ ╚════╝  ╚═════╝ ╚═╝    ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝
#
#                        MC96 COMPLETE SYSTEM INSTALLATION
#                            ONE COMMAND = EVERYTHING
#
###############################################################################
#
#  GORUNFREE Philosophy: ONE COMMAND → COMPLETE SETUP → ZERO CONFIGURATION
#
#  What This Does:
#  ✅ Installs all MC96 scripts and tools
#  ✅ Configures network settings
#  ✅ Sets up automated backups
#  ✅ Installs MC96 Master Control
#  ✅ Configures cron jobs
#  ✅ Creates directory structure
#  ✅ Tests all connections
#  ✅ Generates configuration report
#
#  Execute: bash MC96_INSTALL.sh
#
###############################################################################

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m'

# Banner
clear
cat << 'EOF'
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║                   MC96 SYSTEM INSTALLATION                        ║
║                                                                   ║
║              Mission Control 96 - Complete Setup                  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝

EOF

echo -e "${CYAN}${BOLD}Starting MC96 installation...${NC}\n"
sleep 2

# Detect system
if [[ "$OSTYPE" == "darwin"* ]]; then
    SYSTEM="GOD"
    BASE_PATH="/Users/rsp_ms"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo -e "${YELLOW}Linux detected. Adapting for Linux...${NC}"
    SYSTEM="LINUX"
    BASE_PATH="$HOME"
else
    echo -e "${RED}Unsupported OS: $OSTYPE${NC}"
    echo "This script is designed for macOS (GOD) or Linux."
    echo "For Windows (GABRIEL), run the PowerShell installation script."
    exit 1
fi

echo -e "${GREEN}✓ System detected: ${BOLD}$SYSTEM${NC}\n"

# Configuration
SCRIPTS_DIR="$BASE_PATH/scripts"
LOGS_DIR="$BASE_PATH/logs"
AI_DIR="$BASE_PATH/AI"
PROJECTS_DIR="$BASE_PATH/Projects"
AQUARIUM_DIR="$BASE_PATH/THE_AQUARIUM"
RENDERS_DIR="$BASE_PATH/RENDERS"

# Functions
log() {
    echo -e "${CYAN}[$(date +'%H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
}

# Create directory structure
log "Creating directory structure..."

directories=(
    "$SCRIPTS_DIR"
    "$LOGS_DIR"
    "$AI_DIR"
    "$PROJECTS_DIR"
    "$AQUARIUM_DIR"
    "$RENDERS_DIR"
)

for dir in "${directories[@]}"; do
    if [ ! -d "$dir" ]; then
        mkdir -p "$dir"
        success "Created: $dir"
    else
        success "Exists: $dir"
    fi
done

echo ""

# Install Python dependencies
log "Checking Python dependencies..."

if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    success "Python 3 found: $PYTHON_VERSION"
    
    # Check for required packages
    REQUIRED_PACKAGES=("psutil")
    
    for package in "${REQUIRED_PACKAGES[@]}"; do
        if python3 -c "import $package" 2>/dev/null; then
            success "$package installed"
        else
            log "Installing $package..."
            pip3 install "$package" --user --quiet
            success "$package installed"
        fi
    done
else
    warning "Python 3 not found. Installing via Homebrew..."
    if command -v brew &> /dev/null; then
        brew install python3
    else
        error "Homebrew not found. Please install Python 3 manually."
    fi
fi

echo ""

# Copy MC96 scripts
log "Installing MC96 scripts..."

# Check if we're in the outputs directory
CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

scripts_to_install=(
    "MC96_MASTER_CONTROL.py"
    "daily_backup_GOD.sh"
)

for script in "${scripts_to_install[@]}"; do
    if [ -f "$CURRENT_DIR/$script" ]; then
        cp "$CURRENT_DIR/$script" "$SCRIPTS_DIR/"
        chmod +x "$SCRIPTS_DIR/$script"
        success "Installed: $script"
    else
        warning "$script not found in current directory"
    fi
done

echo ""

# Configure network settings
log "Checking network configuration..."

# Test connectivity to key systems
GABRIEL_IP="192.168.1.20"
NAS_IP="192.168.1.30"
SWITCH_IP="192.168.1.1"

test_connection() {
    local host=$1
    local name=$2
    
    if ping -c 1 -W 1 "$host" &> /dev/null; then
        success "$name ($host) - ONLINE"
        return 0
    else
        warning "$name ($host) - OFFLINE"
        return 1
    fi
}

test_connection "$GABRIEL_IP" "GABRIEL"
test_connection "$NAS_IP" "NAS"
test_connection "$SWITCH_IP" "Switch"

echo ""

# Set up cron job for daily backups
log "Configuring automated backups..."

CRON_JOB="0 2 * * * $SCRIPTS_DIR/daily_backup_GOD.sh"

# Check if cron job already exists
if crontab -l 2>/dev/null | grep -q "daily_backup_GOD.sh"; then
    success "Backup cron job already configured"
else
    # Add cron job
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    success "Backup cron job configured (2:00 AM daily)"
fi

echo ""

# Create command aliases
log "Creating command aliases..."

ALIAS_FILE="$BASE_PATH/.bash_profile"
if [[ "$SHELL" == *"zsh"* ]]; then
    ALIAS_FILE="$BASE_PATH/.zshrc"
fi

# Add aliases if they don't exist
if ! grep -q "alias mc96=" "$ALIAS_FILE" 2>/dev/null; then
    cat >> "$ALIAS_FILE" << ALIASEOF

# MC96 Aliases
alias mc96='python3 $SCRIPTS_DIR/MC96_MASTER_CONTROL.py'
alias mc96-backup='$SCRIPTS_DIR/daily_backup_GOD.sh'
alias mc96-logs='tail -f $LOGS_DIR/backup_*.log'
ALIASEOF
    success "Command aliases added to $ALIAS_FILE"
else
    success "Command aliases already configured"
fi

echo ""

# Test MC96 Master Control
log "Testing MC96 Master Control..."

if [ -f "$SCRIPTS_DIR/MC96_MASTER_CONTROL.py" ]; then
    # Test if it runs
    if python3 "$SCRIPTS_DIR/MC96_MASTER_CONTROL.py" help &> /dev/null; then
        success "MC96 Master Control operational"
    else
        warning "MC96 Master Control may have issues"
    fi
else
    warning "MC96 Master Control not found"
fi

echo ""

# Generate configuration report
log "Generating configuration report..."

REPORT_FILE="$BASE_PATH/MC96_INSTALLATION_REPORT.txt"

cat > "$REPORT_FILE" << REPORTEOF
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║               MC96 INSTALLATION REPORT                            ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝

Installation Date: $(date)
System: $SYSTEM
Base Path: $BASE_PATH

DIRECTORIES CREATED:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
$(for dir in "${directories[@]}"; do echo "  ✓ $dir"; done)

SCRIPTS INSTALLED:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
$(ls -1 "$SCRIPTS_DIR")

NETWORK STATUS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  GABRIEL ($GABRIEL_IP): $(ping -c 1 -W 1 $GABRIEL_IP &>/dev/null && echo "ONLINE" || echo "OFFLINE")
  NAS ($NAS_IP): $(ping -c 1 -W 1 $NAS_IP &>/dev/null && echo "ONLINE" || echo "OFFLINE")
  Switch ($SWITCH_IP): $(ping -c 1 -W 1 $SWITCH_IP &>/dev/null && echo "ONLINE" || echo "OFFLINE")

AUTOMATED BACKUPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Schedule: Daily at 2:00 AM
  Script: $SCRIPTS_DIR/daily_backup_GOD.sh
  Logs: $LOGS_DIR/

COMMAND ALIASES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  mc96            Launch MC96 Master Control
  mc96-backup     Run backup manually
  mc96-logs       View backup logs

NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Reload your shell: source $ALIAS_FILE
2. Test MC96: mc96 status
3. Test backup: mc96-backup
4. Configure DGS1210-10 switch (see documentation)
5. Set up remote desktop (Parsec recommended)

DOCUMENTATION:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Complete guide: MC96_COMPLETE_PIPELINE_FLOW.md

═══════════════════════════════════════════════════════════════════

MC96 installation complete! 🚀

═══════════════════════════════════════════════════════════════════
REPORTEOF

success "Configuration report generated: $REPORT_FILE"

echo ""

# Final summary
cat << SUMMARYEOF

${BOLD}${GREEN}╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║              MC96 INSTALLATION COMPLETE ✓                         ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝${NC}

${CYAN}${BOLD}WHAT WAS INSTALLED:${NC}

${GREEN}✓${NC} Directory structure created
${GREEN}✓${NC} MC96 Master Control installed
${GREEN}✓${NC} Backup scripts configured
${GREEN}✓${NC} Cron jobs scheduled
${GREEN}✓${NC} Command aliases added
${GREEN}✓${NC} Python dependencies installed

${CYAN}${BOLD}IMMEDIATE NEXT STEPS:${NC}

${YELLOW}1.${NC} Reload your shell:
   ${BOLD}source $ALIAS_FILE${NC}

${YELLOW}2.${NC} Test MC96 Master Control:
   ${BOLD}mc96 status${NC}

${YELLOW}3.${NC} View complete documentation:
   ${BOLD}cat MC96_COMPLETE_PIPELINE_FLOW.md${NC}

${YELLOW}4.${NC} Configure DGS1210-10 switch (see documentation)

${YELLOW}5.${NC} Set up remote desktop between GOD and GABRIEL

${CYAN}${BOLD}DAILY COMMANDS:${NC}

  ${BOLD}mc96${NC}              Launch interactive control
  ${BOLD}mc96 status${NC}       Show system status
  ${BOLD}mc96-backup${NC}       Run backup manually
  ${BOLD}mc96-logs${NC}         View backup logs

${CYAN}${BOLD}REPORT:${NC}

Full installation report saved to:
${BOLD}$REPORT_FILE${NC}

${GREEN}${BOLD}═══════════════════════════════════════════════════════════════════

              MC96 IS OPERATIONAL. GO COMMAND YOUR EMPIRE.

═══════════════════════════════════════════════════════════════════${NC}

SUMMARYEOF

# Play success sound if available
if command -v afplay &> /dev/null; then
    afplay /System/Library/Sounds/Glass.aiff 2>/dev/null &
fi

# Voice notification
if command -v say &> /dev/null; then
    say "MC96 installation complete. System operational." &
fi

exit 0
