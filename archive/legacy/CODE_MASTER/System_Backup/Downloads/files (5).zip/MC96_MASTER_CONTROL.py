#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║                   MC96 MASTER CONTROL SYSTEM                      ║
║                                                                   ║
║              Complete Ecosystem Command & Control                ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝

GORUNFREE Philosophy: ONE COMMAND = EVERYTHING DONE

Author: Rob Plowman / Fish Music Inc.
System: MC96 (Mission Control 96)
Version: 1.0.0
"""

import subprocess
import os
import sys
import json
import socket
import platform
import psutil
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class MC96System:
    """Base system configuration and constants"""
    
    # Network Configuration
    GOD_IP = "192.168.1.10"
    GABRIEL_IP = "192.168.1.20"
    NAS_IP = "192.168.1.30"
    SWITCH_IP = "192.168.1.1"
    
    # System Paths
    if platform.system() == "Darwin":  # macOS (GOD)
        BASE_PATH = Path("/Users/rsp_ms")
        PROJECTS_PATH = BASE_PATH / "Projects"
        AQUARIUM_PATH = BASE_PATH / "THE_AQUARIUM"
        RENDERS_PATH = BASE_PATH / "RENDERS"
        SCRIPTS_PATH = BASE_PATH / "scripts"
        LOGS_PATH = BASE_PATH / "logs"
    else:  # Windows (GABRIEL)
        BASE_PATH = Path("C:/Users/Rob")
        PROJECTS_PATH = BASE_PATH / "Projects"
        RENDERS_PATH = BASE_PATH / "Renders"
        BACKUPS_PATH = BASE_PATH / "BACKUPS"
        SCRIPTS_PATH = BASE_PATH / "Scripts"
        LOGS_PATH = BASE_PATH / "Logs"
    
    # Ensure directories exist
    for path in [LOGS_PATH, SCRIPTS_PATH]:
        path.mkdir(parents=True, exist_ok=True)


class SystemMonitor:
    """Real-time system monitoring"""
    
    @staticmethod
    def get_cpu_usage() -> float:
        """Get current CPU usage percentage"""
        return psutil.cpu_percent(interval=1)
    
    @staticmethod
    def get_memory_usage() -> Tuple[float, float]:
        """Get memory usage (used GB, total GB)"""
        mem = psutil.virtual_memory()
        return (mem.used / (1024**3), mem.total / (1024**3))
    
    @staticmethod
    def get_disk_usage(path: str = "/") -> Tuple[float, float, float]:
        """Get disk usage (used GB, total GB, percent)"""
        disk = psutil.disk_usage(path)
        return (
            disk.used / (1024**3),
            disk.total / (1024**3),
            disk.percent
        )
    
    @staticmethod
    def get_network_latency(host: str, count: int = 4) -> Optional[float]:
        """Measure network latency to host"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["ping", "-n", str(count), host],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
            else:  # macOS/Linux
                result = subprocess.run(
                    ["ping", "-c", str(count), host],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
            
            if result.returncode == 0:
                # Parse average latency from output
                output = result.stdout
                if "avg" in output or "Average" in output:
                    for line in output.split('\n'):
                        if 'avg' in line.lower() or 'average' in line.lower():
                            # Extract average value
                            parts = line.split('=')[-1].split('/')
                            if len(parts) >= 2:
                                return float(parts[1].strip().split()[0])
                return 0.0
            return None
        except Exception as e:
            print(f"Error measuring latency: {e}")
            return None
    
    @staticmethod
    def check_host_online(host: str) -> bool:
        """Check if host is reachable"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["ping", "-n", "1", "-w", "1000", host],
                    capture_output=True,
                    timeout=2
                )
            else:
                result = subprocess.run(
                    ["ping", "-c", "1", "-W", "1", host],
                    capture_output=True,
                    timeout=2
                )
            return result.returncode == 0
        except:
            return False
    
    @staticmethod
    def get_running_processes(filter_name: Optional[str] = None) -> List[Dict]:
        """Get list of running processes"""
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            try:
                if filter_name is None or filter_name.lower() in proc.info['name'].lower():
                    processes.append(proc.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return processes


class MC96MasterControl:
    """Main control system for MC96 ecosystem"""
    
    def __init__(self):
        self.config = MC96System()
        self.monitor = SystemMonitor()
        self.current_system = self._detect_system()
        
        print(f"{Colors.CYAN}{Colors.BOLD}")
        print("╔═══════════════════════════════════════════════════════════════════╗")
        print("║                                                                   ║")
        print("║                   MC96 MASTER CONTROL ONLINE                      ║")
        print("║                                                                   ║")
        print("╚═══════════════════════════════════════════════════════════════════╝")
        print(f"{Colors.END}")
        print(f"\n{Colors.GREEN}System detected: {self.current_system}{Colors.END}")
        print(f"{Colors.YELLOW}Type 'help' for available commands or 'status' for system overview{Colors.END}\n")
    
    def _detect_system(self) -> str:
        """Detect which system we're running on"""
        hostname = socket.gethostname().lower()
        if "god" in hostname or platform.system() == "Darwin":
            return "GOD"
        elif "gabriel" in hostname or platform.system() == "Windows":
            return "GABRIEL"
        else:
            return "UNKNOWN"
    
    def execute_command(self, command: str) -> str:
        """Main command router"""
        cmd_lower = command.lower().strip()
        
        # Help command
        if cmd_lower in ['help', 'h', '?']:
            return self._show_help()
        
        # Status commands
        elif cmd_lower in ['status', 'stat', 's']:
            return self._show_status()
        
        elif cmd_lower in ['status god', 'god status']:
            return self._show_god_status()
        
        elif cmd_lower in ['status gabriel', 'gabriel status']:
            return self._show_gabriel_status()
        
        elif cmd_lower in ['status network', 'network status', 'network']:
            return self._show_network_status()
        
        # Render commands
        elif 'render' in cmd_lower:
            if 'start' in cmd_lower:
                return self._start_render()
            elif 'status' in cmd_lower or 'check' in cmd_lower:
                return self._check_render_status()
            elif 'queue' in cmd_lower:
                return self._show_render_queue()
            else:
                return "Render commands: 'render start', 'render status', 'render queue'"
        
        # Backup commands
        elif 'backup' in cmd_lower:
            if 'start' in cmd_lower or 'run' in cmd_lower:
                return self._start_backup()
            elif 'status' in cmd_lower or 'check' in cmd_lower:
                return self._check_backup_status()
            else:
                return self._start_backup()
        
        # File transfer commands
        elif 'transfer' in cmd_lower or 'sync' in cmd_lower:
            return self._transfer_files()
        
        # Process monitoring
        elif 'processes' in cmd_lower or 'proc' in cmd_lower:
            return self._show_processes()
        
        # Dashboard
        elif cmd_lower in ['dashboard', 'dash', 'd']:
            return self._show_dashboard()
        
        # Clear screen
        elif cmd_lower in ['clear', 'cls']:
            os.system('cls' if os.name == 'nt' else 'clear')
            return ""
        
        # Exit
        elif cmd_lower in ['exit', 'quit', 'q']:
            return "EXIT"
        
        else:
            return f"{Colors.RED}Unknown command: '{command}'. Type 'help' for available commands.{Colors.END}"
    
    def _show_help(self) -> str:
        """Display help information"""
        help_text = f"""
{Colors.BOLD}{Colors.CYAN}MC96 MASTER CONTROL - AVAILABLE COMMANDS{Colors.END}

{Colors.BOLD}SYSTEM STATUS:{Colors.END}
  status              Show complete system overview
  status god          Show GOD (Mac Studio) status
  status gabriel      Show GABRIEL (HP OMEN) status
  status network      Show network performance

{Colors.BOLD}RENDERING:{Colors.END}
  render start        Start render queue on GABRIEL
  render status       Check current render progress
  render queue        Show pending renders

{Colors.BOLD}BACKUP:{Colors.END}
  backup              Start backup process
  backup status       Check backup progress

{Colors.BOLD}FILE OPERATIONS:{Colors.END}
  transfer            Transfer files between systems
  sync                Sync project folders

{Colors.BOLD}MONITORING:{Colors.END}
  processes           Show running processes
  dashboard           Real-time system dashboard

{Colors.BOLD}GENERAL:{Colors.END}
  help                Show this help message
  clear               Clear screen
  exit                Exit MC96 Master Control

{Colors.YELLOW}TIP: Commands are case-insensitive and flexible.
     'render start' = 'start render' = 'Render Start'{Colors.END}
"""
        return help_text
    
    def _show_status(self) -> str:
        """Show complete system status"""
        status = f"\n{Colors.BOLD}{Colors.CYAN}═══ MC96 SYSTEM STATUS ═══{Colors.END}\n"
        
        # Current system
        status += f"\n{Colors.BOLD}Current System:{Colors.END} {self.current_system}\n"
        
        # Local system stats
        cpu = self.monitor.get_cpu_usage()
        mem_used, mem_total = self.monitor.get_memory_usage()
        disk_used, disk_total, disk_percent = self.monitor.get_disk_usage()
        
        status += f"\n{Colors.BOLD}{self.current_system} Status:{Colors.END}\n"
        status += f"  CPU Usage:    {cpu:.1f}%\n"
        status += f"  Memory:       {mem_used:.1f}GB / {mem_total:.1f}GB ({mem_used/mem_total*100:.1f}%)\n"
        status += f"  Disk:         {disk_used:.1f}GB / {disk_total:.1f}GB ({disk_percent:.1f}%)\n"
        
        # Remote system check
        if self.current_system == "GOD":
            remote_name = "GABRIEL"
            remote_ip = self.config.GABRIEL_IP
        else:
            remote_name = "GOD"
            remote_ip = self.config.GOD_IP
        
        status += f"\n{Colors.BOLD}{remote_name} Status:{Colors.END}\n"
        if self.monitor.check_host_online(remote_ip):
            status += f"  {Colors.GREEN}● ONLINE{Colors.END}\n"
            latency = self.monitor.get_network_latency(remote_ip, count=2)
            if latency:
                status += f"  Latency:      {latency:.1f}ms\n"
        else:
            status += f"  {Colors.RED}● OFFLINE{Colors.END}\n"
        
        # Network status
        status += f"\n{Colors.BOLD}Network:{Colors.END}\n"
        switch_online = self.monitor.check_host_online(self.config.SWITCH_IP)
        if switch_online:
            status += f"  Switch:       {Colors.GREEN}● ONLINE{Colors.END}\n"
        else:
            status += f"  Switch:       {Colors.RED}● OFFLINE{Colors.END}\n"
        
        status += f"\n{Colors.BOLD}Timestamp:{Colors.END} {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        return status
    
    def _show_god_status(self) -> str:
        """Show GOD system status"""
        if self.current_system == "GOD":
            return self._show_status()
        else:
            # Try to query remotely
            if self.monitor.check_host_online(self.config.GOD_IP):
                return f"{Colors.GREEN}GOD is ONLINE{Colors.END}\nLatency: {self.monitor.get_network_latency(self.config.GOD_IP):.1f}ms"
            else:
                return f"{Colors.RED}GOD is OFFLINE{Colors.END}"
    
    def _show_gabriel_status(self) -> str:
        """Show GABRIEL system status"""
        if self.current_system == "GABRIEL":
            return self._show_status()
        else:
            # Try to query remotely
            if self.monitor.check_host_online(self.config.GABRIEL_IP):
                return f"{Colors.GREEN}GABRIEL is ONLINE{Colors.END}\nLatency: {self.monitor.get_network_latency(self.config.GABRIEL_IP):.1f}ms"
            else:
                return f"{Colors.RED}GABRIEL is OFFLINE{Colors.END}"
    
    def _show_network_status(self) -> str:
        """Show network performance"""
        status = f"\n{Colors.BOLD}{Colors.CYAN}═══ NETWORK STATUS ═══{Colors.END}\n\n"
        
        # Test all systems
        systems = [
            ("GOD", self.config.GOD_IP),
            ("GABRIEL", self.config.GABRIEL_IP),
            ("NAS", self.config.NAS_IP),
            ("Switch", self.config.SWITCH_IP)
        ]
        
        for name, ip in systems:
            status += f"{Colors.BOLD}{name}:{Colors.END}\n"
            status += f"  IP: {ip}\n"
            
            if self.monitor.check_host_online(ip):
                status += f"  Status: {Colors.GREEN}● ONLINE{Colors.END}\n"
                latency = self.monitor.get_network_latency(ip, count=2)
                if latency:
                    if latency < 5:
                        color = Colors.GREEN
                    elif latency < 20:
                        color = Colors.YELLOW
                    else:
                        color = Colors.RED
                    status += f"  Latency: {color}{latency:.1f}ms{Colors.END}\n"
            else:
                status += f"  Status: {Colors.RED}● OFFLINE{Colors.END}\n"
            status += "\n"
        
        return status
    
    def _start_render(self) -> str:
        """Start render process"""
        if self.current_system == "GABRIEL":
            # Local render start
            return f"{Colors.GREEN}Starting render queue on GABRIEL...{Colors.END}\n(Implementation: Launch Adobe Media Encoder or render script)"
        else:
            # Remote render start
            return f"{Colors.YELLOW}Sending render command to GABRIEL...{Colors.END}\n(Implementation: SSH to GABRIEL and execute render script)"
    
    def _check_render_status(self) -> str:
        """Check render progress"""
        # Check for render processes
        render_procs = ["Adobe Media Encoder", "Premiere", "After Effects", "Blender"]
        found_procs = []
        
        for proc_name in render_procs:
            procs = self.monitor.get_running_processes(proc_name)
            found_procs.extend(procs)
        
        if found_procs:
            status = f"\n{Colors.BOLD}{Colors.GREEN}Active Rendering Processes:{Colors.END}\n"
            for proc in found_procs:
                status += f"  • {proc['name']} (PID: {proc['pid']}, CPU: {proc['cpu_percent']:.1f}%)\n"
            return status
        else:
            return f"{Colors.YELLOW}No active rendering processes detected{Colors.END}"
    
    def _show_render_queue(self) -> str:
        """Show render queue"""
        return f"{Colors.YELLOW}Render queue: Not implemented yet{Colors.END}\n(Check Adobe Media Encoder or render management software)"
    
    def _start_backup(self) -> str:
        """Start backup process"""
        backup_script = self.config.SCRIPTS_PATH / ("daily_backup.sh" if platform.system() == "Darwin" else "daily_backup.ps1")
        
        if backup_script.exists():
            try:
                if platform.system() == "Darwin":
                    subprocess.Popen(["/bin/bash", str(backup_script)])
                else:
                    subprocess.Popen(["powershell.exe", "-File", str(backup_script)])
                return f"{Colors.GREEN}✓ Backup started successfully{Colors.END}\nLog: {self.config.LOGS_PATH}/backup_{datetime.now().strftime('%Y%m%d')}.log"
            except Exception as e:
                return f"{Colors.RED}✗ Error starting backup: {e}{Colors.END}"
        else:
            return f"{Colors.YELLOW}⚠ Backup script not found: {backup_script}{Colors.END}"
    
    def _check_backup_status(self) -> str:
        """Check backup status"""
        log_file = self.config.LOGS_PATH / f"backup_{datetime.now().strftime('%Y%m%d')}.log"
        
        if log_file.exists():
            # Read last few lines of log
            with open(log_file, 'r') as f:
                lines = f.readlines()
                last_lines = lines[-10:] if len(lines) > 10 else lines
            
            status = f"\n{Colors.BOLD}Recent Backup Log:{Colors.END}\n"
            status += "".join(last_lines)
            return status
        else:
            return f"{Colors.YELLOW}No backup log found for today{Colors.END}"
    
    def _transfer_files(self) -> str:
        """Transfer files between systems"""
        if self.current_system == "GOD":
            source = self.config.RENDERS_PATH
            dest = f"Rob@{self.config.GABRIEL_IP}:/cygdrive/c/Renders/"
            cmd = f"rsync -avz {source}/ {dest}"
        else:
            source = self.config.RENDERS_PATH
            dest = f"rsp_ms@{self.config.GOD_IP}:/Users/rsp_ms/RENDERS/"
            cmd = f"rsync -avz {source}/ {dest}"
        
        return f"{Colors.YELLOW}Transfer command:{Colors.END}\n{cmd}\n\n{Colors.YELLOW}(Execute manually or integrate with automation){Colors.END}"
    
    def _show_processes(self) -> str:
        """Show running processes"""
        # Show key production processes
        key_processes = ["Pro Tools", "Logic", "Premiere", "After Effects", "Blender", "Unity", "Unreal"]
        
        found_procs = []
        for proc_name in key_processes:
            procs = self.monitor.get_running_processes(proc_name)
            found_procs.extend(procs)
        
        if found_procs:
            status = f"\n{Colors.BOLD}{Colors.CYAN}Production Processes:{Colors.END}\n"
            for proc in found_procs:
                status += f"  • {proc['name']} (CPU: {proc['cpu_percent']:.1f}%, MEM: {proc['memory_percent']:.1f}%)\n"
            return status
        else:
            return f"{Colors.YELLOW}No production processes running{Colors.END}"
    
    def _show_dashboard(self) -> str:
        """Show real-time dashboard"""
        # Clear screen first
        os.system('cls' if os.name == 'nt' else 'clear')
        
        dashboard = f"""
{Colors.BOLD}{Colors.CYAN}╔═══════════════════════════════════════════════════════════════════╗
║                  MC96 REAL-TIME DASHBOARD                         ║
╚═══════════════════════════════════════════════════════════════════╝{Colors.END}

{Colors.BOLD}System:{Colors.END} {self.current_system}
{Colors.BOLD}Time:{Colors.END} {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

"""
        
        # Current system stats
        cpu = self.monitor.get_cpu_usage()
        mem_used, mem_total = self.monitor.get_memory_usage()
        disk_used, disk_total, disk_percent = self.monitor.get_disk_usage()
        
        # CPU bar
        cpu_bar = self._create_bar(cpu, 100, 50)
        dashboard += f"{Colors.BOLD}CPU:{Colors.END}    {cpu_bar} {cpu:.1f}%\n"
        
        # Memory bar
        mem_percent = (mem_used / mem_total) * 100
        mem_bar = self._create_bar(mem_percent, 100, 50)
        dashboard += f"{Colors.BOLD}Memory:{Colors.END} {mem_bar} {mem_used:.1f}GB / {mem_total:.1f}GB\n"
        
        # Disk bar
        disk_bar = self._create_bar(disk_percent, 100, 50)
        dashboard += f"{Colors.BOLD}Disk:{Colors.END}   {disk_bar} {disk_used:.0f}GB / {disk_total:.0f}GB\n"
        
        # Network status
        dashboard += f"\n{Colors.BOLD}Network:{Colors.END}\n"
        if self.current_system == "GOD":
            gabriel_online = self.monitor.check_host_online(self.config.GABRIEL_IP)
            dashboard += f"  GABRIEL: {'●' if gabriel_online else '○'} {'ONLINE' if gabriel_online else 'OFFLINE'}\n"
        else:
            god_online = self.monitor.check_host_online(self.config.GOD_IP)
            dashboard += f"  GOD: {'●' if god_online else '○'} {'ONLINE' if god_online else 'OFFLINE'}\n"
        
        dashboard += f"\n{Colors.YELLOW}Press Ctrl+C to return to command mode{Colors.END}\n"
        
        return dashboard
    
    def _create_bar(self, value: float, max_value: float, width: int) -> str:
        """Create a text-based progress bar"""
        filled = int((value / max_value) * width)
        bar = "█" * filled + "░" * (width - filled)
        
        # Color based on value
        if value < 50:
            color = Colors.GREEN
        elif value < 80:
            color = Colors.YELLOW
        else:
            color = Colors.RED
        
        return f"{color}{bar}{Colors.END}"
    
    def run_interactive(self):
        """Run in interactive mode"""
        while True:
            try:
                command = input(f"\n{Colors.BOLD}{Colors.CYAN}MC96>{Colors.END} ")
                
                if not command.strip():
                    continue
                
                result = self.execute_command(command)
                
                if result == "EXIT":
                    print(f"\n{Colors.CYAN}MC96 Master Control shutting down...{Colors.END}")
                    break
                
                if result:
                    print(result)
            
            except KeyboardInterrupt:
                print(f"\n\n{Colors.YELLOW}Use 'exit' to quit{Colors.END}")
            except EOFError:
                break
            except Exception as e:
                print(f"\n{Colors.RED}Error: {e}{Colors.END}")


def main():
    """Main entry point"""
    mc96 = MC96MasterControl()
    
    # Check for command-line arguments
    if len(sys.argv) > 1:
        # Execute single command and exit
        command = " ".join(sys.argv[1:])
        result = mc96.execute_command(command)
        print(result)
    else:
        # Interactive mode
        mc96.run_interactive()


if __name__ == "__main__":
    main()
