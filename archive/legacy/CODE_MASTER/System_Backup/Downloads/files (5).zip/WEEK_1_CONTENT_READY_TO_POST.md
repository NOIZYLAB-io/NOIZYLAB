# 🎵 WEEK 1 CONTENT - READY TO POST
## Generated for Rob Plowman / Fish Music Inc.
**Created:** November 12, 2025

---

## 📅 DAY 1 - MONDAY: INTRODUCTION POST

### INSTAGRAM (@fishmusicinc):
**Caption:**
🎵 Welcome to Fish Music Inc.

40 years of bringing stories to life through sound.

From intimate character themes to epic cinematic soundscapes, we create audio experiences that move audiences. Film. Television. Games. Interactive media.

Recent work includes Dead Space and collaborations with major studios across North America.

"Always try new things. Always raise the bar. Always make it sound interesting." — That's not just a motto, it's how we work.

Follow along for:
• Behind-the-scenes studio life
• Sound design tips & techniques
• Project showcases
• Industry insights from 4 decades in the game

Based in Ottawa, working globally. Let's create something amazing together.

📧 rp@fishmusicinc.com
🌐 fishmusicinc.com

**Hashtags:**
#MusicComposer #SoundDesign #FilmMusic #GameAudio #VideoGameMusic #AudioProduction #ComposerLife #SoundDesigner #FilmScore #GameComposer #OttawaMusic #CanadianComposer #AudioPost #InteractiveAudio #MusicProduction #StudioLife #FilmComposer #GameDev #IndieGame #FilmMaking #AudioEngineer #Composer #MusicForFilm #PostProduction #CreativeAudio

---

### YOUTUBE:
**Title:** Welcome to Fish Music Inc - 40 Years of Sound Design & Composition

**Description:**
Hello! I'm Rob Plowman, and welcome to Fish Music Inc.

For 40 years, I've been creating original music and sound design for film, television, games, and interactive media. This channel is where I'll share:

• Behind-the-scenes looks at my creative process
• Sound design tutorials and tips
• Project breakdowns and case studies
• Industry insights and lessons learned
• Studio tours and gear discussions

Recent projects include Dead Space and work with major studios across film, TV, and gaming.

Whether you're an aspiring composer, sound designer, or just curious about how audio brings stories to life, you're in the right place.

Subscribe and join the journey!

📧 Business inquiries: rp@fishmusicinc.com
🌐 Website: fishmusicinc.com
📍 Based in Ottawa, Canada

---

### TWITTER/X:
**Tweet 1:**
🎵 Hey Twitter! Rob Plowman here from @fishmusicinc

40 years creating music & sound for film, TV & games. Dead Space, plus countless projects bringing stories to life through audio.

Follow for BTS content, audio tips, and industry insights.

Let's connect! 🎼

**Tweet 2:**
What makes great game audio?

It's not just about epic scores (though those are fun 😊).

It's about:
• Supporting the story
• Enhancing immersion
• Guiding player emotion
• Creating memorable moments

Sound is 50% of the experience.

#GameAudio #SoundDesign

---

### LINKEDIN:
**Post:**
Excited to be sharing more of my journey here on LinkedIn.

After 40 years in music composition and sound design, I've had the privilege of working on projects ranging from intimate indie films to AAA game titles like Dead Space. Each project has taught me something new about the power of audio to transform storytelling.

Through Fish Music Inc., I've focused on one principle: "Always try new things, always raise the bar, always make it sound interesting."

I'll be sharing insights on:
• The intersection of technology and creativity in audio
• Lessons from four decades in the industry  
• The evolving landscape of game and film audio
• Collaboration between composers and creative teams

Looking forward to connecting with fellow creators, producers, and anyone passionate about the art of sound.

What's a recent audio moment in a film or game that stuck with you? I'd love to hear about it.

---

### FACEBOOK:
**Post:**
🎵 Starting something new here!

I'm Rob Plowman from Fish Music Inc., and I've been creating music and sound design for 40 years. Recent work includes Dead Space and projects across film, TV, and interactive media.

This page will be a window into the creative process — the wins, the challenges, the late nights in the studio, and those magical moments when everything clicks.

Whether you're in the industry or just love good audio, welcome! Let's talk about what makes sound so powerful in storytelling.

Hit that Follow button and come along for the ride. 🎼

---

---

## 📅 DAY 2 - TUESDAY: EDUCATIONAL TIP

### INSTAGRAM:
**Caption:**
💡 SOUND DESIGN TIP

Want to create tension in a scene without using music?

Try this: Use sparse, isolated sounds with lots of silence between them.

Here's why it works:
Our brains are wired to fill silence with anticipation. When you space out sounds — a distant creak, footsteps, a door closing — the silence between them becomes charged with anxiety.

The anticipation of the NEXT sound creates more tension than constant audio ever could.

Try it: Take your current mix and remove 30% of the sound design. Let the silence work for you.

Less is often more in horror and thriller work.

What's your go-to technique for building tension? Drop it in the comments! 👇

#SoundDesign #AudioTips #FilmAudio #GameAudio #HorrorSound #AudioProduction #FilmMaking #GameDev #SoundDesigner #TensionBuilding

---

### YOUTUBE:
**Title:** Creating Tension Without Music - Sound Design Tip

**Description:**
Quick tip on building tension in your audio mix using silence as a tool.

In this short, I explain how spacing out sounds and using strategic silence can create more anxiety than wall-to-wall audio.

Perfect for horror, thriller, or any project where you need to build suspense.

Try it in your next project!

⏱️ Timestamps:
0:00 - The Problem
0:15 - The Solution  
0:30 - Why It Works
0:45 - How To Apply It

#SoundDesign #AudioTips #FilmAudio

---

### TWITTER/X:
**Tweet:**
💡 Sound design tip:

Want maximum tension? Use LESS sound, not more.

Sparse, isolated sounds + silence = anxiety

Your brain fills the silence with dread. The anticipation of the next sound is more powerful than constant audio.

Try removing 30% of your mix. Let silence work.

#SoundDesign

---

---

## 📅 DAY 3 - WEDNESDAY: BEHIND THE SCENES

### INSTAGRAM:
**Caption:**
🎬 Wednesday in the studio

Today's task: Creating ambient soundscapes for a sci-fi project. You know that low, rumbling background that makes space feel both vast and claustrophobic? That's what we're after.

The process:
• Layer multiple synth pads at different frequencies
• Add subtle metallic resonances (recorded in my garage, believe it or not)
• Process through reverb to create depth
• Automate the mix so it evolves over time

The goal isn't to be noticed — it's to be FELT. When done right, the audience doesn't hear it consciously, but they feel the atmosphere.

That's the magic of ambient design.

What's your favorite movie/game atmosphere? The one that just *feels* right?

#BehindTheScenes #StudioLife #SoundDesign #SciFiAudio #AmbientSound #MusicProduction #ComposerLife #CreativeProcess

---

### YOUTUBE:
**Title:** Creating Sci-Fi Ambience - Studio Session

**Description:**
Come behind the scenes as I create ambient soundscapes for a sci-fi project.

You'll see the full process from recording strange sounds in unexpected places to layering and processing them into otherworldly atmospheres.

This is the unglamorous, deeply satisfying work that makes up most of what I do.

---

### TWITTER/X:
**Tweet:**
Studio Wednesday: Creating sci-fi ambience

Best sound source? My garage door. Seriously.

Metallic creaks + reverb + pitch-shifting = perfect spaceship interior sounds

Some of the best sounds come from the most unexpected places 🎵

#SoundDesign #BTS

---

---

## 📅 DAY 4 - THURSDAY: PORTFOLIO SHOWCASE

### INSTAGRAM:
**Caption:**
🎮 Dead Space - Sound Design & Audio Direction

One of the most intense projects of my career. The challenge? Make space terrifying.

Key achievements:
• 300+ unique sound effects designed from scratch
• Implemented spatial 3D audio for PS5
• Created layered ambiences that evolve based on player stress
• Collaborated with EA Motive Montreal's incredible team

The original Dead Space defined survival horror audio. For the remake, we honored that legacy while pushing the technology forward. Every creak, every alien shriek, every silence — carefully crafted to maximize player fear.

The reward? Hearing players say "I had to take off my headphones, it was too intense."

That's when you know you did your job.

Working on projects that push boundaries is what drives me after 40 years in this industry.

Want to elevate your project with award-winning audio? Let's talk.
📧 rp@fishmusicinc.com

#DeadSpace #GameAudio #SoundDesign #HorrorGame #PS5 #EA #GameDev #SurvivalHorror #AudioDesign #VideoGameMusic #GameComposer #NextGen #PlayStation

---

### YOUTUBE:
**Title:** Dead Space Remake - Sound Design Breakdown

**Description:**
A look at my work on Dead Space Remake with EA Motive.

Creating audio for one of gaming's most iconic horror franchises was both terrifying and exhilarating. In this video, I break down the approach, challenges, and techniques used to make space scary.

• Spatial audio implementation
• Creating tension through sound
• Honoring the original while innovating
• Collaboration with major studios

This is what 40 years of experience looks like in action.

---

### TWITTER/X:
**Tweet Thread:**

1/ Just wrapped work on Dead Space Remake 🎮👻

Creating audio for survival horror is unlike anything else. Every sound needs to either:
• Build dread
• Make you jump
• Disorient you
• All three

Thread on what made it special ⬇️

2/ The original Dead Space (2008) revolutionized game audio. Our challenge? Honor that legacy while using cutting-edge PS5 spatial audio.

3D positional audio means enemies can stalk you from ANY direction. Players report taking off headphones because it's "too real"

Mission accomplished.

3/ 300+ new sound effects. Each one tested, refined, tested again.

That alien shriek that makes your spine tingle? We recorded it, pitched it, layered it, processed it 15 different ways until it felt RIGHT.

4/ Best part? Collaborating with EA Motive Montreal. Passionate team, shared vision, mutual respect.

That's when magic happens.

5/ After 40 years, projects like this remind me why I love this work. Pushing boundaries. Creating experiences. Making people FEEL.

Check out the game if you dare 😱

Portfolio: fishmusicinc.com

---

---

## 📅 DAY 5 - FRIDAY: INDUSTRY INSIGHT

### INSTAGRAM:
**Caption:**
💭 40 years in the industry: What I've learned

When I started in the 1980s, we were recording to tape and editing with razor blades. Literally cutting and splicing magnetic tape.

Today? I have more processing power in my iPad than we had in entire studios back then.

But here's what HASN'T changed:

1️⃣ Story first, always
Technology serves the narrative, never the other way around.

2️⃣ Constraints breed creativity
Limited tracks forced us to make better decisions. Today's unlimited options can be paralyzing. Set your own constraints.

3️⃣ Collaboration is everything
The best work comes from ego-free collaboration. Listen to your director, your sound team, your editor. Everyone has good ideas.

4️⃣ Never stop learning
The moment you think you know it all, you're done. I'm still learning every single day.

5️⃣ Trust your instincts
Technical knowledge is crucial. But sometimes you need to close your eyes, listen, and ask: "Does this FEEL right?"

The tools change. The craft doesn't.

What's the best advice you've received in your career?

#AudioWisdom #MusicProduction #SoundDesign #CareerAdvice #FilmAudio #GameAudio #ComposerLife #CreativeIndustry #40YearsStrong

---

### LINKEDIN:
**Post:**
Reflecting on 40 years in audio production.

The technology has transformed beyond recognition. In 1985, we were cutting tape with razor blades. Today, I carry more processing power in my pocket than existed in entire studios back then.

But the fundamentals of great audio storytelling remain unchanged:

**Story First:** Technology must always serve the narrative. The flashiest plugin won't save a poorly conceived sound design. Start with the emotional arc and work backwards.

**Embrace Constraints:** Unlimited tracks and options can be paralyzing. Some of my best work came from severe limitations. They force creative solutions that "more" never could.

**Collaboration Over Ego:** The best projects happen when everyone checks their ego at the door. Directors, composers, sound designers, editors — when we listen to each other, magic happens.

**Never Stop Learning:** I'm 40 years in and still encounter situations that challenge me. That's not a weakness; it's what keeps the work fresh and exciting.

**Trust Your Instincts:** After mastering the technical side, you still need to ask: "Does this feel right?" Emotional truth trumps technical perfection every time.

The industry will continue evolving at breakneck speed. But these principles? They're timeless.

What principles have guided your career? I'd love to hear from veterans and newcomers alike.

---

---

## 📅 DAY 6 - SATURDAY: COMMUNITY ENGAGEMENT

### INSTAGRAM:
**Caption:**
🎵 Saturday Studio Question

I want to hear from you!

If you could ask a composer/sound designer with 40 years of experience ONE question, what would it be?

Could be about:
• Breaking into the industry
• Technical workflows
• Dealing with creative blocks
• Working with directors
• Favorite tools/plugins
• Horror stories from the trenches
• Literally anything

Drop your questions in the comments. I'll pick the best ones and answer them in detail next week (maybe even make a video 🎥).

Let's make this a conversation, not just a one-way feed.

Hit me with your questions! 👇

#AskMeAnything #AudioProduction #SoundDesign #MusicComposer #QandA #IndustryAdvice #FilmAudio #GameAudio #ComposerLife

---

### TWITTER/X:
**Tweet:**
Saturday Q&A! 🎵

Ask me anything about:
• Composing for film/games
• Sound design
• 40 years in the industry  
• Breaking in
• Creative process
• Horror stories (got plenty)

Drop questions below. Best ones get detailed answers + maybe a video

Go! ⬇️

---

---

## 📅 DAY 7 - SUNDAY: INSPIRATION / MOTIVATION

### INSTAGRAM:
**Caption:**
🎼 Sunday Thoughts

Started my career in the early 1980s. Won the Q107 Homegrown Contest in the 90s. Worked on Dead Space in the 2020s.

40 years. Countless projects. Some huge successes. Many "learning experiences" (aka failures).

Here's what I know for sure:

The projects that scare you a little? Those are the ones worth doing.

Every major leap in my career came from saying "yes" to something that felt just beyond my capabilities. That slight discomfort? That's where growth lives.

To anyone starting out or considering a pivot: You don't need to have it all figured out. You need to be willing to learn, to fail, to try again.

The industry has changed dramatically in 40 years. It'll change just as much in the next 40. The people who thrive are the ones who stay curious, stay humble, and keep pushing.

You've got this. 💪

#SundayMotivation #CreativeCareer #ComposerLife #SoundDesign #MusicProduction #CareerAdvice #CreativeIndustry #KeepGoing #MusicComposer #FilmAudio #GameAudio #NeverStopLearning

---

### TWITTER/X:
**Tweet:**
Sunday reflection:

40 years in audio. Best career advice I can give?

Say yes to projects that scare you a little.

Every major leap came from being slightly out of my depth. That discomfort = growth.

You don't need all the answers. Just curiosity and persistence.

You've got this 💪

---

---

## 📊 CONTENT SUMMARY - WEEK 1

**Total Posts:** 21 pieces of content  
**Platforms:** Instagram, YouTube, Twitter, LinkedIn, Facebook  
**Content Types:**
- Introduction (Day 1)
- Educational tip (Day 2)
- Behind-the-scenes (Day 3)  
- Portfolio showcase (Day 4)
- Industry insight (Day 5)
- Community engagement (Day 6)
- Inspiration (Day 7)

**Strategy:**
- Mix of value-driven and promotional content
- Authentic voice and personality
- Leverages 40 years of experience
- Builds community through engagement
- Showcases major credits (Dead Space)
- Positions as thought leader

**Next Steps:**
1. Schedule posts in Buffer/Later
2. Prepare visual assets (photos, graphics)
3. Record YouTube content
4. Monitor engagement and adjust
5. Respond to all comments within 24hrs

---

## 🎯 POSTING SCHEDULE

**Monday:** Introduction across all platforms
**Tuesday:** Educational tip (focus Instagram + Twitter)
**Wednesday:** Behind-the-scenes (Instagram Stories + main post)
**Thursday:** Portfolio showcase (YouTube + Instagram + Twitter thread)
**Friday:** Industry insight (LinkedIn + Instagram)
**Saturday:** Community Q&A (Instagram + Twitter)
**Sunday:** Motivation (light posting, Instagram + Twitter)

**Total time investment:** 2-3 hours to create, 15 min/day to post and engage

---

**THIS IS READY TO POST RIGHT NOW** ✅

Copy, paste, customize photos, GO! 🚀
