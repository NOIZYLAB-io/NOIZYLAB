#!/bin/bash
# Quick one-liner to install Git shortcuts

bash "$(dirname "$0")/install-git-shortcuts.sh" << EOF
3
Y
EOF
