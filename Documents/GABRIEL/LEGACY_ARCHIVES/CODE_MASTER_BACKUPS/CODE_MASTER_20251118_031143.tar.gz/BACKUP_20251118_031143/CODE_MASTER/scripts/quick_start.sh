#!/bin/bash

# Quick launcher - Just run this to start GABRIEL ULTIMATE
# Usage: bash quick_start.sh

cd "$(dirname "$0")"
chmod +x start_ultimate.sh
./start_ultimate.sh
