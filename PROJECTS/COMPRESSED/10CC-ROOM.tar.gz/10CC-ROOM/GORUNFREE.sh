#!/bin/bash
set -e
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║  🌌 10CC ROOM - AI Constellation                              ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
cd "$(dirname "$0")"
wrangler deploy --minify
echo "✅ https://noizylab-10cc.fishmusicinc.workers.dev"
