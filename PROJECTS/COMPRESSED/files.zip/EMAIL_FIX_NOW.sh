#!/bin/bash
# EMAIL FIX NOW - One-Click Solution for Rob
# Run this on GOD: chmod +x EMAIL_FIX_NOW.sh && ./EMAIL_FIX_NOW.sh

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

clear
echo -e "${BOLD}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║         EMAIL FIX NOW - ROB'S MIRACLE MIGRATION            ║${NC}"
echo -e "${BOLD}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Domains to check
DOMAINS=("fishmusicinc.com" "noizylab.ca" "noizy.ai")

echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}STEP 1: DNS AUDIT${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo ""

for domain in "${DOMAINS[@]}"; do
    echo -e "${YELLOW}━━━ $domain ━━━${NC}"
    
    # NS Check
    echo -n "  Nameservers: "
    ns=$(dig $domain NS +short 2>/dev/null | head -2 | tr '\n' ' ')
    if [[ $ns == *"cloudflare"* ]]; then
        echo -e "${GREEN}✓ Cloudflare${NC} ($ns)"
        NS_OK=true
    elif [[ -z "$ns" ]]; then
        echo -e "${RED}✗ NONE - Domain may not exist or DNS broken!${NC}"
        NS_OK=false
    else
        echo -e "${RED}✗ NOT Cloudflare${NC} ($ns)"
        NS_OK=false
    fi
    
    # MX Check
    echo -n "  Mail (MX):   "
    mx=$(dig $domain MX +short 2>/dev/null | head -2 | tr '\n' ' ')
    if [[ $mx == *"icloud"* ]] || [[ $mx == *"mail.me"* ]]; then
        echo -e "${GREEN}✓ Apple iCloud${NC}"
    elif [[ $mx == *"cloudflare"* ]]; then
        echo -e "${YELLOW}⚠ Cloudflare Routing${NC} (needs migration)"
    elif [[ -z "$mx" ]]; then
        echo -e "${RED}✗ NO MX RECORDS - Email BROKEN!${NC}"
    else
        echo -e "${YELLOW}? Other: $mx${NC}"
    fi
    
    # SPF Check
    echo -n "  SPF:         "
    spf=$(dig $domain TXT +short 2>/dev/null | grep -i "spf" | head -1)
    if [[ $spf == *"icloud"* ]]; then
        echo -e "${GREEN}✓ iCloud${NC}"
    elif [[ $spf == *"cloudflare"* ]]; then
        echo -e "${YELLOW}⚠ Cloudflare${NC} (needs update)"
    elif [[ -z "$spf" ]]; then
        echo -e "${RED}✗ NO SPF${NC}"
    else
        echo -e "${YELLOW}? $spf${NC}"
    fi
    
    # DMARC Check
    echo -n "  DMARC:       "
    dmarc=$(dig _dmarc.$domain TXT +short 2>/dev/null | head -1)
    if [[ -z "$dmarc" ]]; then
        echo -e "${RED}✗ NO DMARC${NC}"
    elif [[ $dmarc == *"reject"* ]]; then
        echo -e "${GREEN}✓ Enforced (reject)${NC}"
    elif [[ $dmarc == *"quarantine"* ]]; then
        echo -e "${YELLOW}⚠ Quarantine mode${NC}"
    else
        echo -e "${YELLOW}⚠ Monitor only (p=none)${NC}"
    fi
    
    echo ""
done

echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}STEP 2: WHAT YOU NEED TO DO${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${BOLD}ACTION 1: Open iCloud Custom Email Domain${NC}"
echo "  → System Settings → Apple Account → iCloud → Mail"
echo "  → Custom Email Domain → Add Domain"
echo ""

echo -e "${BOLD}ACTION 2: Add these domains in iCloud:${NC}"
echo "  • fishmusicinc.com"
echo "  • noizylab.ca" 
echo "  • noizy.ai"
echo ""

echo -e "${BOLD}ACTION 3: Add these email addresses:${NC}"
echo "  • rp@fishmusicinc.com"
echo "  • gofish@fishmusicinc.com"
echo "  • rsp@noizylab.ca"
echo "  • help@noizylab.ca"
echo "  • hello@noizylab.ca"
echo "  • rsp@noizy.ai"
echo ""

echo -e "${BOLD}ACTION 4: Copy Apple's DNS records and paste to Claude${NC}"
echo ""

echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}APPLE iCLOUD TARGET DNS (what it should look like)${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo "  MX Records:"
echo "    mx01.mail.icloud.com (priority 10)"
echo "    mx02.mail.icloud.com (priority 10)"
echo ""
echo "  SPF Record:"
echo "    v=spf1 include:icloud.com ~all"
echo ""
echo "  DKIM: (Apple provides unique values per domain)"
echo ""

echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}QUICK LINKS${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo "  Cloudflare Dashboard:"
echo "    https://dash.cloudflare.com"
echo ""
echo "  Open iCloud Settings (click to open):"

# Try to open System Settings on Mac
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo ""
    read -p "  Press ENTER to open iCloud Mail settings..." 
    open "x-apple.systempreferences:com.apple.preferences.AppleIDPrefPane"
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Done! Copy Apple's DNS records and paste them to Claude.${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
