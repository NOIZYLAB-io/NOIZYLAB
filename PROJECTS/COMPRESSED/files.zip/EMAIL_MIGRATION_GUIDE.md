# EMAIL MIGRATION: CLOUDFLARE → APPLE iCLOUD
## Complete Action Plan for Rob Plowman

---

## TARGET STATE
All these addresses landing in Apple Mail on Mac via iCloud:
- `rp@fishmusicinc.com`
- `gofish@fishmusicinc.com`
- `rsp@noizylab.ca`
- `help@noizylab.ca`
- `hello@noizylab.ca`
- `rsp@noizy.ai`

Primary iCloud: `rsplowman@icloud.com`

---

## PHASE 0: FIX NAMESERVERS (DO THIS FIRST!)

### Problem
fishmusicinc.com shows "Invalid nameservers / pending" in Cloudflare.
**Nothing works until this is fixed.**

### Action
At your domain registrar (GoDaddy?), set nameservers to:
```
brenna.ns.cloudflare.com
damiete.ns.cloudflare.com
```

Do the same for noizylab.ca and noizy.ai - check each zone in Cloudflare for assigned NS.

### Verify (run on GOD):
```bash
dig fishmusicinc.com NS +short
# Should show *.ns.cloudflare.com
```

---

## PHASE 1: APPLE SETUP (GET DNS RECORDS)

### On Mac:
1. **System Settings** → **Apple Account** → **iCloud** → **Mail**
2. Click **Custom Email Domain**
3. Add domain: `fishmusicinc.com`
4. Add addresses: `rp@fishmusicinc.com`, `gofish@fishmusicinc.com`
5. **SCREENSHOT/COPY the DNS records Apple shows you**
6. Repeat for `noizylab.ca` and `noizy.ai`

### What Apple Will Give You:
- **MX records** (usually 2)
- **DKIM records** (CNAME or TXT - unique per domain!)
- **Verification TXT** (sometimes)

**PASTE THESE TO ME AND I'LL GIVE EXACT CLOUDFLARE CHANGES**

---

## PHASE 2: CLOUDFLARE DNS CHANGES

### SAFE ORDER (no downtime):
1. ✅ ADD Apple verification/DKIM records FIRST
2. ⏳ WAIT for Apple to verify domain
3. ✅ SWITCH MX to Apple
4. ✅ UPDATE SPF to iCloud
5. ✅ TEST send/receive
6. ✅ DELETE old Cloudflare Email Routing records

### For fishmusicinc.com (current state → target):

#### DELETE (after verification):
| Type | Name | Old Value |
|------|------|-----------|
| MX | @ | route1.mx.cloudflare.net (prio 65) |
| MX | @ | route2.mx.cloudflare.net (prio 28) |
| MX | @ | route3.mx.cloudflare.net (prio 41) |
| TXT | cf2024-1._domainkey | v=DKIM1;... (Cloudflare DKIM) |

#### ADD:
| Type | Name | New Value | Priority |
|------|------|-----------|----------|
| MX | @ | mx01.mail.icloud.com | 10 |
| MX | @ | mx02.mail.icloud.com | 10 |
| TXT/CNAME | [Apple DKIM selector] | [Apple DKIM value] | - |
| TXT | @ (if Apple requires) | [Apple verification] | - |

#### EDIT:
| Type | Name | Old Value | New Value |
|------|------|-----------|-----------|
| TXT | @ (SPF) | v=spf1 include:_spf.mx.cloudflare.net ~all | v=spf1 include:icloud.com ~all |

#### KEEP:
- DMARC (p=none) - upgrade later
- google-site-verification
- Website A/AAAA records
- www CNAME (add if missing)

---

## PHASE 3: ADD RECOMMENDED RECORDS

### Add www (if missing):
| Type | Name | Value | Proxy |
|------|------|-------|-------|
| CNAME | www | @ | Proxied (orange) |

### Add CAA (cert security):
| Type | Name | Value |
|------|------|-------|
| CAA | @ | 0 issue "letsencrypt.org" |
| CAA | @ | 0 issuewild "letsencrypt.org" |
| CAA | @ | 0 iodef "mailto:rsplowman@icloud.com" |

---

## PHASE 4: APPLE MAIL RULES (ORGANIZE INBOX)

In **Mail.app** → **Settings** → **Rules**, create:

| Rule Name | Condition | Action |
|-----------|-----------|--------|
| NoizyLab Support | To contains help@noizylab.ca | Move to NoizyLab/Support |
| NoizyLab Hello | To contains hello@noizylab.ca | Move to NoizyLab/Hello |
| NoizyLab RSP | To contains rsp@noizylab.ca | Move to NoizyLab/RSP |
| FishMusic RP | To contains rp@fishmusicinc.com | Move to FishMusic/RP |
| FishMusic GoFish | To contains gofish@fishmusicinc.com | Move to FishMusic/GoFish |
| NoizyAI | To contains rsp@noizy.ai | Move to NoizyAI |

---

## PHASE 5: DMARC HARDENING (AFTER 1 WEEK)

### Week 1 (current):
```
v=DMARC1; p=none; rua=mailto:dmarc@yourdomain
```

### Week 2:
```
v=DMARC1; p=quarantine; pct=50; rua=mailto:dmarc@yourdomain
```

### Week 3+:
```
v=DMARC1; p=reject; adkim=s; aspf=s; rua=mailto:dmarc@yourdomain
```

---

## ROLLBACK PLAN (if needed)

### Restore Cloudflare Email Routing for fishmusicinc.com:
```
DELETE Apple MX
ADD:
  MX @ route1.mx.cloudflare.net priority 65
  MX @ route2.mx.cloudflare.net priority 28
  MX @ route3.mx.cloudflare.net priority 41

EDIT SPF back to:
  v=spf1 include:_spf.mx.cloudflare.net ~all

RE-ADD Cloudflare DKIM if saved
```

---

## VERIFICATION COMMANDS (run on GOD)

```bash
# Check MX
dig fishmusicinc.com MX +short
# Should show: mx01.mail.icloud.com, mx02.mail.icloud.com

# Check SPF
dig fishmusicinc.com TXT +short | grep spf
# Should show: v=spf1 include:icloud.com ~all

# Check DMARC
dig _dmarc.fishmusicinc.com TXT +short
# Should show: v=DMARC1; p=...

# Check NS authority
dig fishmusicinc.com NS +short
# Should show: *.ns.cloudflare.com
```

---

## WHAT I NEED FROM YOU

**PASTE THE APPLE DNS RECORDS** from iCloud Custom Email Domain setup:

```
fishmusicinc.com:
MX:
DKIM/verify:

noizylab.ca:
MX:
DKIM/verify:

noizy.ai:
MX:
DKIM/verify:
```

Then I'll give you the EXACT Cloudflare click-path.

---

## iCLOUD CUSTOM EMAIL DOMAIN LIMITS

Apple may limit number of custom domains based on your iCloud plan.
- iCloud+ 50GB: 1 domain
- iCloud+ 200GB: 3 domains  
- iCloud+ 2TB: 5 domains
- Family Sharing: domains shared across family

If you hit the limit, we do a hybrid:
- Host top 2 domains in iCloud
- Forward the third domain into iCloud

---

## QUICK LINKS

- Cloudflare Dashboard: https://dash.cloudflare.com
- Apple iCloud Mail Settings: System Settings → Apple Account → iCloud → Mail
- MX Toolbox (verify): https://mxtoolbox.com/SuperTool.aspx

