#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
#  MC96ECOUNIVERSE VOLUME SCANNER
#  Run on GOD (Mac Studio) to scan all mounted volumes
#  GORUNFREE - One command, full inventory
# ═══════════════════════════════════════════════════════════════════════════

set -e

OUTPUT_DIR="$HOME/MC96ECO_SCAN_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUTPUT_DIR"

echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║           MC96ECOUNIVERSE VOLUME SCANNER                                 ║"
echo "║           Scanning all mounted volumes on $(hostname)                    ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Output directory: $OUTPUT_DIR"
echo "Started: $(date)"
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 1. SYSTEM INFO
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [1/8] Gathering system info..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "MC96ECOUNIVERSE SCAN REPORT"
  echo "Generated: $(date)"
  echo "Hostname: $(hostname)"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  echo "SYSTEM INFO:"
  echo "────────────────────────────────────────────────────────────────────────────"
  uname -a
  echo ""
  
  if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "macOS Version: $(sw_vers -productVersion)"
    echo "Chip: $(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo 'Apple Silicon')"
    echo "Memory: $(sysctl -n hw.memsize | awk '{print $1/1024/1024/1024 " GB"}')"
  fi
  echo ""
} > "$OUTPUT_DIR/00_SYSTEM_INFO.txt"

echo "   ✓ System info saved"

# ═══════════════════════════════════════════════════════════════════════════
# 2. ALL MOUNTED VOLUMES
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [2/8] Listing all mounted volumes..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "ALL MOUNTED VOLUMES"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "── Disk Utility View ──"
    diskutil list
    echo ""
    echo "── Mount Points ──"
    df -h | grep -E "^/dev|Filesystem"
    echo ""
    echo "── /Volumes Contents ──"
    ls -la /Volumes/
  else
    echo "── Mount Points ──"
    df -h
    echo ""
    echo "── Block Devices ──"
    lsblk 2>/dev/null || echo "lsblk not available"
  fi
  echo ""
} > "$OUTPUT_DIR/01_MOUNTED_VOLUMES.txt"

echo "   ✓ Volume list saved"

# ═══════════════════════════════════════════════════════════════════════════
# 3. DISK USAGE SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [3/8] Calculating disk usage..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "DISK USAGE SUMMARY"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  if [[ "$OSTYPE" == "darwin"* ]]; then
    # Mac - detailed per volume
    for vol in /Volumes/*/; do
      if [ -d "$vol" ]; then
        volname=$(basename "$vol")
        echo "────────────────────────────────────────────────────────────────────────────"
        echo "VOLUME: $volname"
        echo "────────────────────────────────────────────────────────────────────────────"
        df -h "$vol" 2>/dev/null | tail -1
        echo ""
      fi
    done
    
    # Main disk
    echo "────────────────────────────────────────────────────────────────────────────"
    echo "MAIN DISK (/):"
    echo "────────────────────────────────────────────────────────────────────────────"
    df -h /
  else
    df -h --total
  fi
  echo ""
} > "$OUTPUT_DIR/02_DISK_USAGE.txt"

echo "   ✓ Disk usage saved"

# ═══════════════════════════════════════════════════════════════════════════
# 4. NETWORK SHARES
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [4/8] Detecting network shares..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "NETWORK SHARES & SMB MOUNTS"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "── SMB/AFP Mounts ──"
    mount | grep -E "smbfs|afpfs|nfs" || echo "No network shares currently mounted"
    echo ""
    echo "── Recently Connected Servers ──"
    defaults read com.apple.finder RecentMoveAndCopyDestinations 2>/dev/null || echo "None found"
  else
    echo "── Network Mounts ──"
    mount | grep -E "cifs|nfs|smb" || echo "No network shares currently mounted"
  fi
  echo ""
} > "$OUTPUT_DIR/03_NETWORK_SHARES.txt"

echo "   ✓ Network shares saved"

# ═══════════════════════════════════════════════════════════════════════════
# 5. FIND LARGE DIRECTORIES (Top storage consumers)
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [5/8] Finding largest directories (this may take a while)..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "LARGEST DIRECTORIES"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  if [[ "$OSTYPE" == "darwin"* ]]; then
    for vol in /Volumes/*/; do
      if [ -d "$vol" ] && [ -r "$vol" ]; then
        volname=$(basename "$vol")
        echo "────────────────────────────────────────────────────────────────────────────"
        echo "TOP 20 DIRECTORIES ON: $volname"
        echo "────────────────────────────────────────────────────────────────────────────"
        du -sh "$vol"*/ 2>/dev/null | sort -hr | head -20 || echo "Cannot read"
        echo ""
      fi
    done
    
    echo "────────────────────────────────────────────────────────────────────────────"
    echo "TOP 20 IN HOME DIRECTORY:"
    echo "────────────────────────────────────────────────────────────────────────────"
    du -sh ~/*/ 2>/dev/null | sort -hr | head -20
  fi
  echo ""
} > "$OUTPUT_DIR/04_LARGEST_DIRS.txt"

echo "   ✓ Large directories saved"

# ═══════════════════════════════════════════════════════════════════════════
# 6. FIND MEDIA FILES (Audio/Video archives)
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [6/8] Cataloging media files..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "MEDIA FILE INVENTORY"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  echo "── AUDIO FILES ──"
  echo "Searching for: .wav, .aif, .aiff, .mp3, .flac, .ogg, .m4a"
  echo ""
  
  for vol in /Volumes/*/; do
    if [ -d "$vol" ] && [ -r "$vol" ]; then
      volname=$(basename "$vol")
      count=$(find "$vol" -maxdepth 5 -type f \( -iname "*.wav" -o -iname "*.aif" -o -iname "*.aiff" -o -iname "*.mp3" -o -iname "*.flac" -o -iname "*.m4a" \) 2>/dev/null | wc -l | tr -d ' ')
      if [ "$count" -gt 0 ]; then
        echo "$volname: $count audio files"
      fi
    fi
  done
  
  echo ""
  echo "── VIDEO FILES ──"
  echo "Searching for: .mov, .mp4, .avi, .mkv, .m4v, .prproj, .fcpx"
  echo ""
  
  for vol in /Volumes/*/; do
    if [ -d "$vol" ] && [ -r "$vol" ]; then
      volname=$(basename "$vol")
      count=$(find "$vol" -maxdepth 5 -type f \( -iname "*.mov" -o -iname "*.mp4" -o -iname "*.avi" -o -iname "*.mkv" -o -iname "*.m4v" \) 2>/dev/null | wc -l | tr -d ' ')
      if [ "$count" -gt 0 ]; then
        echo "$volname: $count video files"
      fi
    fi
  done
  
  echo ""
  echo "── PROJECT FILES ──"
  echo "Searching for: .ptx, .ptf, .logicx, .cpr, .als, .rpp"
  echo ""
  
  for vol in /Volumes/*/; do
    if [ -d "$vol" ] && [ -r "$vol" ]; then
      volname=$(basename "$vol")
      count=$(find "$vol" -maxdepth 5 -type f \( -iname "*.ptx" -o -iname "*.ptf" -o -iname "*.logicx" -o -iname "*.cpr" -o -iname "*.als" \) 2>/dev/null | wc -l | tr -d ' ')
      if [ "$count" -gt 0 ]; then
        echo "$volname: $count DAW project files"
      fi
    fi
  done
  echo ""
} > "$OUTPUT_DIR/05_MEDIA_FILES.txt"

echo "   ✓ Media inventory saved"

# ═══════════════════════════════════════════════════════════════════════════
# 7. FIND CODE/DEV DIRECTORIES
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [7/8] Finding code repositories..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "CODE REPOSITORIES & DEV DIRECTORIES"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  echo "── Git Repositories ──"
  find /Volumes/*/ -maxdepth 5 -name ".git" -type d 2>/dev/null | while read gitdir; do
    repo=$(dirname "$gitdir")
    echo "$repo"
  done | head -100
  
  echo ""
  echo "── Home Git Repos ──"
  find ~ -maxdepth 4 -name ".git" -type d 2>/dev/null | while read gitdir; do
    repo=$(dirname "$gitdir")
    echo "$repo"
  done
  
  echo ""
  echo "── Node Projects (package.json) ──"
  find ~ -maxdepth 4 -name "package.json" -type f 2>/dev/null | head -50
  
  echo ""
  echo "── Python Projects ──"
  find ~ -maxdepth 4 -name "requirements.txt" -type f 2>/dev/null | head -50
  echo ""
} > "$OUTPUT_DIR/06_CODE_REPOS.txt"

echo "   ✓ Code repos saved"

# ═══════════════════════════════════════════════════════════════════════════
# 8. GENERATE SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
echo "▶ [8/8] Generating summary..."

{
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo "MC96ECOUNIVERSE SCAN SUMMARY"
  echo "Generated: $(date)"
  echo "Hostname: $(hostname)"
  echo "═══════════════════════════════════════════════════════════════════════════"
  echo ""
  
  echo "VOLUMES FOUND:"
  echo "────────────────────────────────────────────────────────────────────────────"
  if [[ "$OSTYPE" == "darwin"* ]]; then
    ls -1 /Volumes/ | while read vol; do
      size=$(df -h "/Volumes/$vol" 2>/dev/null | tail -1 | awk '{print $2}')
      used=$(df -h "/Volumes/$vol" 2>/dev/null | tail -1 | awk '{print $3}')
      pct=$(df -h "/Volumes/$vol" 2>/dev/null | tail -1 | awk '{print $5}')
      echo "  $vol: $used / $size ($pct used)"
    done
  fi
  
  echo ""
  echo "TOTAL STORAGE:"
  echo "────────────────────────────────────────────────────────────────────────────"
  df -h | grep -E "^/dev" | awk '{sum+=$2} END {print "  Total capacity: " sum " (approximate)"}'
  df -h | grep -E "^/dev" | awk '{sum+=$3} END {print "  Total used: " sum " (approximate)"}'
  
  echo ""
  echo "SCAN OUTPUT FILES:"
  echo "────────────────────────────────────────────────────────────────────────────"
  ls -la "$OUTPUT_DIR"
  
  echo ""
  echo "════════════════════════════════════════════════════════════════════════════"
  echo "SCAN COMPLETE"
  echo "════════════════════════════════════════════════════════════════════════════"
} > "$OUTPUT_DIR/07_SUMMARY.txt"

# Also output summary to console
cat "$OUTPUT_DIR/07_SUMMARY.txt"

echo ""
echo "════════════════════════════════════════════════════════════════════════════"
echo "ALL SCAN FILES SAVED TO: $OUTPUT_DIR"
echo "════════════════════════════════════════════════════════════════════════════"
echo ""
echo "To view results:"
echo "  open $OUTPUT_DIR"
echo ""
echo "To send to Claude:"
echo "  Drag the folder into Claude Code, or:"
echo "  cat $OUTPUT_DIR/*.txt"
echo ""
