# ═══════════════════════════════════════════════════════════════════════════
#  MC96ECOUNIVERSE VOLUME SCANNER - GABRIEL (Windows)
#  Run on GABRIEL (HP Omen) to scan all mounted volumes
#  GORUNFREE - One command, full inventory
# ═══════════════════════════════════════════════════════════════════════════

$ErrorActionPreference = "Continue"
$OutputDir = "$env:USERPROFILE\MC96ECO_SCAN_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

Write-Host "╔══════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║           MC96ECOUNIVERSE VOLUME SCANNER - GABRIEL                       ║" -ForegroundColor Cyan
Write-Host "║           Scanning all mounted volumes on $env:COMPUTERNAME                    ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "Output directory: $OutputDir" -ForegroundColor Yellow
Write-Host "Started: $(Get-Date)" -ForegroundColor Yellow
Write-Host ""

# ═══════════════════════════════════════════════════════════════════════════
# 1. SYSTEM INFO
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [1/8] Gathering system info..." -ForegroundColor Green

$SystemInfo = @"
═══════════════════════════════════════════════════════════════════════════
MC96ECOUNIVERSE SCAN REPORT - GABRIEL
Generated: $(Get-Date)
Hostname: $env:COMPUTERNAME
═══════════════════════════════════════════════════════════════════════════

SYSTEM INFO:
────────────────────────────────────────────────────────────────────────────
$(Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, OsArchitecture, CsProcessors, CsTotalPhysicalMemory | Format-List | Out-String)

CPU:
$(Get-WmiObject Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors | Format-List | Out-String)

RAM:
$([math]::Round((Get-WmiObject Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)) GB
"@
$SystemInfo | Out-File "$OutputDir\00_SYSTEM_INFO.txt" -Encoding UTF8
Write-Host "   ✓ System info saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 2. ALL MOUNTED VOLUMES
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [2/8] Listing all mounted volumes..." -ForegroundColor Green

$Volumes = @"
═══════════════════════════════════════════════════════════════════════════
ALL MOUNTED VOLUMES
═══════════════════════════════════════════════════════════════════════════

── Physical Disks ──
$(Get-PhysicalDisk | Select-Object FriendlyName, MediaType, Size, HealthStatus | Format-Table -AutoSize | Out-String)

── Logical Drives ──
$(Get-Volume | Where-Object {$_.DriveLetter} | Select-Object DriveLetter, FileSystemLabel, FileSystem, @{N='SizeGB';E={[math]::Round($_.Size/1GB,2)}}, @{N='FreeGB';E={[math]::Round($_.SizeRemaining/1GB,2)}}, HealthStatus | Format-Table -AutoSize | Out-String)

── Drive Letters ──
$(Get-PSDrive -PSProvider FileSystem | Select-Object Name, @{N='UsedGB';E={[math]::Round($_.Used/1GB,2)}}, @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}, Root | Format-Table -AutoSize | Out-String)
"@
$Volumes | Out-File "$OutputDir\01_MOUNTED_VOLUMES.txt" -Encoding UTF8
Write-Host "   ✓ Volume list saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 3. DISK USAGE SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [3/8] Calculating disk usage..." -ForegroundColor Green

$DiskUsage = @"
═══════════════════════════════════════════════════════════════════════════
DISK USAGE SUMMARY
═══════════════════════════════════════════════════════════════════════════

"@

Get-Volume | Where-Object {$_.DriveLetter -and $_.Size -gt 0} | ForEach-Object {
    $pctUsed = [math]::Round((($_.Size - $_.SizeRemaining) / $_.Size) * 100, 1)
    $DiskUsage += @"
────────────────────────────────────────────────────────────────────────────
DRIVE $($_.DriveLetter): $($_.FileSystemLabel)
────────────────────────────────────────────────────────────────────────────
  Total: $([math]::Round($_.Size/1GB,2)) GB
  Used:  $([math]::Round(($_.Size - $_.SizeRemaining)/1GB,2)) GB ($pctUsed%)
  Free:  $([math]::Round($_.SizeRemaining/1GB,2)) GB

"@
}
$DiskUsage | Out-File "$OutputDir\02_DISK_USAGE.txt" -Encoding UTF8
Write-Host "   ✓ Disk usage saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 4. NETWORK SHARES
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [4/8] Detecting network shares..." -ForegroundColor Green

$NetworkShares = @"
═══════════════════════════════════════════════════════════════════════════
NETWORK SHARES & SMB CONNECTIONS
═══════════════════════════════════════════════════════════════════════════

── Mapped Network Drives ──
$(Get-PSDrive -PSProvider FileSystem | Where-Object {$_.DisplayRoot -like "\\*"} | Select-Object Name, DisplayRoot | Format-Table -AutoSize | Out-String)

── SMB Connections ──
$(Get-SmbConnection 2>$null | Select-Object ServerName, ShareName, UserName | Format-Table -AutoSize | Out-String)

── SMB Shares on This Machine ──
$(Get-SmbShare | Select-Object Name, Path, Description | Format-Table -AutoSize | Out-String)
"@
$NetworkShares | Out-File "$OutputDir\03_NETWORK_SHARES.txt" -Encoding UTF8
Write-Host "   ✓ Network shares saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 5. FIND LARGE DIRECTORIES
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [5/8] Finding largest directories (this may take a while)..." -ForegroundColor Green

$LargeDirs = @"
═══════════════════════════════════════════════════════════════════════════
LARGEST DIRECTORIES
═══════════════════════════════════════════════════════════════════════════

"@

Get-Volume | Where-Object {$_.DriveLetter -and $_.Size -gt 0} | ForEach-Object {
    $drive = "$($_.DriveLetter):\"
    $LargeDirs += @"
────────────────────────────────────────────────────────────────────────────
TOP DIRECTORIES ON $drive
────────────────────────────────────────────────────────────────────────────
"@
    try {
        $topDirs = Get-ChildItem -Path $drive -Directory -ErrorAction SilentlyContinue | 
            ForEach-Object {
                $size = (Get-ChildItem -Path $_.FullName -Recurse -File -ErrorAction SilentlyContinue | 
                    Measure-Object -Property Length -Sum).Sum
                [PSCustomObject]@{
                    Name = $_.Name
                    SizeGB = [math]::Round($size/1GB, 2)
                }
            } | Sort-Object SizeGB -Descending | Select-Object -First 15
        $LargeDirs += ($topDirs | Format-Table -AutoSize | Out-String)
    } catch {
        $LargeDirs += "  Cannot read directory`n"
    }
    $LargeDirs += "`n"
}
$LargeDirs | Out-File "$OutputDir\04_LARGEST_DIRS.txt" -Encoding UTF8
Write-Host "   ✓ Large directories saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 6. FIND MEDIA FILES
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [6/8] Cataloging media files..." -ForegroundColor Green

$MediaFiles = @"
═══════════════════════════════════════════════════════════════════════════
MEDIA FILE INVENTORY
═══════════════════════════════════════════════════════════════════════════

── AUDIO FILES (.wav, .mp3, .flac, .aif, .m4a) ──
"@

Get-Volume | Where-Object {$_.DriveLetter -and $_.Size -gt 0} | ForEach-Object {
    $drive = "$($_.DriveLetter):\"
    $audioCount = (Get-ChildItem -Path $drive -Recurse -File -Include *.wav,*.mp3,*.flac,*.aif,*.aiff,*.m4a -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($audioCount -gt 0) {
        $MediaFiles += "  $drive : $audioCount audio files`n"
    }
}

$MediaFiles += @"

── VIDEO FILES (.mov, .mp4, .avi, .mkv) ──
"@

Get-Volume | Where-Object {$_.DriveLetter -and $_.Size -gt 0} | ForEach-Object {
    $drive = "$($_.DriveLetter):\"
    $videoCount = (Get-ChildItem -Path $drive -Recurse -File -Include *.mov,*.mp4,*.avi,*.mkv,*.m4v -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($videoCount -gt 0) {
        $MediaFiles += "  $drive : $videoCount video files`n"
    }
}

$MediaFiles += @"

── DAW PROJECT FILES (.ptx, .logicx, .cpr, .als, .rpp) ──
"@

Get-Volume | Where-Object {$_.DriveLetter -and $_.Size -gt 0} | ForEach-Object {
    $drive = "$($_.DriveLetter):\"
    $projCount = (Get-ChildItem -Path $drive -Recurse -File -Include *.ptx,*.ptf,*.cpr,*.als,*.rpp -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($projCount -gt 0) {
        $MediaFiles += "  $drive : $projCount DAW project files`n"
    }
}

$MediaFiles | Out-File "$OutputDir\05_MEDIA_FILES.txt" -Encoding UTF8
Write-Host "   ✓ Media inventory saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 7. FIND CODE REPOS
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [7/8] Finding code repositories..." -ForegroundColor Green

$CodeRepos = @"
═══════════════════════════════════════════════════════════════════════════
CODE REPOSITORIES & DEV DIRECTORIES
═══════════════════════════════════════════════════════════════════════════

── Git Repositories ──
"@

$gitRepos = Get-ChildItem -Path $env:USERPROFILE -Recurse -Directory -Filter ".git" -ErrorAction SilentlyContinue -Force | 
    Select-Object -First 50 | ForEach-Object { $_.Parent.FullName }
$CodeRepos += ($gitRepos -join "`n") + "`n"

$CodeRepos += @"

── Node Projects (package.json) ──
"@
$nodeProjects = Get-ChildItem -Path $env:USERPROFILE -Recurse -File -Filter "package.json" -ErrorAction SilentlyContinue | 
    Select-Object -First 30 | ForEach-Object { $_.DirectoryName }
$CodeRepos += ($nodeProjects -join "`n") + "`n"

$CodeRepos += @"

── Python Projects (requirements.txt) ──
"@
$pyProjects = Get-ChildItem -Path $env:USERPROFILE -Recurse -File -Filter "requirements.txt" -ErrorAction SilentlyContinue | 
    Select-Object -First 30 | ForEach-Object { $_.DirectoryName }
$CodeRepos += ($pyProjects -join "`n") + "`n"

$CodeRepos | Out-File "$OutputDir\06_CODE_REPOS.txt" -Encoding UTF8
Write-Host "   ✓ Code repos saved" -ForegroundColor Gray

# ═══════════════════════════════════════════════════════════════════════════
# 8. GENERATE SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
Write-Host "▶ [8/8] Generating summary..." -ForegroundColor Green

$Summary = @"
═══════════════════════════════════════════════════════════════════════════
MC96ECOUNIVERSE SCAN SUMMARY - GABRIEL
Generated: $(Get-Date)
Hostname: $env:COMPUTERNAME
═══════════════════════════════════════════════════════════════════════════

VOLUMES FOUND:
────────────────────────────────────────────────────────────────────────────
"@

Get-Volume | Where-Object {$_.DriveLetter -and $_.Size -gt 0} | ForEach-Object {
    $pctUsed = [math]::Round((($_.Size - $_.SizeRemaining) / $_.Size) * 100, 1)
    $Summary += "  $($_.DriveLetter): $($_.FileSystemLabel) - $([math]::Round(($_.Size - $_.SizeRemaining)/1GB,2)) / $([math]::Round($_.Size/1GB,2)) GB ($pctUsed% used)`n"
}

$totalSize = (Get-Volume | Where-Object {$_.DriveLetter} | Measure-Object -Property Size -Sum).Sum
$totalFree = (Get-Volume | Where-Object {$_.DriveLetter} | Measure-Object -Property SizeRemaining -Sum).Sum

$Summary += @"

TOTAL STORAGE:
────────────────────────────────────────────────────────────────────────────
  Total capacity: $([math]::Round($totalSize/1TB, 2)) TB
  Total used: $([math]::Round(($totalSize - $totalFree)/1TB, 2)) TB
  Total free: $([math]::Round($totalFree/1TB, 2)) TB

SCAN OUTPUT FILES:
────────────────────────────────────────────────────────────────────────────
$(Get-ChildItem $OutputDir | Format-Table Name, Length -AutoSize | Out-String)

════════════════════════════════════════════════════════════════════════════
SCAN COMPLETE
════════════════════════════════════════════════════════════════════════════
"@

$Summary | Out-File "$OutputDir\07_SUMMARY.txt" -Encoding UTF8

# Output to console
Write-Host $Summary -ForegroundColor Cyan

Write-Host ""
Write-Host "════════════════════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "ALL SCAN FILES SAVED TO: $OutputDir" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "To view results:" -ForegroundColor Yellow
Write-Host "  explorer $OutputDir" -ForegroundColor White
Write-Host ""
Write-Host "To send to Claude Code:" -ForegroundColor Yellow
Write-Host "  Drag the folder into Claude Code, or paste contents" -ForegroundColor White
Write-Host ""

# Open the folder
explorer $OutputDir
