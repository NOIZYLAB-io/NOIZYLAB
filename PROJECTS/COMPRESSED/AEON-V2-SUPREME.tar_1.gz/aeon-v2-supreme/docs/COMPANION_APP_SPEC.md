# 📱 AEON COMPANION APP SPECIFICATION

## Overview

The AEON Companion App bridges the PMIC hardware (BLE) to the GOD-KERNEL cloud (HTTPS).

---

## 🎯 Core Features

### 1. BLE Connection
- Scan for AEON-PMIC devices
- Auto-connect to bonded device
- Handle reconnection on disconnect
- Display connection status

### 2. Power Monitoring
- Real-time SOC display (battery ring)
- Harvest/load power meters
- Runtime estimation
- Alert notifications

### 3. Cloud Bridge
- Forward power state to GOD-KERNEL (1/sec)
- Receive AI throttle level
- Relay burst commands to PMIC
- Handle offline queuing

### 4. Voice Alerts
- Text-to-speech for PMIC alerts
- Configurable alert types
- Do Not Disturb mode

### 5. OTA Updates
- Check for firmware updates
- Download and transfer to PMIC
- Progress indication

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                      📱 AEON COMPANION APP                     │
│                                                                 │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                    UI LAYER                              │  │
│   │                                                          │  │
│   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ │  │
│   │  │ Dashboard│  │ Settings │  │  History │  │  Debug   │ │  │
│   │  └──────────┘  └──────────┘  └──────────┘  └──────────┘ │  │
│   └─────────────────────────────────────────────────────────┘  │
│                              │                                  │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                   STATE MANAGER                          │  │
│   │                                                          │  │
│   │  • PowerState (from PMIC)                               │  │
│   │  • CloudState (from GOD-KERNEL)                         │  │
│   │  • ConnectionState (BLE + Network)                      │  │
│   │  • SettingsState (user preferences)                     │  │
│   └─────────────────────────────────────────────────────────┘  │
│                              │                                  │
│   ┌─────────────────────────┬───────────────────────────────┐  │
│   │                         │                                │  │
│   │   BLE SERVICE           │     CLOUD SERVICE             │  │
│   │                         │                                │  │
│   │   • Scan/Connect        │     • POST /power              │  │
│   │   • Parse PowerState    │     • GET /status              │  │
│   │   • Send Commands       │     • WebSocket (optional)     │  │
│   │   • Handle Alerts       │     • Offline queue            │  │
│   │   • OTA Transfer        │     • Retry logic              │  │
│   │                         │                                │  │
│   └─────────────────────────┴───────────────────────────────┘  │
│                              │                                  │
│   ┌─────────────────────────────────────────────────────────┐  │
│   │                   PLATFORM LAYER                         │  │
│   │                                                          │  │
│   │   iOS: CoreBluetooth, URLSession, AVSpeechSynthesizer   │  │
│   │   Android: BluetoothLeScanner, OkHttp, TextToSpeech     │  │
│   │                                                          │  │
│   └─────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📲 Screens

### 1. Dashboard (Main)

```
┌─────────────────────────────────────┐
│  ⚡ AEON POWER          [⚙️]        │
├─────────────────────────────────────┤
│                                     │
│         ╭───────────────╮          │
│         │               │          │
│         │      75%      │          │
│         │    BOOST      │          │
│         │               │          │
│         ╰───────────────╯          │
│                                     │
│   🌞 Solar     │   ⚡ Load         │
│   344 mW       │   180 mW          │
│                                     │
│   🔋 Runtime   │   💪 Supercap     │
│   4.2 hours    │   4.8V            │
│                                     │
├─────────────────────────────────────┤
│                                     │
│   🧠 AI Level: NORMAL              │
│   📡 Connected to GOD-KERNEL       │
│                                     │
│   [  🔥 BURST MODE  ]              │
│                                     │
└─────────────────────────────────────┘
```

### 2. Settings

```
┌─────────────────────────────────────┐
│  ⚙️ Settings                  [<]   │
├─────────────────────────────────────┤
│                                     │
│  DEVICE                             │
│  ─────────────────────────────────  │
│  AEON-PMIC             Connected ● │
│  Firmware: 2.0.0    [Check Update] │
│                                     │
│  CLOUD                              │
│  ─────────────────────────────────  │
│  Endpoint: aeon-god-kernel...      │
│  Sync interval: [1 sec ▼]          │
│                                     │
│  ALERTS                             │
│  ─────────────────────────────────  │
│  Voice alerts        [●───────]    │
│  Low battery         [───────●]    │
│  Mode changes        [───────●]    │
│  Predictions         [●───────]    │
│                                     │
│  POWER LIMITS                       │
│  ─────────────────────────────────  │
│  Min SOC for AI      [20% ▼]       │
│  Burst threshold     [4.5V ▼]      │
│                                     │
└─────────────────────────────────────┘
```

### 3. History

```
┌─────────────────────────────────────┐
│  📊 History                   [<]   │
├─────────────────────────────────────┤
│                                     │
│  TODAY                              │
│  ┌─────────────────────────────┐   │
│  │  SOC                        │   │
│  │  ████████████░░░░░░░░ 60%   │   │
│  │  ──────────────────────────  │   │
│  │  6AM    12PM    6PM   12AM  │   │
│  └─────────────────────────────┘   │
│                                     │
│  HARVEST: 412 mAh                   │
│  CONSUMED: 890 mAh                  │
│  NET: -478 mAh                      │
│                                     │
│  AI USAGE                           │
│  ─────────────────────────────────  │
│  FULL: 12 requests                  │
│  NORMAL: 45 requests                │
│  REDUCED: 8 requests                │
│  BURST: 2 requests                  │
│                                     │
│  [  View Full History  ]           │
│                                     │
└─────────────────────────────────────┘
```

---

## 🔧 Technical Requirements

### iOS
- iOS 14.0+
- Swift 5.5+
- SwiftUI
- Core Bluetooth
- Combine for reactive state

### Android
- API 26+ (Android 8.0)
- Kotlin
- Jetpack Compose
- Bluetooth LE
- Coroutines + Flow

---

## 📡 API Integration

### Power Update (POST /power)

```json
{
  "m": "BOOST",
  "soc": 75.5,
  "v": 3.85,
  "h": 344,
  "l": 180,
  "n": 164,
  "sc": 4.8,
  "rt": 4.2,
  "a": 0
}
```

### Response

```json
{
  "status": "POWER_UPDATED",
  "ai_level": { "name": "NORMAL", "model": "llama-3.1-8b" },
  "burst_signal": "OFF",
  "alerts": [],
  "queue_depth": 0
}
```

---

## 🔒 Security

- BLE: LE Secure Connections with bonding
- HTTPS: TLS 1.3 to Cloudflare Workers
- No sensitive data stored locally
- Biometric lock option

---

## 📦 Dependencies

### iOS
```
SwiftUI
CoreBluetooth
Combine
AVFoundation (TTS)
```

### Android
```
implementation 'androidx.bluetooth:bluetooth:1.0.0'
implementation 'com.squareup.okhttp3:okhttp:4.12.0'
implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
```

---

## 🚀 Development Phases

1. **Phase 1:** BLE connection + basic display
2. **Phase 2:** Cloud bridge + power forwarding
3. **Phase 3:** Voice alerts + notifications
4. **Phase 4:** OTA updates
5. **Phase 5:** Widgets + complications
