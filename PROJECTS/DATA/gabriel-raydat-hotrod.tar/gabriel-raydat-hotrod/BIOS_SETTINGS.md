# 🔧 GABRIEL HP-OMEN 25L - BIOS SETTINGS FOR AUDIO

## How to Enter BIOS
```
1. Restart GABRIEL
2. Press F10 repeatedly during boot
3. Enter BIOS Setup
```

## CRITICAL SETTINGS

### 1. Disable Onboard Audio
```
Location: Advanced → Integrated Peripherals
          OR Advanced → Onboard Devices

Setting: HD Audio Controller = DISABLED
         OR Realtek Audio = DISABLED
```

### 2. Disable C-States (CPU Power Saving)
```
Location: Advanced → CPU Configuration
          OR Power Management

Settings:
- C1E Support = DISABLED
- C-State Support = DISABLED  
- Package C-State = C0/C1 (lowest, or disabled)
```

### 3. Disable Speed Step / Cool'n'Quiet
```
Location: Advanced → CPU Configuration

Settings:
- Intel SpeedStep (EIST) = DISABLED
- AMD Cool'n'Quiet = DISABLED
```

### 4. PCIe Settings
```
Location: Advanced → PCIe Configuration

Settings:
- PCIe Speed = Gen3 (not Auto)
- ASPM (Active State Power Management) = DISABLED
```

### 5. USB Settings
```
Location: Advanced → USB Configuration

Settings:
- Legacy USB Support = ENABLED
- USB Mass Storage Driver Support = ENABLED
- XHCI Hand-off = ENABLED
```

### 6. Disable Secure Boot (if having driver issues)
```
Location: Security → Secure Boot

Setting: Secure Boot = DISABLED

Note: Only disable if RME driver won't load
      Re-enable after if Windows complains
```

## SAVE AND EXIT
```
F10 = Save and Exit
ESC = Discard and Exit

ALWAYS choose Save and Exit!
```

## AFTER BIOS CHANGES

1. Windows will boot
2. Check Device Manager - RME should show up
3. No yellow exclamation marks
4. Run the HOTROD_GABRIEL.ps1 script
5. Done!
