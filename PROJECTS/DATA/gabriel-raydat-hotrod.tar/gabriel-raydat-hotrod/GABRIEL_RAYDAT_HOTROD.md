# 🔥 GABRIEL HP-OMEN 25L + RME RAYDAT HOT ROD GUIDE

## SYSTEM OVERVIEW

```
┌─────────────────────────────────────────────────────────────────────┐
│  GABRIEL - HP OMEN 25L - Windows 10                                 │
│  IP: 10.90.90.20                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐      ADAT Optical      ┌──────────────────┐      │
│  │ RME RayDAT   │◄────────────────────►│ UAD Apollo       │      │
│  │ (PCIe)       │      (TOSLINK x2)      │ Quad 2           │      │
│  │              │                        │                  │      │
│  │ 36 Digital   │                        │ 4x Unison Pres   │      │
│  │ Channels     │                        │ 8x ADAT I/O      │      │
│  │              │                        │ SPDIF I/O        │      │
│  │ 0.7ms ASIO   │                        │ Monitor Outs     │      │
│  └──────────────┘                        └──────────────────┘      │
│         │                                         │                 │
│         │ TotalMix FX                             │ Console App     │
│         │ (DSP Mixer)                             │ (UAD Plugins)   │
│         ▼                                         ▼                 │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                        DAW                                    │  │
│  │              (Reaper / Cubase / FL Studio)                   │  │
│  │                                                               │  │
│  │  RayDAT ASIO + Apollo ASIO (aggregate or choose one)         │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## SIGNAL FLOW (Once Optical Connected)

```
RECORDING:
  Mic/Instrument → Apollo Preamp → Apollo ADC → ADAT Out → RayDAT ADAT In → DAW

PLAYBACK:
  DAW → RayDAT ADAT Out → Apollo ADAT In → Apollo DAC → Monitors/Headphones

MONITORING (Zero Latency):
  Apollo Direct Monitoring OR TotalMix DSP Monitoring
```

---

## PHASE 1: RME DRIVER INSTALLATION

### Step 1: Download Latest Driver
```
URL: https://rme-audio.de/downloads.html
File: HDSPe Series Driver v4.50 (Windows)
Direct: rme-audio.de/download/driver_hdsp_win_450.zip
```

### Step 2: Extract & Install
```powershell
# Run as Administrator
cd Downloads
Expand-Archive driver_hdsp_win_450.zip -DestinationPath RME_Driver
cd RME_Driver
.\rmeinstaller.exe

# Follow prompts, reboot when asked
```

### Step 3: Verify Installation
```
Device Manager → Sound, video and game controllers
Should see: "RME HDSPe RayDAT"

System Tray → RME TotalMix FX icon (blue/green)
```

---

## PHASE 2: WINDOWS 10 AUDIO HOT ROD

### A. Power Settings
```powershell
# Run as Administrator in PowerShell

# Set High Performance power plan
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c

# Disable USB selective suspend
powercfg /SETACVALUEINDEX SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
powercfg /SETACTIVE SCHEME_CURRENT

# Disable hard disk sleep
powercfg /change disk-timeout-ac 0

# Disable hibernate
powercfg /hibernate off
```

### B. Disable Audio Enhancements
```powershell
# Open Sound settings
control mmsys.cpl sounds

# For each RME device:
# Right-click → Properties → Enhancements → Disable all enhancements
# Advanced tab → Exclusive Mode → Check both boxes
```

### C. Disable Onboard Audio (BIOS)
```
1. Reboot → Enter BIOS (F10 or Del)
2. Find: Integrated Peripherals / Onboard Devices
3. Disable: HD Audio / Realtek Audio
4. Save & Exit
```

### D. Disable Windows Audio Services (Optional - DAW Only)
```powershell
# Only if using ASIO exclusively
# This prevents Windows from touching audio

# Disable Windows Audio service
# WARNING: No system sounds, only ASIO apps work
Stop-Service audiosrv
Set-Service audiosrv -StartupType Disabled

# To re-enable:
Set-Service audiosrv -StartupType Automatic
Start-Service audiosrv
```

### E. Process Priority & Affinity
```powershell
# Create batch file to launch DAW with high priority
@echo off
start /high /affinity FF "C:\Program Files\REAPER (x64)\reaper.exe"
```

### F. Disable Background Apps
```powershell
# Settings → Privacy → Background apps → OFF

# Or via Registry:
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v "GlobalUserDisabled" /t REG_DWORD /d 1 /f
```

### G. Disable Game Mode & Game Bar
```powershell
reg add "HKCU\Software\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 0 /f
```

### H. Network Throttling
```powershell
# Disable Nagle's Algorithm for lower latency
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 0xffffffff /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 0 /f
```

### I. DPC Latency Optimization
```powershell
# Disable driver power management that causes latency spikes
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "CsEnabled" /t REG_DWORD /d 0 /f

# Disable HPET (can cause issues on some systems)
bcdedit /deletevalue useplatformclock
```

---

## PHASE 3: RME TOTALMIX FX CONFIGURATION

### A. Open TotalMix Settings
```
System Tray → Right-click RME icon → Settings
OR
TotalMix FX → Options → Settings
```

### B. Optimal Buffer Settings
```
Settings Dialog:
├── Buffer Size: 128 samples (2.9ms @ 44.1kHz)
│   └── Lower = less latency, more CPU
│   └── Higher = more latency, less CPU
├── Sample Rate: 48000 Hz (match Apollo)
├── Clock Source: ADAT1 (when Apollo connected)
│   └── Apollo will be master clock
└── Safe Mode: OFF (unless crackling)
```

### C. TotalMix Routing for Apollo
```
ADAT 1-8 IN  → Hardware Outputs (for monitoring)
ADAT 1-8 OUT → Main software playback

Software Playback 1-2 → ADAT Out 1-2 → Apollo → Monitors
```

### D. Save Workspace
```
TotalMix → File → Save Workspace As → "GABRIEL_APOLLO_SETUP.tmws"
```

---

## PHASE 4: UAD APOLLO INTEGRATION

### A. Apollo Clock Settings
```
UAD Console → Settings → Hardware:
├── Sample Rate: 48000 Hz
├── Clock Source: Internal (Apollo is MASTER)
├── Digital Mirror: ADAT (optional)
└── ADAT: Enabled
```

### B. Optical Cable Connection
```
NEEDED:
- 2x TOSLINK optical cables (for 16 channels @ 48kHz)
- OR 4x TOSLINK for full 32 channels @ 48kHz

CONNECTIONS:
┌────────────────┐         ┌────────────────┐
│ RayDAT         │         │ Apollo Quad    │
├────────────────┤         ├────────────────┤
│ ADAT 1 OUT ────┼────────►│ ADAT IN        │
│ ADAT 1 IN  ◄───┼─────────│ ADAT OUT       │
│                │         │                │
│ (Optional:)    │         │                │
│ ADAT 2 OUT ────┼────────►│ ADAT 2 IN      │
│ ADAT 2 IN  ◄───┼─────────│ ADAT 2 OUT     │
└────────────────┘         └────────────────┘
```

### C. Sync Configuration
```
MASTER: Apollo Quad (Internal Clock)
SLAVE:  RayDAT (Clock Source: ADAT1)

In RME Settings:
- Clock Source: ADAT1
- AutoSync: Enabled
- Should show "Sync" status (not just "Lock")
```

---

## PHASE 5: DAW SETUP

### Reaper (Recommended)
```
Options → Preferences → Audio → Device:
├── Audio System: ASIO
├── ASIO Driver: ASIO HDSPe RayDAT
├── Sample Rate: 48000
├── Block Size: 128
└── Enable inputs: ADAT 1-8
```

### ASIO4ALL (If Combining Interfaces)
```
NOT RECOMMENDED - use one interface at a time
RayDAT ASIO is superior to ASIO4ALL
```

### FL Studio
```
Options → Audio Settings:
├── Device: ASIO HDSPe RayDAT
├── Sample Rate: 48000
├── Buffer Length: 128
└── Triple Buffer: OFF
```

### Cubase/Nuendo
```
Studio → Studio Setup → Audio System:
├── ASIO Driver: ASIO HDSPe RayDAT
├── Input Latency: ~2.9ms
├── Output Latency: ~2.9ms
└── Release Driver in Background: Checked
```

---

## PHASE 6: ADVANCED OPTIMIZATION

### A. LatencyMon (Test Your System)
```
Download: resplendence.com/latencymon
Run for 10 minutes while working
Check for DPC latency spikes > 500μs

Common culprits:
- ACPI.sys (disable C-States in BIOS)
- nvlddmkm.sys (NVIDIA driver - update or rollback)
- tcpip.sys (disable offloading)
- dxgkrnl.sys (GPU driver)
```

### B. Disable NVIDIA HD Audio
```
Device Manager → Sound controllers →
"NVIDIA High Definition Audio" → Disable

This only outputs HDMI audio - not needed
```

### C. Set RME Process Priority
```
Task Manager → Details → 
"TotalMix FX" → Right-click → Set Priority → High
```

### D. IRQ Optimization
```
# Check IRQ assignments
msinfo32 → Hardware Resources → IRQs

RayDAT should NOT share IRQ with:
- Network adapter
- USB controllers
- GPU (if possible)

Fix: Try different PCIe slot or disable conflicting devices
```

---

## TROUBLESHOOTING

### No Sound
```
1. Check TotalMix routing (faders up?)
2. Check DAW output routing
3. Verify sample rate matches everywhere
4. Check clock sync (should show "Sync")
```

### Crackling/Pops
```
1. Increase buffer size
2. Run LatencyMon - find culprit driver
3. Disable WiFi while recording
4. Close background apps
5. Check DPC latency
```

### Clock Sync Issues
```
1. Apollo = Master (Internal clock)
2. RayDAT = Slave (ADAT1 clock source)
3. Sample rates MUST match (both 48kHz)
4. Check optical cable connection
```

### RayDAT Not Detected
```
1. Reseat card in PCIe slot
2. Check PCIe power (if required)
3. Try different slot
4. Update BIOS
5. Disable Secure Boot (sometimes helps)
```

---

## SHOPPING LIST - OPTICAL CABLES

| Item | Purpose | Price |
|------|---------|-------|
| **TOSLINK 1m x2** | RayDAT ↔ Apollo | ~$15-30 |
| **TOSLINK 3m x2** | If farther apart | ~$25-50 |
| **Glass Fiber** | Better than plastic | +$10-20 |

**Recommended Brands:**
- Monoprice (budget, good)
- AudioQuest Forest (mid-range)
- Lifatec Silflex (audiophile, glass)

---

## FINAL CHECKLIST

- [ ] RME Driver v4.50 installed
- [ ] TotalMix FX running in system tray
- [ ] Windows audio optimizations applied
- [ ] Onboard audio disabled (BIOS)
- [ ] Power plan: High Performance
- [ ] Buffer size: 128 samples
- [ ] Sample rate: 48000 Hz
- [ ] Clock: Apollo=Master, RayDAT=Slave (ADAT1)
- [ ] TOSLINK cables connected (when purchased)
- [ ] DAW configured for ASIO HDSPe RayDAT
- [ ] LatencyMon tested (no red flags)
- [ ] Workspace saved in TotalMix
