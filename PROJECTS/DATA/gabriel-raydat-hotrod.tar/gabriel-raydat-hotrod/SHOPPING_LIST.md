# 🛒 GABRIEL RayDAT + Apollo - SHOPPING LIST

## CRITICAL - TOSLINK Optical Cables

You need **2 cables minimum** for 8-channel bidirectional ADAT:

| Item | Qty | Purpose | Price Range |
|------|-----|---------|-------------|
| **TOSLINK 1m** | 2 | RayDAT ↔ Apollo | $10-30 each |

### Recommended Cables (Quality Matters!)

**Budget (Works Fine):**
- [Monoprice Premium TOSLINK](https://www.monoprice.com/) - ~$8-15
- [AmazonBasics TOSLINK](https://www.amazon.com/) - ~$8-12

**Mid-Range (Better):**
- [AudioQuest Pearl](https://www.audioquest.com/) - ~$30-50
- [Wireworld Nova](https://www.wireworldcable.com/) - ~$40-60

**Pro (Glass Fiber - Best):**
- [Lifatec Silflex](https://www.lifatec.com/) - ~$50-100
- [Sys Concept Glass](https://www.sysconcept.ca/) - ~$40-80

### Cable Length Guide
```
Same rack/desk:     1m (3ft)   - RECOMMENDED
Across room:        3m (10ft)  - Works fine
Long runs:          5m+ (15ft+) - Use GLASS fiber only
```

### DO NOT BUY:
- ❌ Super cheap plastic cables (signal loss)
- ❌ Cables longer than needed (signal degradation)
- ❌ "Gold plated" TOSLINK (marketing BS - it's OPTICAL)

---

## OPTIONAL UPGRADES

### Word Clock Module (WCM) - ~$400
Only if you need BNC word clock sync
```
RME WCM for RayDAT
- 1x BNC In, 2x BNC Out
- Connects internally via ribbon cable
```

### Better Monitoring
If Apollo headphone out isn't enough:
```
- Sennheiser HD650/HD600 - ~$300-400
- Audio-Technica ATH-M50x - ~$150
- Beyerdynamic DT 770/880/990 - ~$150-300
```

### Backup Power
```
APC UPS 1500VA - ~$150-200
Protects gear from power spikes
Gives you time to save during outage
```

---

## TOTAL MINIMUM COST

| Item | Cost |
|------|------|
| 2x TOSLINK cables (1m) | ~$20-30 |
| **TOTAL** | **~$20-30** |

That's it! The RayDAT is installed, Apollo is there, just need the optical cables!

---

## WHERE TO BUY (Canada)

- **Long & McQuade** - longandmcquade.com
- **Amazon.ca** - amazon.ca
- **Monoprice** - monoprice.com (ships to CA)
- **B&H Photo** - bhphotovideo.com
- **Sweetwater** - sweetwater.com

---

## QUICK REFERENCE - Connections

```
┌─────────────────────────────────────────┐
│           BACK OF RAYDAT                │
├─────────────────────────────────────────┤
│  ADAT1 OUT ●────────────► Apollo ADAT IN │
│  ADAT1 IN  ●◄──────────── Apollo ADAT OUT│
│                                          │
│  (ADAT2, ADAT3, ADAT4 available for     │
│   additional converters later)           │
└─────────────────────────────────────────┘
```
