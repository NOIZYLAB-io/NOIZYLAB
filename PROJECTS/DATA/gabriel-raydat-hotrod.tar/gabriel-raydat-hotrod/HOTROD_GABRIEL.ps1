#Requires -RunAsAdministrator
<#
.SYNOPSIS
    GABRIEL HP-OMEN 25L Audio Hot Rod Script
    Optimizes Windows 10 for RME RayDAT + UAD Apollo
    
.DESCRIPTION
    GORUNFREE! One script does EVERYTHING.
    Run as Administrator.
    
.AUTHOR
    Fish Music Inc / NOIZYLAB / MC96 ECOSYSTEM
#>

Write-Host "
╔═══════════════════════════════════════════════════════════════╗
║  GABRIEL AUDIO HOT ROD SCRIPT                                 ║
║  RME RayDAT + UAD Apollo Optimization                         ║
║  GORUNFREE!                                                   ║
╚═══════════════════════════════════════════════════════════════╝
" -ForegroundColor Cyan

$ErrorActionPreference = "SilentlyContinue"

# ═══════════════════════════════════════════════════════════════
# PHASE 1: POWER SETTINGS
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 1] Configuring Power Settings..." -ForegroundColor Yellow

# Create Ultimate Performance power plan (hidden by default)
Write-Host "  → Enabling Ultimate Performance power plan..."
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>$null
$ultimatePlan = powercfg -list | Select-String "Ultimate Performance" | ForEach-Object { ($_ -split '\s+')[3] }
if ($ultimatePlan) {
    powercfg -setactive $ultimatePlan
    Write-Host "    ✓ Ultimate Performance enabled" -ForegroundColor Green
} else {
    # Fall back to High Performance
    powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
    Write-Host "    ✓ High Performance enabled" -ForegroundColor Green
}

# Disable USB selective suspend
Write-Host "  → Disabling USB selective suspend..."
powercfg /SETACVALUEINDEX SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
powercfg /SETDCVALUEINDEX SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
powercfg /SETACTIVE SCHEME_CURRENT
Write-Host "    ✓ USB selective suspend disabled" -ForegroundColor Green

# Disable hard disk sleep
Write-Host "  → Disabling hard disk sleep..."
powercfg /change disk-timeout-ac 0
powercfg /change disk-timeout-dc 0
Write-Host "    ✓ Hard disk sleep disabled" -ForegroundColor Green

# Disable hibernate
Write-Host "  → Disabling hibernate..."
powercfg /hibernate off
Write-Host "    ✓ Hibernate disabled" -ForegroundColor Green

# Disable display timeout (optional for studio)
Write-Host "  → Setting display timeout to 30 min..."
powercfg /change monitor-timeout-ac 30
Write-Host "    ✓ Display timeout set" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 2: REGISTRY OPTIMIZATIONS
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 2] Applying Registry Optimizations..." -ForegroundColor Yellow

# Multimedia scheduling - prioritize audio
Write-Host "  → Configuring multimedia scheduling..."
$mmPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
Set-ItemProperty -Path $mmPath -Name "NetworkThrottlingIndex" -Value 0xffffffff -Type DWord
Set-ItemProperty -Path $mmPath -Name "SystemResponsiveness" -Value 0 -Type DWord
Write-Host "    ✓ Multimedia scheduling optimized" -ForegroundColor Green

# Audio priority
Write-Host "  → Setting audio task priority..."
$audioTaskPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio"
if (!(Test-Path $audioTaskPath)) { New-Item -Path $audioTaskPath -Force | Out-Null }
Set-ItemProperty -Path $audioTaskPath -Name "Affinity" -Value 0 -Type DWord
Set-ItemProperty -Path $audioTaskPath -Name "Background Only" -Value "False" -Type String
Set-ItemProperty -Path $audioTaskPath -Name "Clock Rate" -Value 10000 -Type DWord
Set-ItemProperty -Path $audioTaskPath -Name "GPU Priority" -Value 8 -Type DWord
Set-ItemProperty -Path $audioTaskPath -Name "Priority" -Value 6 -Type DWord
Set-ItemProperty -Path $audioTaskPath -Name "Scheduling Category" -Value "High" -Type String
Set-ItemProperty -Path $audioTaskPath -Name "SFIO Priority" -Value "High" -Type String
Write-Host "    ✓ Audio task priority set to HIGH" -ForegroundColor Green

# Pro Audio task (if DAW uses it)
Write-Host "  → Setting Pro Audio task priority..."
$proAudioPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio"
if (!(Test-Path $proAudioPath)) { New-Item -Path $proAudioPath -Force | Out-Null }
Set-ItemProperty -Path $proAudioPath -Name "Affinity" -Value 0 -Type DWord
Set-ItemProperty -Path $proAudioPath -Name "Background Only" -Value "False" -Type String
Set-ItemProperty -Path $proAudioPath -Name "Clock Rate" -Value 10000 -Type DWord
Set-ItemProperty -Path $proAudioPath -Name "GPU Priority" -Value 8 -Type DWord
Set-ItemProperty -Path $proAudioPath -Name "Priority" -Value 6 -Type DWord
Set-ItemProperty -Path $proAudioPath -Name "Scheduling Category" -Value "High" -Type String
Set-ItemProperty -Path $proAudioPath -Name "SFIO Priority" -Value "High" -Type String
Write-Host "    ✓ Pro Audio task priority set" -ForegroundColor Green

# Disable Game Mode and Game Bar
Write-Host "  → Disabling Game Mode and Game Bar..."
$gamePath = "HKCU:\Software\Microsoft\GameBar"
if (!(Test-Path $gamePath)) { New-Item -Path $gamePath -Force | Out-Null }
Set-ItemProperty -Path $gamePath -Name "AllowAutoGameMode" -Value 0 -Type DWord
Set-ItemProperty -Path $gamePath -Name "AutoGameModeEnabled" -Value 0 -Type DWord
Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 0 -Type DWord 2>$null
Write-Host "    ✓ Game Mode disabled" -ForegroundColor Green

# Disable Connected Standby (causes audio issues)
Write-Host "  → Disabling Connected Standby..."
$powerPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Power"
Set-ItemProperty -Path $powerPath -Name "CsEnabled" -Value 0 -Type DWord
Write-Host "    ✓ Connected Standby disabled" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 3: DISABLE BACKGROUND SERVICES
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 3] Disabling Background Services..." -ForegroundColor Yellow

# Disable Windows Search indexing (can cause disk spikes)
Write-Host "  → Disabling Windows Search indexing..."
Stop-Service WSearch -Force 2>$null
Set-Service WSearch -StartupType Disabled
Write-Host "    ✓ Windows Search disabled" -ForegroundColor Green

# Disable Superfetch/SysMain (can cause stuttering)
Write-Host "  → Disabling SysMain (Superfetch)..."
Stop-Service SysMain -Force 2>$null
Set-Service SysMain -StartupType Disabled
Write-Host "    ✓ SysMain disabled" -ForegroundColor Green

# Disable Windows Update service during sessions (re-enable manually)
Write-Host "  → Stopping Windows Update (can re-enable later)..."
Stop-Service wuauserv -Force 2>$null
# Not disabling permanently - just stopping for this session
Write-Host "    ✓ Windows Update stopped (not permanently disabled)" -ForegroundColor Green

# Disable Diagnostic services
Write-Host "  → Disabling Diagnostic services..."
Stop-Service DiagTrack -Force 2>$null
Set-Service DiagTrack -StartupType Disabled
Stop-Service dmwappushservice -Force 2>$null
Set-Service dmwappushservice -StartupType Disabled
Write-Host "    ✓ Diagnostic services disabled" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 4: USB & PCI OPTIMIZATIONS
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 4] Optimizing USB & PCI Devices..." -ForegroundColor Yellow

# Disable USB power management for all USB hubs
Write-Host "  → Disabling USB power management..."
$usbHubs = Get-WmiObject Win32_USBHub
foreach ($hub in $usbHubs) {
    $pnpEntity = Get-WmiObject -Query "SELECT * FROM Win32_PnPEntity WHERE DeviceID='$($hub.DeviceID.Replace('\','\\'))'" 2>$null
}

# Disable power management via registry for USB
$usbPath = "HKLM:\SYSTEM\CurrentControlSet\Services\USB"
if (!(Test-Path $usbPath)) { New-Item -Path $usbPath -Force | Out-Null }
Set-ItemProperty -Path $usbPath -Name "DisableSelectiveSuspend" -Value 1 -Type DWord 2>$null
Write-Host "    ✓ USB power management configured" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 5: NETWORK OPTIMIZATIONS
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 5] Optimizing Network..." -ForegroundColor Yellow

# Disable Nagle's Algorithm (reduces network latency)
Write-Host "  → Disabling Nagle's Algorithm..."
$tcpPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
$interfaces = Get-ChildItem $tcpPath
foreach ($interface in $interfaces) {
    Set-ItemProperty -Path $interface.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord 2>$null
    Set-ItemProperty -Path $interface.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord 2>$null
}
Write-Host "    ✓ Nagle's Algorithm disabled" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 6: VISUAL EFFECTS (Reduce GPU Load)
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 6] Optimizing Visual Effects..." -ForegroundColor Yellow

# Set visual effects to "Adjust for best performance" but keep font smoothing
Write-Host "  → Reducing visual effects..."
$visualPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
Set-ItemProperty -Path $visualPath -Name "VisualFXSetting" -Value 2 -Type DWord 2>$null

# Keep ClearType font smoothing (important for readability)
$desktopPath = "HKCU:\Control Panel\Desktop"
Set-ItemProperty -Path $desktopPath -Name "FontSmoothing" -Value "2" -Type String 2>$null
Write-Host "    ✓ Visual effects reduced (fonts preserved)" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 7: CREATE AUDIO SESSION SCRIPT
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 7] Creating Audio Session Launcher..." -ForegroundColor Yellow

$launcherPath = "$env:USERPROFILE\Desktop\START_AUDIO_SESSION.bat"
$launcherContent = @'
@echo off
title GABRIEL AUDIO SESSION
color 0A

echo.
echo ╔═══════════════════════════════════════════════════════════════╗
echo ║  GABRIEL AUDIO SESSION STARTER                                ║
echo ║  RME RayDAT + UAD Apollo                                      ║
echo ╚═══════════════════════════════════════════════════════════════╝
echo.

:: Stop unnecessary services for this session
echo [1/5] Stopping background services...
net stop wuauserv >nul 2>&1
net stop BITS >nul 2>&1
net stop DoSvc >nul 2>&1

:: Set process priorities
echo [2/5] Setting process priorities...
wmic process where name="TotalMixFX.exe" CALL setpriority "high priority" >nul 2>&1

:: Clear standby memory
echo [3/5] Clearing standby memory...
:: Requires RAMMap or similar tool

:: Disable WiFi (optional - uncomment if needed)
:: echo [4/5] Disabling WiFi...
:: netsh interface set interface "Wi-Fi" disable

echo [4/5] Ready...

:: Launch TotalMix if not running
tasklist /FI "IMAGENAME eq TotalMixFX.exe" 2>NUL | find /I /N "TotalMixFX.exe">NUL
if "%ERRORLEVEL%"=="1" (
    echo [5/5] Starting TotalMix FX...
    start "" "C:\Program Files\RME\TotalMix FX\TotalMixFX.exe"
)

echo.
echo ════════════════════════════════════════════════════════════════
echo   AUDIO SESSION READY!
echo   Buffer: 128 samples / Latency: ~2.9ms
echo   Clock: Apollo = Master, RayDAT = Slave (ADAT1)
echo ════════════════════════════════════════════════════════════════
echo.
echo Press any key to launch DAW or close this window...
pause >nul
'@

Set-Content -Path $launcherPath -Value $launcherContent
Write-Host "    ✓ Created: START_AUDIO_SESSION.bat on Desktop" -ForegroundColor Green

# ═══════════════════════════════════════════════════════════════
# PHASE 8: VERIFY RME INSTALLATION
# ═══════════════════════════════════════════════════════════════
Write-Host "`n[PHASE 8] Verifying RME Installation..." -ForegroundColor Yellow

$rmeDevice = Get-WmiObject Win32_SoundDevice | Where-Object { $_.Name -like "*RME*" -or $_.Name -like "*HDSPe*" -or $_.Name -like "*RayDAT*" }

if ($rmeDevice) {
    Write-Host "    ✓ RME Device Found: $($rmeDevice.Name)" -ForegroundColor Green
} else {
    Write-Host "    ⚠ RME Device NOT FOUND in Windows!" -ForegroundColor Red
    Write-Host "      → Check Device Manager" -ForegroundColor Yellow
    Write-Host "      → Reinstall RME drivers from rme-audio.de/downloads" -ForegroundColor Yellow
}

# Check for TotalMix
$totalMix = Get-Process -Name "TotalMixFX" -ErrorAction SilentlyContinue
if ($totalMix) {
    Write-Host "    ✓ TotalMix FX is running" -ForegroundColor Green
} else {
    Write-Host "    ⚠ TotalMix FX not running" -ForegroundColor Yellow
    Write-Host "      → Start from: C:\Program Files\RME\TotalMix FX\" -ForegroundColor Yellow
}

# ═══════════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════════
Write-Host "`n
╔═══════════════════════════════════════════════════════════════╗
║  HOT ROD COMPLETE!                                            ║
╠═══════════════════════════════════════════════════════════════╣
║  ✓ Power plan: Ultimate/High Performance                      ║
║  ✓ USB selective suspend: DISABLED                            ║
║  ✓ Multimedia scheduling: OPTIMIZED                           ║
║  ✓ Audio priority: HIGH                                       ║
║  ✓ Game Mode: DISABLED                                        ║
║  ✓ Background services: MINIMIZED                             ║
║  ✓ Network latency: OPTIMIZED                                 ║
║  ✓ Visual effects: REDUCED                                    ║
║  ✓ Session launcher: Desktop\START_AUDIO_SESSION.bat          ║
╠═══════════════════════════════════════════════════════════════╣
║  NEXT STEPS:                                                  ║
║  1. REBOOT to apply all changes                               ║
║  2. Disable onboard audio in BIOS                             ║
║  3. Connect TOSLINK cables (Apollo ↔ RayDAT)                  ║
║  4. Set Apollo Clock: Internal, RayDAT Clock: ADAT1           ║
║  5. Run START_AUDIO_SESSION.bat before recording              ║
╚═══════════════════════════════════════════════════════════════╝
" -ForegroundColor Cyan

Write-Host "REBOOT REQUIRED for all changes to take effect!" -ForegroundColor Red
Write-Host ""
$reboot = Read-Host "Reboot now? (Y/N)"
if ($reboot -eq "Y" -or $reboot -eq "y") {
    Write-Host "Rebooting in 10 seconds... (Ctrl+C to cancel)"
    Start-Sleep -Seconds 10
    Restart-Computer -Force
}

