# 🎚️ TotalMix FX Configuration for Apollo Integration

## Initial Setup

### 1. Open TotalMix Settings
```
System Tray → Right-click RME icon → Settings
```

### 2. Clock Configuration
```
┌─────────────────────────────────────┐
│ RME HDSPe RayDAT Settings           │
├─────────────────────────────────────┤
│ Sample Rate:    48000 Hz            │
│ Clock Source:   ADAT1               │ ← Apollo is master
│ AutoSync Ref:   ADAT1               │
│ Current:        Sync (green)        │ ← Must say "Sync"
└─────────────────────────────────────┘
```

### 3. Buffer Size
```
Buffer Size: 128 samples
             ↓
Input Latency:  2.67 ms (@ 48kHz)
Output Latency: 2.67 ms (@ 48kHz)
Total RTL:      ~5.3 ms
```

### 4. Check Sync Status
```
Status should show:
- ADAT1: Sync (not just "Lock")
- Sample Rate: 48000 (matching Apollo)
- No red warnings
```

---

## Routing for Apollo Playback

### Software Playback → ADAT Out → Apollo → Monitors

```
TotalMix Mixer (Hardware Outputs section):

ADAT 1/2 Output:
├── Software Playback 1/2: 0.0 dB (unity)
├── All others: -∞ (off)
└── This goes to Apollo ADAT In 1/2 → DAC → Monitors
```

### Step by Step:
1. Open TotalMix FX
2. Bottom row = Hardware Outputs
3. Click on "ADAT 1/2" output
4. Middle row = Software Playback
5. Raise "Software Playback 1/2" fader to 0.0 dB
6. Lower all other faders

---

## Routing for Apollo Recording

### Apollo Preamps → ADAT Out → RayDAT ADAT In → DAW

```
Apollo Console:
├── Mic/Instrument → Preamp → ADC
├── ADAT Out 1-8 mirrors inputs 1-8
└── Send to RayDAT

TotalMix (monitoring only):
├── Hardware Input: ADAT 1-8
├── Route to: AN 1/2 or Phones (if connected)
└── Or use Apollo's direct monitoring
```

---

## Save Your Workspace

```
File → Save Workspace As...
Filename: GABRIEL_APOLLO_48K.tmws
Location: Documents\RME TotalMix FX\

This saves:
- All routing
- All fader positions  
- All settings
- Clock configuration
```

## Load at Startup

```
Options → Settings → Options tab:
☑ Load workspace on startup: GABRIEL_APOLLO_48K.tmws
```

---

## Quick Reference - Channel Mapping

```
┌────────────────────────────────────────────────────────────┐
│  RayDAT Channels        →    Apollo Channels               │
├────────────────────────────────────────────────────────────┤
│  ADAT 1 (ch 1-8)        ↔    Apollo ADAT (ch 1-8)         │
│  ADAT 2 (ch 9-16)       ↔    (not connected)              │
│  ADAT 3 (ch 17-24)      ↔    (not connected)              │
│  ADAT 4 (ch 25-32)      ↔    (not connected)              │
│  SPDIF (ch 33-34)       ↔    (available)                  │
│  AES (ch 35-36)         ↔    (available)                  │
└────────────────────────────────────────────────────────────┘
```
